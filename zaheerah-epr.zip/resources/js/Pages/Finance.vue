<script setup lang="ts">
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import { Head } from '@inertiajs/vue3';
</script>

<template>
    <Head title="Finance" />
    <AuthenticatedLayout>
        <template #header>
            <h2 class="text-2xl font-bold leading-tight text-gray-800 dark:text-gray-200">Financial Management</h2>
        </template>

        <div class="flex flex-col items-center justify-center h-[70vh] text-center">
            <div class="relative w-16 h-16">
                <div class="absolute inset-0 border-4 border-gray-300 dark:border-gray-600 rounded-full"></div>
                <div class="absolute inset-0 border-t-4 border-green-500 rounded-full animate-spin"></div>
            </div>
            <h3 class="mt-6 text-2xl font-semibold text-gray-800 dark:text-gray-200">
                Page Under Development
            </h3>
            <p class="mt-2 text-gray-600 dark:text-gray-400 max-w-md">
                We are currently working on this section to improve your experience.  
                Please check back soon for updates.
            </p>
        </div>
    </AuthenticatedLayout>
</template>
