import { defineComponent, unref, withCtx, createTextVNode, useSSRContext } from "vue";
import { ssrInterpolate, ssrRenderComponent, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual, ssrRenderList, ssrRenderAttr } from "vue/server-renderer";
import { useForm } from "@inertiajs/vue3";
import { _ as _sfc_main$1, a as _sfc_main$2, b as _sfc_main$3 } from "./TextInput-Co45MSy8.js";
import { P as PrimaryButton } from "./PrimaryButton-CDoi0rzE.js";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "ProductForm",
  __ssrInlineRender: true,
  props: {
    categories: {
      type: Array,
      required: true
    },
    suppliers: {
      type: Array,
      required: true
    }
  },
  setup(__props) {
    const form = useForm({
      name: "",
      price: "",
      stock: "",
      weight: "",
      weight_per_bag: "",
      total_cost: "",
      stock_receive: "",
      stock_release: "",
      remaining_bags: "",
      supplier_id: "",
      exp_date: "",
      batch_number: "",
      storage_location: "",
      category_id: ""
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      if (_ctx.$page.props.flash.success) {
        _push(`<div class="bg-green-100 text-green-700 px-4 py-2 rounded mb-4">${ssrInterpolate(_ctx.$page.props.flash.success)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<form class="space-y-6"><div class="grid grid-cols-1 md:grid-cols-2 gap-4"><div>`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "name",
        value: "Product Name"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, {
        id: "name",
        type: "text",
        class: "mt-1 block w-full",
        modelValue: unref(form).name,
        "onUpdate:modelValue": ($event) => unref(form).name = $event,
        required: "",
        autofocus: ""
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.name
      }, null, _parent));
      _push(`</div><div>`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "price",
        value: "Price"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, {
        id: "price",
        type: "number",
        step: "0.01",
        class: "mt-1 block w-full",
        modelValue: unref(form).price,
        "onUpdate:modelValue": ($event) => unref(form).price = $event,
        required: ""
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.price
      }, null, _parent));
      _push(`</div><div>`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "stock",
        value: "Stock"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, {
        id: "stock",
        type: "number",
        class: "mt-1 block w-full",
        modelValue: unref(form).stock,
        "onUpdate:modelValue": ($event) => unref(form).stock = $event,
        required: ""
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.stock
      }, null, _parent));
      _push(`</div><div>`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "category",
        value: "Category"
      }, null, _parent));
      _push(`<select id="category" class="mt-1 block w-full rounded-md shadow-sm border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50" required><option value="" disabled${ssrIncludeBooleanAttr(Array.isArray(unref(form).category_id) ? ssrLooseContain(unref(form).category_id, "") : ssrLooseEqual(unref(form).category_id, "")) ? " selected" : ""}>Select a category</option><!--[-->`);
      ssrRenderList(__props.categories, (category) => {
        _push(`<option${ssrRenderAttr("value", category.id)}>${ssrInterpolate(category.name)}</option>`);
      });
      _push(`<!--]--></select>`);
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.category_id
      }, null, _parent));
      _push(`</div><div>`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "weight",
        value: "Weight"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, {
        id: "weight",
        type: "number",
        step: "0.01",
        class: "mt-1 block w-full",
        modelValue: unref(form).weight,
        "onUpdate:modelValue": ($event) => unref(form).weight = $event
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.weight
      }, null, _parent));
      _push(`</div><div>`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "weight_per_bag",
        value: "Weight per Bag"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, {
        id: "weight_per_bag",
        type: "number",
        step: "0.01",
        class: "mt-1 block w-full",
        modelValue: unref(form).weight_per_bag,
        "onUpdate:modelValue": ($event) => unref(form).weight_per_bag = $event
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.weight_per_bag
      }, null, _parent));
      _push(`</div><div>`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "total_cost",
        value: "Total Cost"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, {
        id: "total_cost",
        type: "number",
        step: "0.01",
        class: "mt-1 block w-full",
        modelValue: unref(form).total_cost,
        "onUpdate:modelValue": ($event) => unref(form).total_cost = $event
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.total_cost
      }, null, _parent));
      _push(`</div><div>`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "stock_receive",
        value: "Stock Receive"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, {
        id: "stock_receive",
        type: "number",
        class: "mt-1 block w-full",
        modelValue: unref(form).stock_receive,
        "onUpdate:modelValue": ($event) => unref(form).stock_receive = $event
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.stock_receive
      }, null, _parent));
      _push(`</div><div>`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "stock_release",
        value: "Stock Release"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, {
        id: "stock_release",
        type: "number",
        class: "mt-1 block w-full",
        modelValue: unref(form).stock_release,
        "onUpdate:modelValue": ($event) => unref(form).stock_release = $event
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.stock_release
      }, null, _parent));
      _push(`</div><div>`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "remaining_bags",
        value: "Remaining Bags"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, {
        id: "remaining_bags",
        type: "number",
        class: "mt-1 block w-full",
        modelValue: unref(form).remaining_bags,
        "onUpdate:modelValue": ($event) => unref(form).remaining_bags = $event
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.remaining_bags
      }, null, _parent));
      _push(`</div><div>`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "supplier",
        value: "Supplier"
      }, null, _parent));
      _push(`<select id="supplier" class="mt-1 block w-full rounded-md shadow-sm border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"><option value="" disabled${ssrIncludeBooleanAttr(Array.isArray(unref(form).supplier_id) ? ssrLooseContain(unref(form).supplier_id, "") : ssrLooseEqual(unref(form).supplier_id, "")) ? " selected" : ""}>Select a supplier</option><!--[-->`);
      ssrRenderList(__props.suppliers, (supplier) => {
        _push(`<option${ssrRenderAttr("value", supplier.id)}>${ssrInterpolate(supplier.name)}</option>`);
      });
      _push(`<!--]--></select>`);
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.supplier_id
      }, null, _parent));
      _push(`</div><div>`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "exp_date",
        value: "Expiration Date"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, {
        id: "exp_date",
        type: "date",
        class: "mt-1 block w-full",
        modelValue: unref(form).exp_date,
        "onUpdate:modelValue": ($event) => unref(form).exp_date = $event
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.exp_date
      }, null, _parent));
      _push(`</div><div>`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "batch_number",
        value: "Batch Number"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, {
        id: "batch_number",
        type: "text",
        class: "mt-1 block w-full",
        modelValue: unref(form).batch_number,
        "onUpdate:modelValue": ($event) => unref(form).batch_number = $event
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.batch_number
      }, null, _parent));
      _push(`</div><div>`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "storage_location",
        value: "Storage Location"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, {
        id: "storage_location",
        type: "text",
        class: "mt-1 block w-full",
        modelValue: unref(form).storage_location,
        "onUpdate:modelValue": ($event) => unref(form).storage_location = $event
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.storage_location
      }, null, _parent));
      _push(`</div></div><div class="flex items-center gap-4">`);
      _push(ssrRenderComponent(PrimaryButton, {
        disabled: unref(form).processing
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Save`);
          } else {
            return [
              createTextVNode("Save")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></form><!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/product/Partials/ProductForm.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
