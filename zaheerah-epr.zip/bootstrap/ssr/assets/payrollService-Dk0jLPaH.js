import axios from "axios";
const fetchUsers = async () => {
  try {
    const response = await axios.get("/users");
    return response.data.users;
  } catch (error) {
    console.error("Error fetching users:", error);
    return [];
  }
};
const fetchPayrolls = async () => {
  try {
    const response = await axios.get("/payrolls");
    return response.data.payrolls;
  } catch (error) {
    console.error("Error fetching payrolls:", error);
    return [];
  }
};
export {
  fetchUsers as a,
  fetchPayrolls as f
};
