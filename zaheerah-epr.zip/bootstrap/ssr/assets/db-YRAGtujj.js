import { defineComponent, unref, withCtx, createVNode, useSSRContext } from "vue";
import { ssrRenderComponent } from "vue/server-renderer";
import { A as AuthenticatedLayout } from "./AuthenticatedLayout-GMSouBjC.js";
import { Head } from "@inertiajs/vue3";
import "laravel-permission-to-vuejs";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "db",
  __ssrInlineRender: true,
  props: {
    totalRevenue: {
      type: String,
      default: "0"
    },
    totalProfit: {
      type: String,
      default: "0"
    },
    totalStock: {
      type: String,
      default: "0"
    },
    totalCost: {
      type: String,
      default: "0"
    },
    categories: Array,
    recentActivities: {
      type: Array,
      default: []
    },
    users: Array
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Dashboard" }, null, _parent));
      _push(ssrRenderComponent(AuthenticatedLayout, null, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<header class="flex items-center justify-between px-4 py-4 bg-gray-50 dark:bg-gray-800 rounded-lg shadow-sm"${_scopeId}><h2 class="text-3xl font-bold text-gray-800 dark:text-gray-200"${_scopeId}>Admin Dashboard</h2></header>`);
          } else {
            return [
              createVNode("header", { class: "flex items-center justify-between px-4 py-4 bg-gray-50 dark:bg-gray-800 rounded-lg shadow-sm" }, [
                createVNode("h2", { class: "text-3xl font-bold text-gray-800 dark:text-gray-200" }, "Admin Dashboard")
              ])
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="p-6"${_scopeId}><div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8"${_scopeId}><div class="bg-white dark:bg-gray-700 p-6 rounded-lg shadow-sm"${_scopeId}><h3 class="text-lg font-semibold text-gray-700 dark:text-gray-200"${_scopeId}>Total Employees</h3><p class="text-2xl font-bold text-gray-900 dark:text-gray-100"${_scopeId}>256</p></div><div class="bg-white dark:bg-gray-700 p-6 rounded-lg shadow-sm"${_scopeId}><h3 class="text-lg font-semibold text-gray-700 dark:text-gray-200"${_scopeId}>Active Employees</h3><p class="text-2xl font-bold text-gray-900 dark:text-gray-100"${_scopeId}>240</p></div><div class="bg-white dark:bg-gray-700 p-6 rounded-lg shadow-sm"${_scopeId}><h3 class="text-lg font-semibold text-gray-700 dark:text-gray-200"${_scopeId}>New Hires (This Month)</h3><p class="text-2xl font-bold text-gray-900 dark:text-gray-100"${_scopeId}>8</p></div></div><div class="bg-white dark:bg-gray-700 p-6 rounded-lg shadow-sm mb-8"${_scopeId}><h3 class="text-xl font-semibold text-gray-800 dark:text-gray-200 mb-4"${_scopeId}>Notice Board</h3><div class="space-y-4"${_scopeId}><div class="p-4 bg-gray-50 dark:bg-gray-600 rounded-lg"${_scopeId}><h4 class="text-lg font-semibold text-gray-700 dark:text-gray-200"${_scopeId}>Company Holiday Announcement</h4><p class="text-gray-600 dark:text-gray-300 mt-2"${_scopeId}>The company will be closed on December 25th and 26th for the Christmas holiday. Wishing everyone a joyful celebration!</p><p class="text-sm text-gray-500 dark:text-gray-400 mt-2"${_scopeId}>Posted on: December 20, 2023</p></div><div class="p-4 bg-gray-50 dark:bg-gray-600 rounded-lg"${_scopeId}><h4 class="text-lg font-semibold text-gray-700 dark:text-gray-200"${_scopeId}>New Policy Update</h4><p class="text-gray-600 dark:text-gray-300 mt-2"${_scopeId}>Starting January 1st, 2024, the company will implement a new remote work policy. Please review the updated guidelines in the employee handbook.</p><p class="text-sm text-gray-500 dark:text-gray-400 mt-2"${_scopeId}>Posted on: December 15, 2023</p></div><div class="p-4 bg-gray-50 dark:bg-gray-600 rounded-lg"${_scopeId}><h4 class="text-lg font-semibold text-gray-700 dark:text-gray-200"${_scopeId}>Team Building Event</h4><p class="text-gray-600 dark:text-gray-300 mt-2"${_scopeId}>Join us for a team-building event on December 22nd at 3 PM in the main conference room. Snacks and refreshments will be provided!</p><p class="text-sm text-gray-500 dark:text-gray-400 mt-2"${_scopeId}>Posted on: December 18, 2023</p></div></div></div><div class="bg-white dark:bg-gray-700 p-6 rounded-lg shadow-sm mb-8"${_scopeId}><h3 class="text-xl font-semibold text-gray-800 dark:text-gray-200 mb-4"${_scopeId}>Upcoming Events</h3><div class="space-y-4"${_scopeId}><div class="p-4 bg-gray-50 dark:bg-gray-600 rounded-lg"${_scopeId}><h4 class="text-lg font-semibold text-gray-700 dark:text-gray-200"${_scopeId}>Annual Company Dinner</h4><p class="text-gray-600 dark:text-gray-300 mt-2"${_scopeId}>Join us for the annual company dinner on January 10th, 2024, at 7 PM. Venue: Grand Ballroom, City Hotel.</p><p class="text-sm text-gray-500 dark:text-gray-400 mt-2"${_scopeId}>Date: January 10, 2024</p></div><div class="p-4 bg-gray-50 dark:bg-gray-600 rounded-lg"${_scopeId}><h4 class="text-lg font-semibold text-gray-700 dark:text-gray-200"${_scopeId}>Training Workshop</h4><p class="text-gray-600 dark:text-gray-300 mt-2"${_scopeId}>A training workshop on &quot;Effective Communication Skills&quot; will be held on January 15th, 2024, from 10 AM to 2 PM.</p><p class="text-sm text-gray-500 dark:text-gray-400 mt-2"${_scopeId}>Date: January 15, 2024</p></div></div></div><div class="bg-white dark:bg-gray-700 p-6 rounded-lg shadow-sm mb-8"${_scopeId}><h3 class="text-xl font-semibold text-gray-800 dark:text-gray-200 mb-4"${_scopeId}>Recent Employee Activity</h3><ul class="space-y-4"${_scopeId}><li class="flex items-center justify-between"${_scopeId}><span class="text-gray-600 dark:text-gray-300"${_scopeId}>John Doe updated their profile</span><span class="text-sm text-gray-500 dark:text-gray-400"${_scopeId}>2 hours ago</span></li><li class="flex items-center justify-between"${_scopeId}><span class="text-gray-600 dark:text-gray-300"${_scopeId}>Jane Smith completed a training session</span><span class="text-sm text-gray-500 dark:text-gray-400"${_scopeId}>5 hours ago</span></li><li class="flex items-center justify-between"${_scopeId}><span class="text-gray-600 dark:text-gray-300"${_scopeId}>New employee &quot;Alice Johnson&quot; onboarded</span><span class="text-sm text-gray-500 dark:text-gray-400"${_scopeId}>1 day ago</span></li></ul></div></div>`);
          } else {
            return [
              createVNode("div", { class: "p-6" }, [
                createVNode("div", { class: "grid grid-cols-1 md:grid-cols-3 gap-6 mb-8" }, [
                  createVNode("div", { class: "bg-white dark:bg-gray-700 p-6 rounded-lg shadow-sm" }, [
                    createVNode("h3", { class: "text-lg font-semibold text-gray-700 dark:text-gray-200" }, "Total Employees"),
                    createVNode("p", { class: "text-2xl font-bold text-gray-900 dark:text-gray-100" }, "256")
                  ]),
                  createVNode("div", { class: "bg-white dark:bg-gray-700 p-6 rounded-lg shadow-sm" }, [
                    createVNode("h3", { class: "text-lg font-semibold text-gray-700 dark:text-gray-200" }, "Active Employees"),
                    createVNode("p", { class: "text-2xl font-bold text-gray-900 dark:text-gray-100" }, "240")
                  ]),
                  createVNode("div", { class: "bg-white dark:bg-gray-700 p-6 rounded-lg shadow-sm" }, [
                    createVNode("h3", { class: "text-lg font-semibold text-gray-700 dark:text-gray-200" }, "New Hires (This Month)"),
                    createVNode("p", { class: "text-2xl font-bold text-gray-900 dark:text-gray-100" }, "8")
                  ])
                ]),
                createVNode("div", { class: "bg-white dark:bg-gray-700 p-6 rounded-lg shadow-sm mb-8" }, [
                  createVNode("h3", { class: "text-xl font-semibold text-gray-800 dark:text-gray-200 mb-4" }, "Notice Board"),
                  createVNode("div", { class: "space-y-4" }, [
                    createVNode("div", { class: "p-4 bg-gray-50 dark:bg-gray-600 rounded-lg" }, [
                      createVNode("h4", { class: "text-lg font-semibold text-gray-700 dark:text-gray-200" }, "Company Holiday Announcement"),
                      createVNode("p", { class: "text-gray-600 dark:text-gray-300 mt-2" }, "The company will be closed on December 25th and 26th for the Christmas holiday. Wishing everyone a joyful celebration!"),
                      createVNode("p", { class: "text-sm text-gray-500 dark:text-gray-400 mt-2" }, "Posted on: December 20, 2023")
                    ]),
                    createVNode("div", { class: "p-4 bg-gray-50 dark:bg-gray-600 rounded-lg" }, [
                      createVNode("h4", { class: "text-lg font-semibold text-gray-700 dark:text-gray-200" }, "New Policy Update"),
                      createVNode("p", { class: "text-gray-600 dark:text-gray-300 mt-2" }, "Starting January 1st, 2024, the company will implement a new remote work policy. Please review the updated guidelines in the employee handbook."),
                      createVNode("p", { class: "text-sm text-gray-500 dark:text-gray-400 mt-2" }, "Posted on: December 15, 2023")
                    ]),
                    createVNode("div", { class: "p-4 bg-gray-50 dark:bg-gray-600 rounded-lg" }, [
                      createVNode("h4", { class: "text-lg font-semibold text-gray-700 dark:text-gray-200" }, "Team Building Event"),
                      createVNode("p", { class: "text-gray-600 dark:text-gray-300 mt-2" }, "Join us for a team-building event on December 22nd at 3 PM in the main conference room. Snacks and refreshments will be provided!"),
                      createVNode("p", { class: "text-sm text-gray-500 dark:text-gray-400 mt-2" }, "Posted on: December 18, 2023")
                    ])
                  ])
                ]),
                createVNode("div", { class: "bg-white dark:bg-gray-700 p-6 rounded-lg shadow-sm mb-8" }, [
                  createVNode("h3", { class: "text-xl font-semibold text-gray-800 dark:text-gray-200 mb-4" }, "Upcoming Events"),
                  createVNode("div", { class: "space-y-4" }, [
                    createVNode("div", { class: "p-4 bg-gray-50 dark:bg-gray-600 rounded-lg" }, [
                      createVNode("h4", { class: "text-lg font-semibold text-gray-700 dark:text-gray-200" }, "Annual Company Dinner"),
                      createVNode("p", { class: "text-gray-600 dark:text-gray-300 mt-2" }, "Join us for the annual company dinner on January 10th, 2024, at 7 PM. Venue: Grand Ballroom, City Hotel."),
                      createVNode("p", { class: "text-sm text-gray-500 dark:text-gray-400 mt-2" }, "Date: January 10, 2024")
                    ]),
                    createVNode("div", { class: "p-4 bg-gray-50 dark:bg-gray-600 rounded-lg" }, [
                      createVNode("h4", { class: "text-lg font-semibold text-gray-700 dark:text-gray-200" }, "Training Workshop"),
                      createVNode("p", { class: "text-gray-600 dark:text-gray-300 mt-2" }, 'A training workshop on "Effective Communication Skills" will be held on January 15th, 2024, from 10 AM to 2 PM.'),
                      createVNode("p", { class: "text-sm text-gray-500 dark:text-gray-400 mt-2" }, "Date: January 15, 2024")
                    ])
                  ])
                ]),
                createVNode("div", { class: "bg-white dark:bg-gray-700 p-6 rounded-lg shadow-sm mb-8" }, [
                  createVNode("h3", { class: "text-xl font-semibold text-gray-800 dark:text-gray-200 mb-4" }, "Recent Employee Activity"),
                  createVNode("ul", { class: "space-y-4" }, [
                    createVNode("li", { class: "flex items-center justify-between" }, [
                      createVNode("span", { class: "text-gray-600 dark:text-gray-300" }, "John Doe updated their profile"),
                      createVNode("span", { class: "text-sm text-gray-500 dark:text-gray-400" }, "2 hours ago")
                    ]),
                    createVNode("li", { class: "flex items-center justify-between" }, [
                      createVNode("span", { class: "text-gray-600 dark:text-gray-300" }, "Jane Smith completed a training session"),
                      createVNode("span", { class: "text-sm text-gray-500 dark:text-gray-400" }, "5 hours ago")
                    ]),
                    createVNode("li", { class: "flex items-center justify-between" }, [
                      createVNode("span", { class: "text-gray-600 dark:text-gray-300" }, 'New employee "Alice Johnson" onboarded'),
                      createVNode("span", { class: "text-sm text-gray-500 dark:text-gray-400" }, "1 day ago")
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/db.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
