import { defineComponent, unref, withCtx, createVNode, useSSRContext } from "vue";
import { ssrRenderComponent } from "vue/server-renderer";
import { A as AuthenticatedLayout } from "./AuthenticatedLayout-BMQt65oV.js";
import { Head } from "@inertiajs/vue3";
import "laravel-permission-to-vuejs";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Finance",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Finance" }, null, _parent));
      _push(ssrRenderComponent(AuthenticatedLayout, null, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<h2 class="text-2xl font-bold leading-tight text-gray-800 dark:text-gray-200"${_scopeId}>Financial Management</h2>`);
          } else {
            return [
              createVNode("h2", { class: "text-2xl font-bold leading-tight text-gray-800 dark:text-gray-200" }, "Financial Management")
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="flex flex-col items-center justify-center h-[70vh] text-center"${_scopeId}><div class="relative w-16 h-16"${_scopeId}><div class="absolute inset-0 border-4 border-gray-300 dark:border-gray-600 rounded-full"${_scopeId}></div><div class="absolute inset-0 border-t-4 border-green-500 rounded-full animate-spin"${_scopeId}></div></div><h3 class="mt-6 text-2xl font-semibold text-gray-800 dark:text-gray-200"${_scopeId}> Page Under Development </h3><p class="mt-2 text-gray-600 dark:text-gray-400 max-w-md"${_scopeId}> We are currently working on this section to improve your experience. Please check back soon for updates. </p></div>`);
          } else {
            return [
              createVNode("div", { class: "flex flex-col items-center justify-center h-[70vh] text-center" }, [
                createVNode("div", { class: "relative w-16 h-16" }, [
                  createVNode("div", { class: "absolute inset-0 border-4 border-gray-300 dark:border-gray-600 rounded-full" }),
                  createVNode("div", { class: "absolute inset-0 border-t-4 border-green-500 rounded-full animate-spin" })
                ]),
                createVNode("h3", { class: "mt-6 text-2xl font-semibold text-gray-800 dark:text-gray-200" }, " Page Under Development "),
                createVNode("p", { class: "mt-2 text-gray-600 dark:text-gray-400 max-w-md" }, " We are currently working on this section to improve your experience. Please check back soon for updates. ")
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Finance.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
