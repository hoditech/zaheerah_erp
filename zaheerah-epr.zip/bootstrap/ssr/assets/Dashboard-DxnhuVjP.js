import { defineComponent, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrInterpolate } from "vue/server-renderer";
import _sfc_main$1 from "./SummaryCard-Be4td-xb.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Dashboard",
  __ssrInlineRender: true,
  props: {
    totalRevenue: String,
    totalCost: String,
    totalProfit: String,
    categories: Array
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}><h3 class="text-2xl font-semibold mb-4">Dashboard</h3><div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        title: "Total Revenue",
        value: __props.totalRevenue,
        color: "text-orange-500"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, {
        title: "Total Cost",
        value: __props.totalCost,
        color: "text-red-500"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, {
        title: "Net Profit",
        value: __props.totalProfit,
        color: "text-green-500"
      }, null, _parent));
      _push(`</div><div class="bg-white dark:bg-gray-800 shadow-lg rounded-lg p-6 mb-6"><h4 class="text-lg font-semibold text-gray-700 dark:text-gray-200 mb-4">Category Breakdown</h4><table class="w-full border-collapse"><thead><tr class="bg-gray-200 dark:bg-gray-700"><th class="py-3 px-4 text-left">Category</th><th class="py-3 px-4 text-left">Revenue</th><th class="py-3 px-4 text-left">Cost</th><th class="py-3 px-4 text-left">Profit</th><th class="py-3 px-4 text-left">Inventory</th></tr></thead><tbody><!--[-->`);
      ssrRenderList(__props.categories, (category) => {
        _push(`<tr class="border-t border-gray-300 dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700"><td class="py-3 px-4">${ssrInterpolate(category.name)}</td><td class="py-3 px-4">${ssrInterpolate(category.revenue)}</td><td class="py-3 px-4">${ssrInterpolate(category.cost)}</td><td class="py-3 px-4">${ssrInterpolate(category.profit)}</td><td class="py-3 px-4">${ssrInterpolate(category.inventory)}</td></tr>`);
      });
      _push(`<!--]--></tbody></table></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/finance/Components/Dashboard.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
