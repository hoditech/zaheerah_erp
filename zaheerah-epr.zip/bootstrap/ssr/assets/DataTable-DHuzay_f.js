import { defineComponent, ref, computed, watch, mergeProps, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderList, ssrInterpolate, ssrRenderClass, ssrIncludeBooleanAttr } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-1tPrXgE0.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "DataTable",
  __ssrInlineRender: true,
  props: {
    columns: {},
    data: {},
    searchQuery: {},
    actions: {},
    pageSize: {}
  },
  setup(__props) {
    const props = __props;
    const currentPage = ref(1);
    const pageSize = ref(props.pageSize || 10);
    const totalItems = computed(() => filteredData.value.length);
    const totalPages = computed(() => Math.ceil(totalItems.value / pageSize.value));
    const resolveNestedKey = (obj, key) => {
      return key.split(".").reduce((acc, part) => acc && acc[part], obj);
    };
    const filteredData = computed(() => {
      return props.data.filter(
        (item) => props.columns.some(
          (column) => {
            var _a;
            return (_a = resolveNestedKey(item, column.key)) == null ? void 0 : _a.toString().toLowerCase().includes(props.searchQuery.toLowerCase());
          }
        )
      );
    });
    const paginatedData = computed(() => {
      const start = (currentPage.value - 1) * pageSize.value;
      const end = start + pageSize.value;
      return filteredData.value.slice(start, end);
    });
    watch(
      () => props.searchQuery,
      () => currentPage.value = 1
    );
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden" }, _attrs))} data-v-e021caca><table class="min-w-full bg-white dark:bg-gray-800 rounded-lg overflow-hidden" data-v-e021caca><thead data-v-e021caca><tr class="bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 text-sm font-semibold uppercase tracking-wide" data-v-e021caca><!--[-->`);
      ssrRenderList(_ctx.columns, (column) => {
        _push(`<th class="px-6 py-4 border-b text-left" data-v-e021caca>${ssrInterpolate(column.label)}</th>`);
      });
      _push(`<!--]-->`);
      if (_ctx.actions) {
        _push(`<th class="px-6 py-4 border-b text-left" data-v-e021caca>Actions</th>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</tr></thead><tbody data-v-e021caca><!--[-->`);
      ssrRenderList(paginatedData.value, (row) => {
        _push(`<tr class="hover:bg-gray-50 dark:hover:bg-gray-700 transition" data-v-e021caca><!--[-->`);
        ssrRenderList(_ctx.columns, (column) => {
          _push(`<td class="px-6 py-4 border-b text-gray-700 dark:text-gray-300" data-v-e021caca>${ssrInterpolate(resolveNestedKey(row, column.key))}</td>`);
        });
        _push(`<!--]-->`);
        if (_ctx.actions) {
          _push(`<td class="px-6 py-4 border-b" data-v-e021caca><!--[-->`);
          ssrRenderList(_ctx.actions, (action) => {
            _push(`<button class="${ssrRenderClass([action.class, "text-xs font-medium px-3 py-1 rounded-md"])}" data-v-e021caca>${ssrInterpolate(action.label)}</button>`);
          });
          _push(`<!--]--></td>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</tr>`);
      });
      _push(`<!--]--></tbody></table><div class="mt-4 flex items-center justify-between px-6 py-4 bg-gray-100 dark:bg-gray-700 border-t" data-v-e021caca><div class="text-sm" data-v-e021caca> Showing ${ssrInterpolate((currentPage.value - 1) * pageSize.value + 1)} to ${ssrInterpolate(Math.min(currentPage.value * pageSize.value, totalItems.value))} of ${ssrInterpolate(totalItems.value)} results </div><div class="flex items-center space-x-1" data-v-e021caca><button${ssrIncludeBooleanAttr(currentPage.value === 1) ? " disabled" : ""} class="btn" data-v-e021caca>First</button><button${ssrIncludeBooleanAttr(currentPage.value === 1) ? " disabled" : ""} class="btn" data-v-e021caca>Prev</button><span data-v-e021caca>Page ${ssrInterpolate(currentPage.value)} of ${ssrInterpolate(totalPages.value)}</span><button${ssrIncludeBooleanAttr(currentPage.value === totalPages.value) ? " disabled" : ""} class="btn" data-v-e021caca>Next</button><button${ssrIncludeBooleanAttr(currentPage.value === totalPages.value) ? " disabled" : ""} class="btn" data-v-e021caca>Last</button></div></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/DataTable.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const DataTable = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-e021caca"]]);
export {
  DataTable as D
};
