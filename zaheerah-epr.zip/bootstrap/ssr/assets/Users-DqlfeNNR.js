import { defineComponent, ref, resolveComponent, unref, withCtx, createVNode, createTextVNode, withDirectives, vModelText, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderAttr } from "vue/server-renderer";
import { A as AuthenticatedLayout } from "./AuthenticatedLayout-GMSouBjC.js";
import { Head } from "@inertiajs/vue3";
import { D as DataTable } from "./DataTable-Bf1VUkR3.js";
import "laravel-permission-to-vuejs";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Users",
  __ssrInlineRender: true,
  setup(__props) {
    const users = ref([
      { id: 1, name: "Yahaya Hudu", email: "huduyahaya@gmail.com", role: "Admin", status: "Active" }
    ]);
    const columns = [
      { label: "ID", key: "id" },
      { label: "Name", key: "name" },
      { label: "Email", key: "email" },
      { label: "Role", key: "role" },
      { label: "Status", key: "status" }
    ];
    const searchQuery = ref("");
    const deleteUser = (user) => {
      users.value = users.value.filter((u) => u.id !== user.id);
    };
    const actions = [
      { label: "Delete", onClick: deleteUser, class: "text-red-600 hover:text-red-900" },
      {
        label: "Edit",
        onClick: (user) => console.log("Edit", user),
        class: "text-blue-600 hover:text-blue-900"
      }
    ];
    return (_ctx, _push, _parent, _attrs) => {
      const _component_router_link = resolveComponent("router-link");
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "User Management" }, null, _parent));
      _push(ssrRenderComponent(AuthenticatedLayout, null, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<h2 class="text-2xl font-bold leading-tight text-gray-800 dark:text-gray-200"${_scopeId}>User Management</h2>`);
          } else {
            return [
              createVNode("h2", { class: "text-2xl font-bold leading-tight text-gray-800 dark:text-gray-200" }, "User Management")
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="py-6"${_scopeId}><div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8"${_scopeId}><div class="flex justify-between items-center mb-6"${_scopeId}><div class="relative w-1/3"${_scopeId}><input${ssrRenderAttr("value", searchQuery.value)} type="text" placeholder="Search users..." class="w-full p-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring focus:ring-green-500 dark:bg-gray-700 dark:border-gray-600 dark:text-gray-300"${_scopeId}></div>`);
            _push2(ssrRenderComponent(_component_router_link, {
              to: "/users/new",
              class: "inline-flex items-center px-4 py-2 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-md shadow-md transition duration-300 ease-in-out"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` New User `);
                } else {
                  return [
                    createTextVNode(" New User ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div>`);
            _push2(ssrRenderComponent(DataTable, {
              columns,
              data: users.value,
              searchQuery: searchQuery.value,
              actions,
              pageSize: 2
            }, null, _parent2, _scopeId));
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", { class: "py-6" }, [
                createVNode("div", { class: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8" }, [
                  createVNode("div", { class: "flex justify-between items-center mb-6" }, [
                    createVNode("div", { class: "relative w-1/3" }, [
                      withDirectives(createVNode("input", {
                        "onUpdate:modelValue": ($event) => searchQuery.value = $event,
                        type: "text",
                        placeholder: "Search users...",
                        class: "w-full p-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring focus:ring-green-500 dark:bg-gray-700 dark:border-gray-600 dark:text-gray-300"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, searchQuery.value]
                      ])
                    ]),
                    createVNode(_component_router_link, {
                      to: "/users/new",
                      class: "inline-flex items-center px-4 py-2 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-md shadow-md transition duration-300 ease-in-out"
                    }, {
                      default: withCtx(() => [
                        createTextVNode(" New User ")
                      ]),
                      _: 1
                    })
                  ]),
                  createVNode(DataTable, {
                    columns,
                    data: users.value,
                    searchQuery: searchQuery.value,
                    actions,
                    pageSize: 2
                  }, null, 8, ["data", "searchQuery"])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Users.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
