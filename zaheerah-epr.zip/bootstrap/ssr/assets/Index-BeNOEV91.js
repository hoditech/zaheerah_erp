import { defineComponent, ref, unref, withCtx, createVNode, openBlock, createBlock, toDisplayString, createCommentVNode, withDirectives, vModelText, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderAttr } from "vue/server-renderer";
import { A as AuthenticatedLayout } from "./AuthenticatedLayout-BMQt65oV.js";
import { Head, router } from "@inertiajs/vue3";
import { D as DataTable } from "./DataTable-Bf1VUkR3.js";
import { is } from "laravel-permission-to-vuejs";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Index",
  __ssrInlineRender: true,
  props: {
    employees: {
      type: Array,
      required: false,
      default: () => []
    }
  },
  setup(__props) {
    const props = __props;
    const formattedEmployees = props.employees.map((employee) => ({
      ...employee,
      roles: employee.roles.map((role) => role.name).join(", ")
    }));
    const columns = [
      { label: "Name", key: "name" },
      { label: "Email", key: "email" },
      { label: "Phone", key: "phone" },
      { label: "Roles", key: "roles" },
      { label: "Category", key: "category.name" }
    ];
    const searchQuery = ref("");
    const deleteEmployee = (employee) => {
      if (confirm(`Are you sure you want to delete ${employee.name}?`)) {
        router.delete(route("employees.destroy", employee.id), {
          onSuccess: () => {
            console.log(`${employee.name} has been deleted successfully.`);
          }
        });
        employee.value = employee.value.filter((e) => e.id !== employee.id);
      }
    };
    const editEmployee = (employee) => {
      router.visit(route("employees.edit", employee.id));
    };
    let actions = [];
    if (is("Super Admin")) {
      actions = [
        {
          label: "Edit",
          onClick: editEmployee,
          class: "text-blue-600 hover:text-blue-900"
        },
        {
          label: "Delete",
          onClick: deleteEmployee,
          class: "text-red-600 hover:text-red-900"
        }
      ];
    }
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Employee Management" }, null, _parent));
      _push(ssrRenderComponent(AuthenticatedLayout, null, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<h2 class="text-2xl font-bold leading-tight text-gray-800 dark:text-gray-200"${_scopeId}>Employee Management</h2>`);
          } else {
            return [
              createVNode("h2", { class: "text-2xl font-bold leading-tight text-gray-800 dark:text-gray-200" }, "Employee Management")
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="py-6"${_scopeId}><div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8"${_scopeId}>`);
            if (_ctx.$page.props.flash.success) {
              _push2(`<div class="bg-green-100 text-green-700 px-4 py-2 rounded mb-4"${_scopeId}>${ssrInterpolate(_ctx.$page.props.flash.success)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div class="flex justify-between items-center mb-6"${_scopeId}><div class="relative w-1/3"${_scopeId}><input${ssrRenderAttr("value", searchQuery.value)} type="text" placeholder="Search employees..." class="w-full p-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring focus:ring-green-500 dark:bg-gray-700 dark:border-gray-600 dark:text-gray-300"${_scopeId}></div>`);
            if (unref(is)("Super Admin | HR")) {
              _push2(`<button class="inline-flex items-center px-4 py-2 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-md shadow-md transition duration-300 ease-in-out"${_scopeId}> Add Employee </button>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div>`);
            _push2(ssrRenderComponent(DataTable, {
              columns,
              data: unref(formattedEmployees),
              searchQuery: searchQuery.value,
              actions: unref(actions),
              pageSize: 5
            }, null, _parent2, _scopeId));
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", { class: "py-6" }, [
                createVNode("div", { class: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8" }, [
                  _ctx.$page.props.flash.success ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: "bg-green-100 text-green-700 px-4 py-2 rounded mb-4"
                  }, toDisplayString(_ctx.$page.props.flash.success), 1)) : createCommentVNode("", true),
                  createVNode("div", { class: "flex justify-between items-center mb-6" }, [
                    createVNode("div", { class: "relative w-1/3" }, [
                      withDirectives(createVNode("input", {
                        "onUpdate:modelValue": ($event) => searchQuery.value = $event,
                        type: "text",
                        placeholder: "Search employees...",
                        class: "w-full p-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring focus:ring-green-500 dark:bg-gray-700 dark:border-gray-600 dark:text-gray-300"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, searchQuery.value]
                      ])
                    ]),
                    unref(is)("Super Admin | HR") ? (openBlock(), createBlock("button", {
                      key: 0,
                      onClick: ($event) => _ctx.$inertia.visit(_ctx.route("employees.create")),
                      class: "inline-flex items-center px-4 py-2 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-md shadow-md transition duration-300 ease-in-out"
                    }, " Add Employee ", 8, ["onClick"])) : createCommentVNode("", true)
                  ]),
                  createVNode(DataTable, {
                    columns,
                    data: unref(formattedEmployees),
                    searchQuery: searchQuery.value,
                    actions: unref(actions),
                    pageSize: 5
                  }, null, 8, ["data", "searchQuery", "actions"])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/HR/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
