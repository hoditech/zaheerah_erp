import { defineComponent, ref, withCtx, createVNode, withDirectives, vModelText, openBlock, createBlock, Fragment, renderList, toDisplayString, vModelCheckbox, vModelSelect, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderAttr, ssrRenderList, ssrInterpolate, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual } from "vue/server-renderer";
import { A as AuthenticatedLayout } from "./AuthenticatedLayout-GMSouBjC.js";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-1tPrXgE0.js";
import "@inertiajs/vue3";
import "laravel-permission-to-vuejs";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Settings",
  __ssrInlineRender: true,
  setup(__props) {
    var _a;
    const newUser = ref("");
    const users = ref([{ id: 1, email: "user1@example.com" }, { id: 2, email: "user2@example.com" }]);
    const modules = ref({
      sales: false,
      inventory: false,
      crm: false
    });
    const selectedUser = ref((_a = users.value[0]) == null ? void 0 : _a.id);
    const userPermissions = ref({
      view: false,
      edit: false
    });
    const systemSettings = ref({
      currency: "USD",
      language: "en"
    });
    const addUser = () => {
      if (newUser.value) {
        users.value.push({ id: Date.now(), email: newUser.value });
        newUser.value = "";
      }
    };
    const removeUser = (id) => {
      users.value = users.value.filter((user) => user.id !== id);
    };
    const saveModules = () => {
      alert("Module settings saved!");
    };
    const savePermissions = () => {
      alert(`Permissions for user ${selectedUser.value} saved!`);
    };
    const saveSystemSettings = () => {
      alert("System preferences saved!");
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(AuthenticatedLayout, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="bg-white dark:bg-gray-800 min-h-screen p-6" data-v-735ba984${_scopeId}><h2 class="text-3xl font-bold text-gray-800 dark:text-gray-200 mb-6" data-v-735ba984${_scopeId}>ERP Settings</h2><div class="grid grid-cols-1 md:grid-cols-2 gap-6" data-v-735ba984${_scopeId}><section class="bg-gray-100 dark:bg-gray-700 rounded-lg shadow-md p-6" data-v-735ba984${_scopeId}><h3 class="text-xl font-semibold text-gray-800 dark:text-gray-200 mb-4" data-v-735ba984${_scopeId}>User Management</h3><div class="space-y-4" data-v-735ba984${_scopeId}><div data-v-735ba984${_scopeId}><label class="block text-gray-700 dark:text-gray-300 mb-1" data-v-735ba984${_scopeId}>Add User</label><input type="text"${ssrRenderAttr("value", newUser.value)} placeholder="Enter user email" class="w-full p-3 border border-gray-300 rounded-lg dark:bg-gray-600 dark:border-gray-500 dark:text-gray-200" data-v-735ba984${_scopeId}><button class="mt-2 w-full py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg transition" data-v-735ba984${_scopeId}>Add User</button></div><div data-v-735ba984${_scopeId}><h4 class="font-semibold text-gray-700 dark:text-gray-300" data-v-735ba984${_scopeId}>Existing Users:</h4><ul data-v-735ba984${_scopeId}><!--[-->`);
            ssrRenderList(users.value, (user) => {
              _push2(`<li class="flex justify-between items-center border-b border-gray-300 dark:border-gray-500 py-2" data-v-735ba984${_scopeId}><span data-v-735ba984${_scopeId}>${ssrInterpolate(user.email)}</span><button class="text-red-600 hover:text-red-700" data-v-735ba984${_scopeId}>Remove</button></li>`);
            });
            _push2(`<!--]--></ul></div></div></section><section class="bg-gray-100 dark:bg-gray-700 rounded-lg shadow-md p-6" data-v-735ba984${_scopeId}><h3 class="text-xl font-semibold text-gray-800 dark:text-gray-200 mb-4" data-v-735ba984${_scopeId}>Module Settings</h3><div class="space-y-4" data-v-735ba984${_scopeId}><div class="flex items-center" data-v-735ba984${_scopeId}><input type="checkbox"${ssrIncludeBooleanAttr(Array.isArray(modules.value.sales) ? ssrLooseContain(modules.value.sales, null) : modules.value.sales) ? " checked" : ""} class="mr-2" data-v-735ba984${_scopeId}><label class="text-gray-700 dark:text-gray-300" data-v-735ba984${_scopeId}>Sales Module</label></div><div class="flex items-center" data-v-735ba984${_scopeId}><input type="checkbox"${ssrIncludeBooleanAttr(Array.isArray(modules.value.inventory) ? ssrLooseContain(modules.value.inventory, null) : modules.value.inventory) ? " checked" : ""} class="mr-2" data-v-735ba984${_scopeId}><label class="text-gray-700 dark:text-gray-300" data-v-735ba984${_scopeId}>Inventory Module</label></div><div class="flex items-center" data-v-735ba984${_scopeId}><input type="checkbox"${ssrIncludeBooleanAttr(Array.isArray(modules.value.crm) ? ssrLooseContain(modules.value.crm, null) : modules.value.crm) ? " checked" : ""} class="mr-2" data-v-735ba984${_scopeId}><label class="text-gray-700 dark:text-gray-300" data-v-735ba984${_scopeId}>CRM Module</label></div><button class="mt-4 w-full py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg transition" data-v-735ba984${_scopeId}>Save Module Settings</button></div></section><section class="bg-gray-100 dark:bg-gray-700 rounded-lg shadow-md p-6" data-v-735ba984${_scopeId}><h3 class="text-xl font-semibold text-gray-800 dark:text-gray-200 mb-4" data-v-735ba984${_scopeId}>Permission Management</h3><div class="space-y-4" data-v-735ba984${_scopeId}><div data-v-735ba984${_scopeId}><label class="block text-gray-700 dark:text-gray-300 mb-1" data-v-735ba984${_scopeId}>Select User</label><select class="w-full p-3 border border-gray-300 rounded-lg dark:bg-gray-600 dark:border-gray-500 dark:text-gray-200" data-v-735ba984${_scopeId}><!--[-->`);
            ssrRenderList(users.value, (user) => {
              _push2(`<option${ssrRenderAttr("value", user.id)} data-v-735ba984${_scopeId}>${ssrInterpolate(user.email)}</option>`);
            });
            _push2(`<!--]--></select></div><div class="flex items-center" data-v-735ba984${_scopeId}><input type="checkbox"${ssrIncludeBooleanAttr(Array.isArray(userPermissions.value.view) ? ssrLooseContain(userPermissions.value.view, null) : userPermissions.value.view) ? " checked" : ""} class="mr-2" data-v-735ba984${_scopeId}><label class="text-gray-700 dark:text-gray-300" data-v-735ba984${_scopeId}>View Permissions</label></div><div class="flex items-center" data-v-735ba984${_scopeId}><input type="checkbox"${ssrIncludeBooleanAttr(Array.isArray(userPermissions.value.edit) ? ssrLooseContain(userPermissions.value.edit, null) : userPermissions.value.edit) ? " checked" : ""} class="mr-2" data-v-735ba984${_scopeId}><label class="text-gray-700 dark:text-gray-300" data-v-735ba984${_scopeId}>Edit Permissions</label></div><button class="mt-4 w-full py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg transition" data-v-735ba984${_scopeId}>Save Permissions</button></div></section><section class="bg-gray-100 dark:bg-gray-700 rounded-lg shadow-md p-6" data-v-735ba984${_scopeId}><h3 class="text-xl font-semibold text-gray-800 dark:text-gray-200 mb-4" data-v-735ba984${_scopeId}>System Preferences</h3><div class="space-y-4" data-v-735ba984${_scopeId}><div data-v-735ba984${_scopeId}><label class="block text-gray-700 dark:text-gray-300 mb-1" data-v-735ba984${_scopeId}>Currency</label><select class="w-full p-3 border border-gray-300 rounded-lg dark:bg-gray-600 dark:border-gray-500 dark:text-gray-200" data-v-735ba984${_scopeId}><option value="USD" data-v-735ba984${ssrIncludeBooleanAttr(Array.isArray(systemSettings.value.currency) ? ssrLooseContain(systemSettings.value.currency, "USD") : ssrLooseEqual(systemSettings.value.currency, "USD")) ? " selected" : ""}${_scopeId}>USD</option><option value="EUR" data-v-735ba984${ssrIncludeBooleanAttr(Array.isArray(systemSettings.value.currency) ? ssrLooseContain(systemSettings.value.currency, "EUR") : ssrLooseEqual(systemSettings.value.currency, "EUR")) ? " selected" : ""}${_scopeId}>EUR</option><option value="GBP" data-v-735ba984${ssrIncludeBooleanAttr(Array.isArray(systemSettings.value.currency) ? ssrLooseContain(systemSettings.value.currency, "GBP") : ssrLooseEqual(systemSettings.value.currency, "GBP")) ? " selected" : ""}${_scopeId}>GBP</option></select></div><div data-v-735ba984${_scopeId}><label class="block text-gray-700 dark:text-gray-300 mb-1" data-v-735ba984${_scopeId}>Default Language</label><select class="w-full p-3 border border-gray-300 rounded-lg dark:bg-gray-600 dark:border-gray-500 dark:text-gray-200" data-v-735ba984${_scopeId}><option value="en" data-v-735ba984${ssrIncludeBooleanAttr(Array.isArray(systemSettings.value.language) ? ssrLooseContain(systemSettings.value.language, "en") : ssrLooseEqual(systemSettings.value.language, "en")) ? " selected" : ""}${_scopeId}>English</option><option value="fr" data-v-735ba984${ssrIncludeBooleanAttr(Array.isArray(systemSettings.value.language) ? ssrLooseContain(systemSettings.value.language, "fr") : ssrLooseEqual(systemSettings.value.language, "fr")) ? " selected" : ""}${_scopeId}>French</option><option value="es" data-v-735ba984${ssrIncludeBooleanAttr(Array.isArray(systemSettings.value.language) ? ssrLooseContain(systemSettings.value.language, "es") : ssrLooseEqual(systemSettings.value.language, "es")) ? " selected" : ""}${_scopeId}>Spanish</option></select></div><button class="mt-4 w-full py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg transition" data-v-735ba984${_scopeId}>Save System Preferences</button></div></section></div></div>`);
          } else {
            return [
              createVNode("div", { class: "bg-white dark:bg-gray-800 min-h-screen p-6" }, [
                createVNode("h2", { class: "text-3xl font-bold text-gray-800 dark:text-gray-200 mb-6" }, "ERP Settings"),
                createVNode("div", { class: "grid grid-cols-1 md:grid-cols-2 gap-6" }, [
                  createVNode("section", { class: "bg-gray-100 dark:bg-gray-700 rounded-lg shadow-md p-6" }, [
                    createVNode("h3", { class: "text-xl font-semibold text-gray-800 dark:text-gray-200 mb-4" }, "User Management"),
                    createVNode("div", { class: "space-y-4" }, [
                      createVNode("div", null, [
                        createVNode("label", { class: "block text-gray-700 dark:text-gray-300 mb-1" }, "Add User"),
                        withDirectives(createVNode("input", {
                          type: "text",
                          "onUpdate:modelValue": ($event) => newUser.value = $event,
                          placeholder: "Enter user email",
                          class: "w-full p-3 border border-gray-300 rounded-lg dark:bg-gray-600 dark:border-gray-500 dark:text-gray-200"
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, newUser.value]
                        ]),
                        createVNode("button", {
                          onClick: addUser,
                          class: "mt-2 w-full py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg transition"
                        }, "Add User")
                      ]),
                      createVNode("div", null, [
                        createVNode("h4", { class: "font-semibold text-gray-700 dark:text-gray-300" }, "Existing Users:"),
                        createVNode("ul", null, [
                          (openBlock(true), createBlock(Fragment, null, renderList(users.value, (user) => {
                            return openBlock(), createBlock("li", {
                              key: user.id,
                              class: "flex justify-between items-center border-b border-gray-300 dark:border-gray-500 py-2"
                            }, [
                              createVNode("span", null, toDisplayString(user.email), 1),
                              createVNode("button", {
                                onClick: ($event) => removeUser(user.id),
                                class: "text-red-600 hover:text-red-700"
                              }, "Remove", 8, ["onClick"])
                            ]);
                          }), 128))
                        ])
                      ])
                    ])
                  ]),
                  createVNode("section", { class: "bg-gray-100 dark:bg-gray-700 rounded-lg shadow-md p-6" }, [
                    createVNode("h3", { class: "text-xl font-semibold text-gray-800 dark:text-gray-200 mb-4" }, "Module Settings"),
                    createVNode("div", { class: "space-y-4" }, [
                      createVNode("div", { class: "flex items-center" }, [
                        withDirectives(createVNode("input", {
                          type: "checkbox",
                          "onUpdate:modelValue": ($event) => modules.value.sales = $event,
                          class: "mr-2"
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelCheckbox, modules.value.sales]
                        ]),
                        createVNode("label", { class: "text-gray-700 dark:text-gray-300" }, "Sales Module")
                      ]),
                      createVNode("div", { class: "flex items-center" }, [
                        withDirectives(createVNode("input", {
                          type: "checkbox",
                          "onUpdate:modelValue": ($event) => modules.value.inventory = $event,
                          class: "mr-2"
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelCheckbox, modules.value.inventory]
                        ]),
                        createVNode("label", { class: "text-gray-700 dark:text-gray-300" }, "Inventory Module")
                      ]),
                      createVNode("div", { class: "flex items-center" }, [
                        withDirectives(createVNode("input", {
                          type: "checkbox",
                          "onUpdate:modelValue": ($event) => modules.value.crm = $event,
                          class: "mr-2"
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelCheckbox, modules.value.crm]
                        ]),
                        createVNode("label", { class: "text-gray-700 dark:text-gray-300" }, "CRM Module")
                      ]),
                      createVNode("button", {
                        onClick: saveModules,
                        class: "mt-4 w-full py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg transition"
                      }, "Save Module Settings")
                    ])
                  ]),
                  createVNode("section", { class: "bg-gray-100 dark:bg-gray-700 rounded-lg shadow-md p-6" }, [
                    createVNode("h3", { class: "text-xl font-semibold text-gray-800 dark:text-gray-200 mb-4" }, "Permission Management"),
                    createVNode("div", { class: "space-y-4" }, [
                      createVNode("div", null, [
                        createVNode("label", { class: "block text-gray-700 dark:text-gray-300 mb-1" }, "Select User"),
                        withDirectives(createVNode("select", {
                          "onUpdate:modelValue": ($event) => selectedUser.value = $event,
                          class: "w-full p-3 border border-gray-300 rounded-lg dark:bg-gray-600 dark:border-gray-500 dark:text-gray-200"
                        }, [
                          (openBlock(true), createBlock(Fragment, null, renderList(users.value, (user) => {
                            return openBlock(), createBlock("option", {
                              key: user.id,
                              value: user.id
                            }, toDisplayString(user.email), 9, ["value"]);
                          }), 128))
                        ], 8, ["onUpdate:modelValue"]), [
                          [vModelSelect, selectedUser.value]
                        ])
                      ]),
                      createVNode("div", { class: "flex items-center" }, [
                        withDirectives(createVNode("input", {
                          type: "checkbox",
                          "onUpdate:modelValue": ($event) => userPermissions.value.view = $event,
                          class: "mr-2"
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelCheckbox, userPermissions.value.view]
                        ]),
                        createVNode("label", { class: "text-gray-700 dark:text-gray-300" }, "View Permissions")
                      ]),
                      createVNode("div", { class: "flex items-center" }, [
                        withDirectives(createVNode("input", {
                          type: "checkbox",
                          "onUpdate:modelValue": ($event) => userPermissions.value.edit = $event,
                          class: "mr-2"
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelCheckbox, userPermissions.value.edit]
                        ]),
                        createVNode("label", { class: "text-gray-700 dark:text-gray-300" }, "Edit Permissions")
                      ]),
                      createVNode("button", {
                        onClick: savePermissions,
                        class: "mt-4 w-full py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg transition"
                      }, "Save Permissions")
                    ])
                  ]),
                  createVNode("section", { class: "bg-gray-100 dark:bg-gray-700 rounded-lg shadow-md p-6" }, [
                    createVNode("h3", { class: "text-xl font-semibold text-gray-800 dark:text-gray-200 mb-4" }, "System Preferences"),
                    createVNode("div", { class: "space-y-4" }, [
                      createVNode("div", null, [
                        createVNode("label", { class: "block text-gray-700 dark:text-gray-300 mb-1" }, "Currency"),
                        withDirectives(createVNode("select", {
                          "onUpdate:modelValue": ($event) => systemSettings.value.currency = $event,
                          class: "w-full p-3 border border-gray-300 rounded-lg dark:bg-gray-600 dark:border-gray-500 dark:text-gray-200"
                        }, [
                          createVNode("option", { value: "USD" }, "USD"),
                          createVNode("option", { value: "EUR" }, "EUR"),
                          createVNode("option", { value: "GBP" }, "GBP")
                        ], 8, ["onUpdate:modelValue"]), [
                          [vModelSelect, systemSettings.value.currency]
                        ])
                      ]),
                      createVNode("div", null, [
                        createVNode("label", { class: "block text-gray-700 dark:text-gray-300 mb-1" }, "Default Language"),
                        withDirectives(createVNode("select", {
                          "onUpdate:modelValue": ($event) => systemSettings.value.language = $event,
                          class: "w-full p-3 border border-gray-300 rounded-lg dark:bg-gray-600 dark:border-gray-500 dark:text-gray-200"
                        }, [
                          createVNode("option", { value: "en" }, "English"),
                          createVNode("option", { value: "fr" }, "French"),
                          createVNode("option", { value: "es" }, "Spanish")
                        ], 8, ["onUpdate:modelValue"]), [
                          [vModelSelect, systemSettings.value.language]
                        ])
                      ]),
                      createVNode("button", {
                        onClick: saveSystemSettings,
                        class: "mt-4 w-full py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg transition"
                      }, "Save System Preferences")
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Settings.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Settings = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-735ba984"]]);
export {
  Settings as default
};
