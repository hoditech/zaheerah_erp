import { defineComponent, ref, computed, watch, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderList, ssrRenderAttr, ssrInterpolate, ssrIncludeBooleanAttr, ssrLooseContain } from "vue/server-renderer";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Reports",
  __ssrInlineRender: true,
  setup(__props) {
    const reportTypes = ref([
      { value: "sales", label: "Sales Report" },
      { value: "products", label: "Product Performance" },
      { value: "categories", label: "Category Sales" },
      { value: "inventory", label: "Inventory Status" },
      { value: "expiry", label: "Expiry Report" },
      { value: "stock-movement", label: "Stock Movement" }
    ]);
    const selectedReport = ref("sales");
    const dateRange = ref({ start: "", end: "" });
    const expiryThreshold = ref(30);
    const reports = ref([]);
    const selectedColumns = ref([]);
    const isLoading = ref(false);
    const reportColumns = {
      sales: [
        { value: "transaction_id", label: "Transaction ID" },
        { value: "date", label: "Date" },
        { value: "total_amount", label: "Total Amount" },
        { value: "items_count", label: "Items Sold" }
      ],
      products: [
        { value: "product_name", label: "Product Name" },
        { value: "category", label: "Category" },
        { value: "total_sold", label: "Units Sold" },
        { value: "total_revenue", label: "Revenue" }
      ],
      categories: [
        { value: "category_name", label: "Category" },
        { value: "total_quantity", label: "Units Sold" },
        { value: "total_revenue", label: "Revenue" }
      ],
      inventory: [
        { value: "product_name", label: "Product" },
        { value: "category", label: "Category" },
        { value: "remaining_units", label: "Stock" },
        { value: "supplier", label: "Supplier" }
      ],
      expiry: [
        { value: "product_name", label: "Product" },
        { value: "exp_date", label: "Expiry Date" },
        { value: "remaining_units", label: "Stock" },
        { value: "days_until_expiry", label: "Days Until Expiry" }
      ],
      "stock-movement": [
        { value: "product_name", label: "Product" },
        { value: "total_produced", label: "Total Produced" },
        { value: "total_sold", label: "Total Sold" },
        { value: "net_movement", label: "Net Movement" }
      ]
    };
    const availableColumns = computed(
      () => reportColumns[selectedReport.value] || []
    );
    const columnLabels = computed(() => {
      return Object.fromEntries(
        availableColumns.value.map((col) => [col.value, col.label])
      );
    });
    watch(selectedReport, (newVal) => {
      selectedColumns.value = reportColumns[newVal].slice(0, 4).map((c) => c.value);
    });
    const formatColumn = (report, column) => {
      const value = report[column];
      if (column.includes("amount") || column.includes("revenue")) {
        return `$${Number(value).toLocaleString(void 0, { minimumFractionDigits: 2 })}`;
      }
      if (typeof value === "number") return value.toLocaleString();
      return value || "N/A";
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}><h3 class="text-2xl font-semibold mb-4">Reports</h3><div class="mb-6 bg-white dark:bg-gray-800 shadow-lg rounded-lg p-6"><div class="grid grid-cols-1 md:grid-cols-2 gap-6"><div><label class="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-2">Select Report Type</label><select class="w-full px-4 py-2 rounded-lg bg-gray-200 dark:bg-gray-700"><!--[-->`);
      ssrRenderList(reportTypes.value, (report) => {
        _push(`<option${ssrRenderAttr("value", report.value)}>${ssrInterpolate(report.label)}</option>`);
      });
      _push(`<!--]--></select></div>`);
      if (selectedReport.value !== "inventory" && selectedReport.value !== "expiry") {
        _push(`<div><label class="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-2">Date Range</label><div class="flex space-x-4"><input${ssrRenderAttr("value", dateRange.value.start)} type="date" class="px-4 py-2 rounded-lg bg-gray-200 dark:bg-gray-700"><input${ssrRenderAttr("value", dateRange.value.end)} type="date" class="px-4 py-2 rounded-lg bg-gray-200 dark:bg-gray-700"></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div><div class="mb-6 bg-white dark:bg-gray-800 shadow-lg rounded-lg p-6"><div class="grid grid-cols-1 md:grid-cols-2 gap-6"><div><label class="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-2">Select Columns</label><div class="flex flex-wrap gap-2"><!--[-->`);
      ssrRenderList(availableColumns.value, (column) => {
        _push(`<label class="flex items-center space-x-2"><input type="checkbox"${ssrIncludeBooleanAttr(Array.isArray(selectedColumns.value) ? ssrLooseContain(selectedColumns.value, column.value) : selectedColumns.value) ? " checked" : ""}${ssrRenderAttr("value", column.value)} class="rounded border-gray-300 dark:border-gray-700"><span class="text-gray-700 dark:text-gray-200">${ssrInterpolate(column.label)}</span></label>`);
      });
      _push(`<!--]--></div></div>`);
      if (selectedReport.value === "expiry") {
        _push(`<div><label class="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-2">Expiry Threshold (Days)</label><input${ssrRenderAttr("value", expiryThreshold.value)} type="number" min="1" max="365" class="px-4 py-2 rounded-lg bg-gray-200 dark:bg-gray-700 w-32"></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><button class="mt-4 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition"> Generate Report </button></div><div class="mb-6 flex space-x-4"><button class="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition"> Export as CSV </button><button class="px-4 py-2 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition"> Export as Excel </button></div><div class="bg-white dark:bg-gray-800 shadow-lg rounded-lg p-4"><h4 class="text-lg font-semibold text-gray-700 dark:text-gray-200 mb-4">Preview</h4>`);
      if (isLoading.value) {
        _push(`<div class="text-center py-4"><div class="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900 mx-auto"></div></div>`);
      } else {
        _push(`<div><table class="w-full border-collapse"><thead><tr class="bg-gray-200 dark:bg-gray-700"><!--[-->`);
        ssrRenderList(selectedColumns.value, (column) => {
          _push(`<th class="py-3 px-4 text-left">${ssrInterpolate(columnLabels.value[column])}</th>`);
        });
        _push(`<!--]--></tr></thead><tbody><!--[-->`);
        ssrRenderList(reports.value, (report, index) => {
          _push(`<tr class="border-t border-gray-300 dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700"><!--[-->`);
          ssrRenderList(selectedColumns.value, (column) => {
            _push(`<td class="py-3 px-4">${ssrInterpolate(formatColumn(report, column))}</td>`);
          });
          _push(`<!--]--></tr>`);
        });
        _push(`<!--]--></tbody></table>`);
        if (reports.value.length === 0) {
          _push(`<div class="text-center py-4 text-gray-500"> No data available for the selected report </div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      }
      _push(`</div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/finance/Components/Reports.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
