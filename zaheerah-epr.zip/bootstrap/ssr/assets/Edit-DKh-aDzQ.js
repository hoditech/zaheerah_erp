import { defineComponent, reactive, unref, withCtx, createVNode, openBlock, createBlock, toDisplayString, createCommentVNode, withModifiers, withDirectives, vModelText, Fragment, renderList, vModelSelect, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderAttr, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual, ssrRenderList } from "vue/server-renderer";
import { A as AuthenticatedLayout } from "./AuthenticatedLayout-D1TzY3dv.js";
import { Head, router } from "@inertiajs/vue3";
import "laravel-permission-to-vuejs";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Edit",
  __ssrInlineRender: true,
  props: {
    purchaseOrder: {},
    categories: {},
    suppliers: {}
  },
  setup(__props) {
    const props = __props;
    console.log(props.purchaseOrder);
    const form = reactive({
      order_number: props.purchaseOrder.order_number,
      supplier_id: props.purchaseOrder.supplier_id,
      category_id: props.purchaseOrder.category_id,
      total_cost: props.purchaseOrder.total_cost,
      order_date: props.purchaseOrder.order_date,
      delivery_status: props.purchaseOrder.delivery_status
    });
    const submitForm = () => {
      router.put(route("purchase-orders.update", props.purchaseOrder.id), form);
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Edit Supply" }, null, _parent));
      _push(ssrRenderComponent(AuthenticatedLayout, null, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<h2 class="text-xl font-semibold leading-tight text-gray-800 dark:text-gray-200"${_scopeId}> Edit Order </h2>`);
          } else {
            return [
              createVNode("h2", { class: "text-xl font-semibold leading-tight text-gray-800 dark:text-gray-200" }, " Edit Order ")
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="py-12"${_scopeId}><div class="mx-auto max-w-7xl space-y-6 sm:px-6 lg:px-8"${_scopeId}>`);
            if (_ctx.$page.props.flash.success) {
              _push2(`<div class="bg-green-100 text-green-700 px-4 py-2 rounded mb-4"${_scopeId}>${ssrInterpolate(_ctx.$page.props.flash.success)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div class="bg-white p-4 shadow sm:rounded-lg sm:p-8 dark:bg-gray-800"${_scopeId}><form${_scopeId}><div class="mb-6"${_scopeId}><label for="name" class="block text-sm font-medium text-gray-700 dark:text-gray-300"${_scopeId}>Order Number</label><input${ssrRenderAttr("value", form.order_number)} type="text" id="name" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500 dark:bg-gray-700 dark:text-white dark:border-gray-600 dark:focus:ring-green-500 dark:focus:border-green-500" required${_scopeId}></div><div class="mb-6"${_scopeId}><select id="category" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500 dark:bg-gray-700 dark:text-white dark:border-gray-600 dark:focus:ring-green-500 dark:focus:border-green-500" required${_scopeId}><option value="" disabled${ssrIncludeBooleanAttr(Array.isArray(form.supplier_id) ? ssrLooseContain(form.supplier_id, "") : ssrLooseEqual(form.supplier_id, "")) ? " selected" : ""}${_scopeId}>Select a Supplier</option><!--[-->`);
            ssrRenderList(_ctx.suppliers, (supplier) => {
              _push2(`<option${ssrRenderAttr("value", supplier.id)}${_scopeId}>${ssrInterpolate(supplier.name)}</option>`);
            });
            _push2(`<!--]--></select></div><div class="mb-6"${_scopeId}><select id="category" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500 dark:bg-gray-700 dark:text-white dark:border-gray-600 dark:focus:ring-green-500 dark:focus:border-green-500" required${_scopeId}><option value="" disabled${ssrIncludeBooleanAttr(Array.isArray(form.category_id) ? ssrLooseContain(form.category_id, "") : ssrLooseEqual(form.category_id, "")) ? " selected" : ""}${_scopeId}>Select a Category</option><!--[-->`);
            ssrRenderList(_ctx.categories, (category) => {
              _push2(`<option${ssrRenderAttr("value", category.id)}${_scopeId}>${ssrInterpolate(category.name)}</option>`);
            });
            _push2(`<!--]--></select></div><div class="mb-6"${_scopeId}><label for="total_cost" class="block text-sm font-medium text-gray-700 dark:text-gray-300"${_scopeId}>Total Cost</label><input${ssrRenderAttr("value", form.total_cost)} id="total_cost" type="number" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500 dark:bg-gray-700 dark:text-white dark:border-gray-600 dark:focus:ring-green-500 dark:focus:border-green-500" required${_scopeId}></div><div class="mb-6"${_scopeId}><label for="order_date" class="block text-sm font-medium text-gray-700 dark:text-gray-300"${_scopeId}>Order Date</label><input${ssrRenderAttr("value", form.order_date)} id="order_date" type="date" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500 dark:bg-gray-700 dark:text-white dark:border-gray-600 dark:focus:ring-green-500 dark:focus:border-green-500" required${_scopeId}></div><div class="mb-6"${_scopeId}><label for="status" class="block text-sm font-medium text-gray-700 dark:text-gray-300"${_scopeId}>Status</label><select id="status" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500 dark:bg-gray-700 dark:text-white dark:border-gray-600 dark:focus:ring-green-500 dark:focus:border-green-500" required${_scopeId}><option value="" disabled${ssrIncludeBooleanAttr(Array.isArray(form.delivery_status) ? ssrLooseContain(form.delivery_status, "") : ssrLooseEqual(form.delivery_status, "")) ? " selected" : ""}${_scopeId}>Select Status</option><option value="Pending"${ssrIncludeBooleanAttr(Array.isArray(form.delivery_status) ? ssrLooseContain(form.delivery_status, "Pending") : ssrLooseEqual(form.delivery_status, "Pending")) ? " selected" : ""}${_scopeId}>Pending</option><option value="Delivered"${ssrIncludeBooleanAttr(Array.isArray(form.delivery_status) ? ssrLooseContain(form.delivery_status, "Delivered") : ssrLooseEqual(form.delivery_status, "Delivered")) ? " selected" : ""}${_scopeId}>Delivered</option><option value="Cancelled"${ssrIncludeBooleanAttr(Array.isArray(form.delivery_status) ? ssrLooseContain(form.delivery_status, "Cancelled") : ssrLooseEqual(form.delivery_status, "Cancelled")) ? " selected" : ""}${_scopeId}>Cancelled</option></select></div><div class="flex space-x-4"${_scopeId}><button type="submit" class="px-6 py-2 text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 rounded-md"${_scopeId}> Save </button><button type="button" class="px-6 py-2 text-white bg-gray-600 hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-500 rounded-md"${_scopeId}> Cancel </button></div></form></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "py-12" }, [
                createVNode("div", { class: "mx-auto max-w-7xl space-y-6 sm:px-6 lg:px-8" }, [
                  _ctx.$page.props.flash.success ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: "bg-green-100 text-green-700 px-4 py-2 rounded mb-4"
                  }, toDisplayString(_ctx.$page.props.flash.success), 1)) : createCommentVNode("", true),
                  createVNode("div", { class: "bg-white p-4 shadow sm:rounded-lg sm:p-8 dark:bg-gray-800" }, [
                    createVNode("form", {
                      onSubmit: withModifiers(submitForm, ["prevent"])
                    }, [
                      createVNode("div", { class: "mb-6" }, [
                        createVNode("label", {
                          for: "name",
                          class: "block text-sm font-medium text-gray-700 dark:text-gray-300"
                        }, "Order Number"),
                        withDirectives(createVNode("input", {
                          "onUpdate:modelValue": ($event) => form.order_number = $event,
                          type: "text",
                          id: "name",
                          class: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500 dark:bg-gray-700 dark:text-white dark:border-gray-600 dark:focus:ring-green-500 dark:focus:border-green-500",
                          required: ""
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, form.order_number]
                        ])
                      ]),
                      createVNode("div", { class: "mb-6" }, [
                        withDirectives(createVNode("select", {
                          "onUpdate:modelValue": ($event) => form.supplier_id = $event,
                          id: "category",
                          class: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500 dark:bg-gray-700 dark:text-white dark:border-gray-600 dark:focus:ring-green-500 dark:focus:border-green-500",
                          required: ""
                        }, [
                          createVNode("option", {
                            value: "",
                            disabled: ""
                          }, "Select a Supplier"),
                          (openBlock(true), createBlock(Fragment, null, renderList(_ctx.suppliers, (supplier) => {
                            return openBlock(), createBlock("option", {
                              key: supplier.id,
                              value: supplier.id
                            }, toDisplayString(supplier.name), 9, ["value"]);
                          }), 128))
                        ], 8, ["onUpdate:modelValue"]), [
                          [vModelSelect, form.supplier_id]
                        ])
                      ]),
                      createVNode("div", { class: "mb-6" }, [
                        withDirectives(createVNode("select", {
                          "onUpdate:modelValue": ($event) => form.category_id = $event,
                          id: "category",
                          class: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500 dark:bg-gray-700 dark:text-white dark:border-gray-600 dark:focus:ring-green-500 dark:focus:border-green-500",
                          required: ""
                        }, [
                          createVNode("option", {
                            value: "",
                            disabled: ""
                          }, "Select a Category"),
                          (openBlock(true), createBlock(Fragment, null, renderList(_ctx.categories, (category) => {
                            return openBlock(), createBlock("option", {
                              key: category.id,
                              value: category.id
                            }, toDisplayString(category.name), 9, ["value"]);
                          }), 128))
                        ], 8, ["onUpdate:modelValue"]), [
                          [vModelSelect, form.category_id]
                        ])
                      ]),
                      createVNode("div", { class: "mb-6" }, [
                        createVNode("label", {
                          for: "total_cost",
                          class: "block text-sm font-medium text-gray-700 dark:text-gray-300"
                        }, "Total Cost"),
                        withDirectives(createVNode("input", {
                          "onUpdate:modelValue": ($event) => form.total_cost = $event,
                          id: "total_cost",
                          type: "number",
                          class: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500 dark:bg-gray-700 dark:text-white dark:border-gray-600 dark:focus:ring-green-500 dark:focus:border-green-500",
                          required: ""
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, form.total_cost]
                        ])
                      ]),
                      createVNode("div", { class: "mb-6" }, [
                        createVNode("label", {
                          for: "order_date",
                          class: "block text-sm font-medium text-gray-700 dark:text-gray-300"
                        }, "Order Date"),
                        withDirectives(createVNode("input", {
                          "onUpdate:modelValue": ($event) => form.order_date = $event,
                          id: "order_date",
                          type: "date",
                          class: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500 dark:bg-gray-700 dark:text-white dark:border-gray-600 dark:focus:ring-green-500 dark:focus:border-green-500",
                          required: ""
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, form.order_date]
                        ])
                      ]),
                      createVNode("div", { class: "mb-6" }, [
                        createVNode("label", {
                          for: "status",
                          class: "block text-sm font-medium text-gray-700 dark:text-gray-300"
                        }, "Status"),
                        withDirectives(createVNode("select", {
                          "onUpdate:modelValue": ($event) => form.delivery_status = $event,
                          id: "status",
                          class: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500 dark:bg-gray-700 dark:text-white dark:border-gray-600 dark:focus:ring-green-500 dark:focus:border-green-500",
                          required: ""
                        }, [
                          createVNode("option", {
                            value: "",
                            disabled: ""
                          }, "Select Status"),
                          createVNode("option", { value: "Pending" }, "Pending"),
                          createVNode("option", { value: "Delivered" }, "Delivered"),
                          createVNode("option", { value: "Cancelled" }, "Cancelled")
                        ], 8, ["onUpdate:modelValue"]), [
                          [vModelSelect, form.delivery_status]
                        ])
                      ]),
                      createVNode("div", { class: "flex space-x-4" }, [
                        createVNode("button", {
                          type: "submit",
                          class: "px-6 py-2 text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 rounded-md"
                        }, " Save "),
                        createVNode("button", {
                          onClick: ($event) => _ctx.$inertia.visit(_ctx.route("purchase-orders.index")),
                          type: "button",
                          class: "px-6 py-2 text-white bg-gray-600 hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-500 rounded-md"
                        }, " Cancel ", 8, ["onClick"])
                      ])
                    ], 32)
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/procurement/PurchaseOrder/Edit.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
