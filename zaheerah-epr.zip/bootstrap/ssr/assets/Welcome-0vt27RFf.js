import { defineComponent, unref, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderAttr, ssrRenderList, ssrRenderClass } from "vue/server-renderer";
import { Head } from "@inertiajs/vue3";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Welcome",
  __ssrInlineRender: true,
  props: {
    canLogin: { type: Boolean },
    canRegister: { type: Boolean },
    laravelVersion: {},
    phpVersion: {}
  },
  setup(__props) {
    const socialLinks = [
      { icon: "fab fa-facebook-f", url: "#" },
      { icon: "fab fa-twitter", url: "#" },
      { icon: "fab fa-linkedin-in", url: "#" },
      { icon: "fab fa-instagram", url: "#" }
    ];
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Welcome" }, null, _parent));
      _push(`<div class="bg-gray-50 text-black/50 dark:bg-black dark:text-white/50"><div class="relative flex min-h-screen flex-col items-center justify-center selection:bg-[#FF2D20] selection:text-white"><div class="relative w-full max-w-2xl px-6 lg:max-w-7xl"><main class="mt-6"><div class="text-center px-6 p-8 rounded-lg"><div class="flex justify-center items-center py-8"><img src="/images/logo2.png" height="250" width="250" alt="Logo"></div><h1 class="text-5xl font-bold text-green-600 mb-2">Welcome to the Employee Portal</h1><p class="text-lg text-gray-700 mb-4 max-w-lg mx-auto">Your gateway to success and collaboration.</p><a${ssrRenderAttr("href", _ctx.route("login"))} class="inline-block px-8 py-3 bg-green-600 text-white font-semibold rounded-md shadow-md transition-transform duration-300 transform hover:bg-green-700 hover:scale-105"> Login to Your Account </a></div></main><footer class="text-white text-center p-4 mt-8"><h2 class="text-lg mb-2 text-gray-600">Follow Us</h2><div class="flex justify-center space-x-4"><!--[-->`);
      ssrRenderList(socialLinks, (link, index) => {
        _push(`<a${ssrRenderAttr("href", link.url)} class="text-gray-400 hover:text-green-700"><i class="${ssrRenderClass(link.icon)}"></i></a>`);
      });
      _push(`<!--]--></div></footer></div></div></div><!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Welcome.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
