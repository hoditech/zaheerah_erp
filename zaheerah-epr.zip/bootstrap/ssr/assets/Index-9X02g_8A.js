import { defineComponent, ref, unref, withCtx, createVNode, openBlock, createBlock, toDisplayString, createCommentVNode, withDirectives, vModelText, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderAttr } from "vue/server-renderer";
import { A as AuthenticatedLayout } from "./AuthenticatedLayout-DpiUQPiV.js";
import { Head, router } from "@inertiajs/vue3";
import { D as DataTable } from "./DataTable-DHuzay_f.js";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Index",
  __ssrInlineRender: true,
  props: {
    supplies: {
      type: Array,
      required: false,
      default: () => []
    }
  },
  setup(__props) {
    const columns = [
      { label: "Name", key: "name" },
      { label: "Contact Email", key: "contact_email" },
      { label: "Contact Phone", key: "contact_phone" },
      { label: "Address", key: "address" },
      { label: "Category", key: "category.name" },
      { label: "Status", key: "status" }
    ];
    const searchQuery = ref("");
    const deleteSupply = (supply) => {
      if (confirm(`Are you sure you want to delete the supply: ${supply.name}?`)) {
        router.delete(route("suppliers.destroy", supply.id), {
          onSuccess: () => console.log(`${supply.name} has been deleted successfully.`)
        });
      }
    };
    const editSupply = (supply) => {
      router.visit(route("suppliers.edit", supply.id));
    };
    const actions = [
      {
        label: "Edit",
        onClick: editSupply,
        class: "text-blue-600 hover:text-blue-900"
      },
      {
        label: "Delete",
        onClick: deleteSupply,
        class: "text-red-600 hover:text-red-900"
      }
    ];
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Supplies" }, null, _parent));
      _push(ssrRenderComponent(AuthenticatedLayout, null, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<h2 class="text-2xl font-bold leading-tight text-gray-800 dark:text-gray-200"${_scopeId}>Suppliers</h2>`);
          } else {
            return [
              createVNode("h2", { class: "text-2xl font-bold leading-tight text-gray-800 dark:text-gray-200" }, "Suppliers")
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="py-6"${_scopeId}><div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8"${_scopeId}>`);
            if (_ctx.$page.props.flash.success) {
              _push2(`<div class="bg-green-100 text-green-700 px-4 py-2 rounded mb-4"${_scopeId}>${ssrInterpolate(_ctx.$page.props.flash.success)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div class="flex justify-between items-center mb-6"${_scopeId}><div class="relative w-1/3"${_scopeId}><input${ssrRenderAttr("value", searchQuery.value)} type="text" placeholder="Search supplies..." class="w-full p-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring focus:ring-green-500 dark:bg-gray-700 dark:border-gray-600 dark:text-gray-300"${_scopeId}></div><button class="inline-flex items-center px-4 py-2 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-md shadow-md transition duration-300 ease-in-out"${_scopeId}> Add New Supply </button></div>`);
            _push2(ssrRenderComponent(DataTable, {
              columns,
              data: __props.supplies,
              searchQuery: searchQuery.value,
              actions,
              pageSize: 5
            }, null, _parent2, _scopeId));
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", { class: "py-6" }, [
                createVNode("div", { class: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8" }, [
                  _ctx.$page.props.flash.success ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: "bg-green-100 text-green-700 px-4 py-2 rounded mb-4"
                  }, toDisplayString(_ctx.$page.props.flash.success), 1)) : createCommentVNode("", true),
                  createVNode("div", { class: "flex justify-between items-center mb-6" }, [
                    createVNode("div", { class: "relative w-1/3" }, [
                      withDirectives(createVNode("input", {
                        "onUpdate:modelValue": ($event) => searchQuery.value = $event,
                        type: "text",
                        placeholder: "Search supplies...",
                        class: "w-full p-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring focus:ring-green-500 dark:bg-gray-700 dark:border-gray-600 dark:text-gray-300"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, searchQuery.value]
                      ])
                    ]),
                    createVNode("button", {
                      onClick: ($event) => _ctx.$inertia.visit(_ctx.route("suppliers.create")),
                      class: "inline-flex items-center px-4 py-2 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-md shadow-md transition duration-300 ease-in-out"
                    }, " Add New Supply ", 8, ["onClick"])
                  ]),
                  createVNode(DataTable, {
                    columns,
                    data: __props.supplies,
                    searchQuery: searchQuery.value,
                    actions,
                    pageSize: 5
                  }, null, 8, ["data", "searchQuery"])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/procurement/Suppliers/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
