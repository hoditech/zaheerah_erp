import { defineComponent, reactive, unref, withCtx, createVNode, withModifiers, withDirectives, vModelText, openBlock, createBlock, Fragment, renderList, toDisplayString, vModelSelect, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderAttr, ssrRenderList, ssrInterpolate } from "vue/server-renderer";
import { A as AuthenticatedLayout } from "./AuthenticatedLayout-DpiUQPiV.js";
import { Head, router } from "@inertiajs/vue3";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Create",
  __ssrInlineRender: true,
  props: {
    categories: {
      type: Array,
      required: true
    }
  },
  setup(__props) {
    const form = reactive({
      name: "",
      email: "",
      phone: "",
      role: "",
      category_id: ""
    });
    const submitForm = () => {
      router.post(route("employees.store"), form);
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Add Employee" }, null, _parent));
      _push(ssrRenderComponent(AuthenticatedLayout, null, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<h2 class="text-xl font-semibold leading-tight text-gray-800 dark:text-gray-200"${_scopeId}> Add New Employee </h2>`);
          } else {
            return [
              createVNode("h2", { class: "text-xl font-semibold leading-tight text-gray-800 dark:text-gray-200" }, " Add New Employee ")
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="py-12"${_scopeId}><div class="mx-auto max-w-7xl space-y-6 sm:px-6 lg:px-8"${_scopeId}><div class="bg-white p-4 shadow sm:rounded-lg sm:p-8 dark:bg-gray-800"${_scopeId}><form${_scopeId}><div class="mb-6"${_scopeId}><label for="name" class="block text-sm font-medium text-gray-700 dark:text-gray-300"${_scopeId}>Name</label><input${ssrRenderAttr("value", form.name)} type="text" id="name" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 dark:bg-gray-700 dark:text-white dark:border-gray-600 dark:focus:ring-indigo-500 dark:focus:border-indigo-500" required${_scopeId}></div><div class="mb-6"${_scopeId}><label for="email" class="block text-sm font-medium text-gray-700 dark:text-gray-300"${_scopeId}>Email</label><input${ssrRenderAttr("value", form.email)} type="email" id="email" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 dark:bg-gray-700 dark:text-white dark:border-gray-600 dark:focus:ring-indigo-500 dark:focus:border-indigo-500" required${_scopeId}></div><div class="mb-6"${_scopeId}><label for="phone" class="block text-sm font-medium text-gray-700 dark:text-gray-300"${_scopeId}>Phone</label><input${ssrRenderAttr("value", form.phone)} type="text" id="phone" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 dark:bg-gray-700 dark:text-white dark:border-gray-600 dark:focus:ring-indigo-500 dark:focus:border-indigo-500"${_scopeId}></div><div class="mb-6"${_scopeId}><label for="role" class="block text-sm font-medium text-gray-700 dark:text-gray-300"${_scopeId}>Role</label><input${ssrRenderAttr("value", form.role)} type="text" id="role" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 dark:bg-gray-700 dark:text-white dark:border-gray-600 dark:focus:ring-indigo-500 dark:focus:border-indigo-500" required${_scopeId}></div><div class="mb-6"${_scopeId}><label for="category" class="block text-sm font-medium text-gray-700 dark:text-gray-300"${_scopeId}>Category</label><select id="category" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 dark:bg-gray-700 dark:text-white dark:border-gray-600 dark:focus:ring-indigo-500 dark:focus:border-indigo-500" required${_scopeId}><!--[-->`);
            ssrRenderList(__props.categories, (category) => {
              _push2(`<option${ssrRenderAttr("value", category.id)}${_scopeId}>${ssrInterpolate(category.name)}</option>`);
            });
            _push2(`<!--]--></select></div><div class="flex space-x-4"${_scopeId}><button type="submit" class="px-6 py-2 text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 rounded-md"${_scopeId}> Save </button><button type="button" class="px-6 py-2 text-white bg-gray-600 hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-500 rounded-md"${_scopeId}> Cancel </button></div></form></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "py-12" }, [
                createVNode("div", { class: "mx-auto max-w-7xl space-y-6 sm:px-6 lg:px-8" }, [
                  createVNode("div", { class: "bg-white p-4 shadow sm:rounded-lg sm:p-8 dark:bg-gray-800" }, [
                    createVNode("form", {
                      onSubmit: withModifiers(submitForm, ["prevent"])
                    }, [
                      createVNode("div", { class: "mb-6" }, [
                        createVNode("label", {
                          for: "name",
                          class: "block text-sm font-medium text-gray-700 dark:text-gray-300"
                        }, "Name"),
                        withDirectives(createVNode("input", {
                          "onUpdate:modelValue": ($event) => form.name = $event,
                          type: "text",
                          id: "name",
                          class: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 dark:bg-gray-700 dark:text-white dark:border-gray-600 dark:focus:ring-indigo-500 dark:focus:border-indigo-500",
                          required: ""
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, form.name]
                        ])
                      ]),
                      createVNode("div", { class: "mb-6" }, [
                        createVNode("label", {
                          for: "email",
                          class: "block text-sm font-medium text-gray-700 dark:text-gray-300"
                        }, "Email"),
                        withDirectives(createVNode("input", {
                          "onUpdate:modelValue": ($event) => form.email = $event,
                          type: "email",
                          id: "email",
                          class: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 dark:bg-gray-700 dark:text-white dark:border-gray-600 dark:focus:ring-indigo-500 dark:focus:border-indigo-500",
                          required: ""
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, form.email]
                        ])
                      ]),
                      createVNode("div", { class: "mb-6" }, [
                        createVNode("label", {
                          for: "phone",
                          class: "block text-sm font-medium text-gray-700 dark:text-gray-300"
                        }, "Phone"),
                        withDirectives(createVNode("input", {
                          "onUpdate:modelValue": ($event) => form.phone = $event,
                          type: "text",
                          id: "phone",
                          class: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 dark:bg-gray-700 dark:text-white dark:border-gray-600 dark:focus:ring-indigo-500 dark:focus:border-indigo-500"
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, form.phone]
                        ])
                      ]),
                      createVNode("div", { class: "mb-6" }, [
                        createVNode("label", {
                          for: "role",
                          class: "block text-sm font-medium text-gray-700 dark:text-gray-300"
                        }, "Role"),
                        withDirectives(createVNode("input", {
                          "onUpdate:modelValue": ($event) => form.role = $event,
                          type: "text",
                          id: "role",
                          class: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 dark:bg-gray-700 dark:text-white dark:border-gray-600 dark:focus:ring-indigo-500 dark:focus:border-indigo-500",
                          required: ""
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, form.role]
                        ])
                      ]),
                      createVNode("div", { class: "mb-6" }, [
                        createVNode("label", {
                          for: "category",
                          class: "block text-sm font-medium text-gray-700 dark:text-gray-300"
                        }, "Category"),
                        withDirectives(createVNode("select", {
                          "onUpdate:modelValue": ($event) => form.category_id = $event,
                          id: "category",
                          class: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 dark:bg-gray-700 dark:text-white dark:border-gray-600 dark:focus:ring-indigo-500 dark:focus:border-indigo-500",
                          required: ""
                        }, [
                          (openBlock(true), createBlock(Fragment, null, renderList(__props.categories, (category) => {
                            return openBlock(), createBlock("option", {
                              key: category.id,
                              value: category.id
                            }, toDisplayString(category.name), 9, ["value"]);
                          }), 128))
                        ], 8, ["onUpdate:modelValue"]), [
                          [vModelSelect, form.category_id]
                        ])
                      ]),
                      createVNode("div", { class: "flex space-x-4" }, [
                        createVNode("button", {
                          type: "submit",
                          class: "px-6 py-2 text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 rounded-md"
                        }, " Save "),
                        createVNode("button", {
                          onClick: ($event) => _ctx.$inertia.visit(_ctx.route("employees.index")),
                          type: "button",
                          class: "px-6 py-2 text-white bg-gray-600 hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-500 rounded-md"
                        }, " Cancel ", 8, ["onClick"])
                      ])
                    ], 32)
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/HR/Create.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
