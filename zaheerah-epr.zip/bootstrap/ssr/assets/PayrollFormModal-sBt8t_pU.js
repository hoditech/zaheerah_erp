import { defineComponent, ref, onMounted, mergeProps, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual, ssrRenderList, ssrRenderAttr, ssrInterpolate, ssrRenderDynamicModel } from "vue/server-renderer";
import axios from "axios";
const fetchUsers = async () => {
  try {
    const response = await axios.get("/users");
    return response.data.users;
  } catch (error) {
    console.error("Error fetching users:", error);
    return [];
  }
};
const fetchPayrols = async () => {
  try {
    const response = await axios.get("/payrolls");
    return response.data.payrolls;
  } catch (error) {
    console.error("Error fetching payrolls:", error);
    return [];
  }
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "PayrollFormModal",
  __ssrInlineRender: true,
  emits: ["submit", "close"],
  setup(__props, { emit: __emit }) {
    const users = ref([]);
    const isLoading = ref(true);
    const isSubmitting = ref(false);
    const validationErrors = ref({});
    const defaultForm = {
      user_id: "",
      base_salary: "",
      overtime_pay: "",
      bonuses: "",
      deductions: "",
      tax: "",
      commission: "",
      payment_method: "Bank Transfer",
      payment_status: "Pending",
      payment_date: ""
    };
    const form = ref({ ...defaultForm });
    const salaryFields = {
      base_salary: { label: "Base Salary", type: "number", required: true },
      overtime_pay: { label: "Overtime Pay", type: "number", required: false },
      bonuses: { label: "Bonuses", type: "number", required: false },
      deductions: { label: "Deductions", type: "number", required: false },
      tax: { label: "Tax", type: "number", required: false },
      commission: { label: "Commission", type: "number", required: false },
      payment_method: {
        label: "Payment Method",
        type: "select",
        required: true,
        options: [
          { label: "Bank Transfer", value: "bank_transfer" },
          { label: "Cash", value: "cash" },
          { label: "Mobile Money", value: "mobile_money" }
        ]
      },
      payment_status: {
        label: "Payment Status",
        type: "select",
        required: true,
        options: [
          { label: "Paid", value: "paid" },
          { label: "Pending", value: "pending" }
        ]
      },
      payment_date: { label: "Payment Date", type: "date", required: false }
    };
    const loadUsers = async () => {
      isLoading.value = true;
      try {
        users.value = await fetchUsers();
      } catch (error) {
        console.error("Failed to fetch users:", error);
      } finally {
        isLoading.value = false;
      }
    };
    onMounted(loadUsers);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center" }, _attrs))}><div class="bg-white dark:bg-gray-800 rounded-lg w-1/3 p-6"><h3 class="text-xl font-semibold mb-4">Add Payroll</h3><form><div class="grid grid-cols-1 md:grid-cols-2 gap-4"><div><label class="block text-sm font-medium text-gray-700">Employee</label><select required class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm" aria-label="Select an Employee"${ssrIncludeBooleanAttr(isLoading.value) ? " disabled" : ""}><option value="" disabled${ssrIncludeBooleanAttr(Array.isArray(form.value.user_id) ? ssrLooseContain(form.value.user_id, "") : ssrLooseEqual(form.value.user_id, "")) ? " selected" : ""}>Select an Employee</option>`);
      if (isLoading.value) {
        _push(`<option disabled>Loading employees...</option>`);
      } else {
        _push(`<!--[-->`);
        ssrRenderList(users.value, (user) => {
          _push(`<option${ssrRenderAttr("value", user.id)}>${ssrInterpolate(user.name)}</option>`);
        });
        _push(`<!--]-->`);
      }
      _push(`</select>`);
      if (validationErrors.value.user_id) {
        _push(`<span class="text-red-500 text-sm">${ssrInterpolate(validationErrors.value.user_id[0])}</span>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><!--[-->`);
      ssrRenderList(salaryFields, (value, key) => {
        _push(`<div><label class="block text-sm font-medium text-gray-700">${ssrInterpolate(value.label)}</label>`);
        if (key === "payment_method" || key === "payment_status") {
          _push(`<select required class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm"><!--[-->`);
          ssrRenderList(value.options, (option) => {
            _push(`<option${ssrRenderAttr("value", option.value)}>${ssrInterpolate(option.label)}</option>`);
          });
          _push(`<!--]--></select>`);
        } else {
          _push(`<input${ssrRenderDynamicModel(value.type, form.value[key], null)}${ssrRenderAttr("type", value.type)}${ssrIncludeBooleanAttr(value.required) ? " required" : ""} class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm">`);
        }
        if (validationErrors.value[key]) {
          _push(`<span class="text-red-500 text-sm">${ssrInterpolate(validationErrors.value[key][0])}</span>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      });
      _push(`<!--]--></div><div class="flex space-x-4 mt-6"><button type="submit" class="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition duration-300"${ssrIncludeBooleanAttr(isLoading.value || isSubmitting.value) ? " disabled" : ""}>${ssrInterpolate(isSubmitting.value ? "Submitting..." : "Submit")}</button><button type="button" class="px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition duration-300"${ssrIncludeBooleanAttr(isSubmitting.value) ? " disabled" : ""}> Cancel </button></div></form></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/finance/Components/PayrollFormModal.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const PayrollFormModal = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: _sfc_main
}, Symbol.toStringTag, { value: "Module" }));
export {
  PayrollFormModal as P,
  _sfc_main as _,
  fetchPayrols as f
};
