import { defineComponent, ref, unref, withCtx, createVNode, createTextVNode, withDirectives, vModelText, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderAttr } from "vue/server-renderer";
import { A as AuthenticatedLayout } from "./AuthenticatedLayout-DpiUQPiV.js";
import { Head, Link } from "@inertiajs/vue3";
import { D as DataTable } from "./DataTable-DHuzay_f.js";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "ProductPage",
  __ssrInlineRender: true,
  props: {
    products: {
      type: Array,
      default: () => []
    }
  },
  setup(__props) {
    const props = __props;
    const columns = [
      { label: "ID", key: "id" },
      { label: "Name", key: "name" },
      { label: "Category", key: "category.name" },
      { label: "Price", key: "price" },
      { label: "Stock", key: "stock" }
    ];
    const searchQuery = ref("");
    const deleteProduct = (product) => {
      console.log("Delete Product:", product);
    };
    const actions = [
      { label: "Delete", onClick: deleteProduct, class: "text-red-600 hover:text-red-900" },
      {
        label: "Edit",
        onClick: (product) => console.log("Edit", product),
        class: "text-blue-600 hover:text-blue-900"
      }
    ];
    const exportToCSV = () => {
      const csvHeader = columns.map((col) => col.label).join(",") + "\n";
      const csvRows = props.products.map(
        (product) => columns.map((col) => {
          const keys = col.key.split(".");
          let value = product;
          for (const key of keys) {
            value = [key];
            if (value === void 0) break;
          }
          return `"${value ?? ""}"`;
        }).join(",")
      ).join("\n");
      const csvContent = csvHeader + csvRows;
      const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", "products.csv");
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Product Management" }, null, _parent));
      _push(ssrRenderComponent(AuthenticatedLayout, null, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<h2 class="text-2xl font-bold leading-tight text-gray-800 dark:text-gray-200"${_scopeId}>Product Management</h2>`);
          } else {
            return [
              createVNode("h2", { class: "text-2xl font-bold leading-tight text-gray-800 dark:text-gray-200" }, "Product Management")
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="py-6"${_scopeId}><div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8"${_scopeId}><div class="flex justify-between items-center mb-6"${_scopeId}><div class="relative w-1/3"${_scopeId}><input${ssrRenderAttr("value", searchQuery.value)} type="text" placeholder="Search products..." class="w-full p-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring focus:ring-green-500 dark:bg-gray-700 dark:border-gray-600 dark:text-gray-300"${_scopeId}></div><div class="flex space-x-4"${_scopeId}><button class="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-md shadow-md transition duration-300 ease-in-out"${_scopeId}> Export to CSV </button>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: _ctx.route("products.create"),
              class: "inline-flex items-center px-4 py-2 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-md shadow-md transition duration-300 ease-in-out"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` New Product `);
                } else {
                  return [
                    createTextVNode(" New Product ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div>`);
            _push2(ssrRenderComponent(DataTable, {
              columns,
              data: __props.products,
              searchQuery: searchQuery.value,
              actions
            }, null, _parent2, _scopeId));
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", { class: "py-6" }, [
                createVNode("div", { class: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8" }, [
                  createVNode("div", { class: "flex justify-between items-center mb-6" }, [
                    createVNode("div", { class: "relative w-1/3" }, [
                      withDirectives(createVNode("input", {
                        "onUpdate:modelValue": ($event) => searchQuery.value = $event,
                        type: "text",
                        placeholder: "Search products...",
                        class: "w-full p-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring focus:ring-green-500 dark:bg-gray-700 dark:border-gray-600 dark:text-gray-300"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, searchQuery.value]
                      ])
                    ]),
                    createVNode("div", { class: "flex space-x-4" }, [
                      createVNode("button", {
                        onClick: exportToCSV,
                        class: "inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-md shadow-md transition duration-300 ease-in-out"
                      }, " Export to CSV "),
                      createVNode(unref(Link), {
                        href: _ctx.route("products.create"),
                        class: "inline-flex items-center px-4 py-2 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-md shadow-md transition duration-300 ease-in-out"
                      }, {
                        default: withCtx(() => [
                          createTextVNode(" New Product ")
                        ]),
                        _: 1
                      }, 8, ["href"])
                    ])
                  ]),
                  createVNode(DataTable, {
                    columns,
                    data: __props.products,
                    searchQuery: searchQuery.value,
                    actions
                  }, null, 8, ["data", "searchQuery"])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/product/ProductPage.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
