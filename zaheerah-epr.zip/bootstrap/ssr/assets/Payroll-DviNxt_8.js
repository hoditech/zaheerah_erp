import { defineComponent, ref, computed, onMounted, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderList, ssrRenderClass } from "vue/server-renderer";
import { _ as _sfc_main$1, f as fetchPayrols } from "./PayrollFormModal-sBt8t_pU.js";
import "axios";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Payroll",
  __ssrInlineRender: true,
  setup(__props) {
    const payrolls = ref([]);
    const loading = ref(false);
    const payrollFilter = ref("All");
    const payrollFilters = ["All", "Paid", "Pending"];
    const isPayrollFormOpen = ref(false);
    const successMessage = ref("");
    const filteredPayrolls = computed(() => {
      if (payrollFilter.value === "All") return payrolls.value;
      return payrolls.value.filter((payroll) => payroll.payment_status === payrollFilter.value.toLowerCase());
    });
    const handlePayrollSubmit = () => {
      isPayrollFormOpen.value = false;
      successMessage.value = "Payroll successfully submitted!";
      setTimeout(() => {
        successMessage.value = "";
      }, 3e3);
      loadPayrolls();
    };
    const loadPayrolls = async () => {
      loading.value = true;
      try {
        const payrollsData = await fetchPayrols();
        payrolls.value = payrollsData;
        console.log(payrollsData);
      } catch (error) {
        console.error("Error fetching payrolls:", error);
      } finally {
        loading.value = false;
      }
    };
    onMounted(loadPayrolls);
    const closePayrollForm = () => {
      isPayrollFormOpen.value = false;
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      if (isPayrollFormOpen.value) {
        _push(ssrRenderComponent(_sfc_main$1, {
          onSubmit: handlePayrollSubmit,
          onClose: closePayrollForm
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (successMessage.value) {
        _push(`<div class="bg-green-500 text-white p-4 rounded-lg mb-4">${ssrInterpolate(successMessage.value)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<h3 class="text-2xl font-semibold mb-4">Payroll Tracking</h3><div class="mb-6 flex space-x-4"><!--[-->`);
      ssrRenderList(payrollFilters, (filter) => {
        _push(`<button class="${ssrRenderClass([{ "bg-green-500 text-white": payrollFilter.value === filter }, "px-4 py-2 rounded-lg bg-gray-200 dark:bg-gray-700 hover:bg-green-500 hover:text-white transition"])}">${ssrInterpolate(filter)}</button>`);
      });
      _push(`<!--]--><button class="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition"> Add Payroll </button></div><div class="bg-white dark:bg-gray-800 shadow-lg rounded-lg p-4"><div class="overflow-y-auto max-h-[400px]"><table class="w-full border-collapse"><thead><tr class="bg-gray-200 dark:bg-gray-700"><th class="py-3 px-4 text-left sticky top-0 bg-gray-200 dark:bg-gray-700 z-10">Employee</th><th class="py-3 px-4 text-left sticky top-0 bg-gray-200 dark:bg-gray-700 z-10">Base Salary</th><th class="py-3 px-4 text-left sticky top-0 bg-gray-200 dark:bg-gray-700 z-10">Overtime Pay</th><th class="py-3 px-4 text-left sticky top-0 bg-gray-200 dark:bg-gray-700 z-10">Bonuses</th><th class="py-3 px-4 text-left sticky top-0 bg-gray-200 dark:bg-gray-700 z-10">Net Salary</th><th class="py-3 px-4 text-left sticky top-0 bg-gray-200 dark:bg-gray-700 z-10">Status</th><th class="py-3 px-4 text-left sticky top-0 bg-gray-200 dark:bg-gray-700 z-10">Actions</th></tr></thead><tbody><!--[-->`);
      ssrRenderList(filteredPayrolls.value, (payroll) => {
        _push(`<tr class="border-t border-gray-300 dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700"><td class="py-3 px-4">${ssrInterpolate(payroll.user.name)}</td><td class="py-3 px-4">₦${ssrInterpolate(payroll.base_salary.toLocaleString())}</td><td class="py-3 px-4">₦${ssrInterpolate(payroll.overtime_pay.toLocaleString())}</td><td class="py-3 px-4">₦${ssrInterpolate(payroll.bonuses.toLocaleString())}</td><td class="py-3 px-4">₦${ssrInterpolate(payroll.net_salary.toLocaleString())}</td><td class="py-3 px-4"><span class="${ssrRenderClass({ "text-green-500": payroll.payment_status === "paid", "text-yellow-500": payroll.payment_status === "pending" })}">${ssrInterpolate(payroll.payment_status)}</span></td><td class="py-3 px-4"><button class="px-2 py-1 bg-yellow-500 text-sm text-white rounded-md hover:bg-yellow-600 transition"> Update </button></td></tr>`);
      });
      _push(`<!--]--></tbody></table></div></div>`);
      if (loading.value) {
        _push(`<div class="flex justify-center items-center p-4"><p class="text-green-500">Loading...</p></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/finance/Components/Payroll.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
