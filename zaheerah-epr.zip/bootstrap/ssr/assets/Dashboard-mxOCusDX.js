import { defineComponent, ref, onMounted, unref, withCtx, createVNode, toDisplayString, withModifiers, withDirectives, vModelText, openBlock, createBlock, createCommentVNode, Fragment, renderList, createTextVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderList, ssrRenderAttr } from "vue/server-renderer";
import { Head } from "@inertiajs/vue3";
import { A as AuthenticatedLayout } from "./AuthenticatedLayout-BMQt65oV.js";
import { _ as _sfc_main$1 } from "./Modal-CHpSqOzd.js";
import { PencilIcon, TrashIcon } from "@heroicons/vue/16/solid";
import axios from "axios";
import { is } from "laravel-permission-to-vuejs";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Dashboard",
  __ssrInlineRender: true,
  props: {
    usersCount: {
      type: Number,
      default: 0
    },
    activeUsersCount: {
      type: Number,
      default: 0
    },
    newUsersCount: {
      type: Number,
      default: 0
    },
    logs: {
      type: Array
    }
  },
  setup(__props) {
    const notices = ref([]);
    const isNoticeModalOpen = ref(false);
    const isEditingNotice = ref(false);
    const noticeForm = ref({ id: 0, title: "", description: "", date: "" });
    const currentNoticeIndex = ref(null);
    const isLoading = ref(false);
    const error = ref(null);
    const events = ref([]);
    const isEventModalOpen = ref(false);
    const isEditingEvent = ref(false);
    const eventForm = ref({ id: 0, title: "", description: "", date: "" });
    const currentEventIndex = ref(null);
    const fetchNotices = async () => {
      isLoading.value = true;
      error.value = null;
      try {
        const response = await axios.get("/notices");
        notices.value = response.data;
      } catch (err) {
        error.value = "Failed to fetch notices. Please try again later.";
      } finally {
        isLoading.value = false;
      }
    };
    const fetchEvents = async () => {
      isLoading.value = true;
      error.value = null;
      try {
        const response = await axios.get("/events");
        events.value = response.data;
      } catch (err) {
        error.value = "Failed to fetch events. Please try again later.";
      } finally {
        isLoading.value = false;
      }
    };
    const openNoticeModal = (index) => {
      if (index !== void 0) {
        noticeForm.value = { ...notices.value[index] };
        isEditingNotice.value = true;
        currentNoticeIndex.value = index;
      } else {
        noticeForm.value = { id: 0, title: "", description: "", date: "" };
        isEditingNotice.value = false;
      }
      isNoticeModalOpen.value = true;
    };
    const closeNoticeModal = () => {
      isNoticeModalOpen.value = false;
    };
    const saveNotice = async () => {
      isLoading.value = true;
      error.value = null;
      try {
        if (isEditingNotice.value && currentNoticeIndex.value !== null) {
          await axios.put(`/notices/${notices.value[currentNoticeIndex.value].id}`, noticeForm.value);
        } else {
          await axios.post("/notices", noticeForm.value);
        }
        fetchNotices();
        closeNoticeModal();
      } catch (err) {
        error.value = "Failed to save notice. Please try again later.";
      } finally {
        isLoading.value = false;
      }
    };
    const editNotice = (index) => {
      openNoticeModal(index);
    };
    const deleteNotice = async (index) => {
      isLoading.value = true;
      error.value = null;
      try {
        await axios.delete(`/notices/${notices.value[index].id}`);
        fetchNotices();
      } catch (err) {
        error.value = "Failed to delete notice. Please try again later.";
      } finally {
        isLoading.value = false;
      }
    };
    const openEventModal = (index) => {
      if (index !== void 0) {
        eventForm.value = { ...events.value[index] };
        isEditingEvent.value = true;
        currentEventIndex.value = index;
      } else {
        eventForm.value = { id: 0, title: "", description: "", date: "" };
        isEditingEvent.value = false;
      }
      isEventModalOpen.value = true;
    };
    const closeEventModal = () => {
      isEventModalOpen.value = false;
    };
    const saveEvent = async () => {
      isLoading.value = true;
      error.value = null;
      try {
        if (isEditingEvent.value && currentEventIndex.value !== null) {
          await axios.put(`/events/${events.value[currentEventIndex.value].id}`, eventForm.value);
        } else {
          await axios.post("/events", eventForm.value);
        }
        fetchEvents();
        closeEventModal();
      } catch (err) {
        error.value = "Failed to save event. Please try again later.";
      } finally {
        isLoading.value = false;
      }
    };
    const editEvent = (index) => {
      openEventModal(index);
    };
    const deleteEvent = async (index) => {
      isLoading.value = true;
      error.value = null;
      try {
        await axios.delete(`/events/${events.value[index].id}`);
        fetchEvents();
      } catch (err) {
        error.value = "Failed to delete event. Please try again later.";
      } finally {
        isLoading.value = false;
      }
    };
    onMounted(() => {
      fetchNotices();
      fetchEvents();
    });
    const formatDate = (date) => {
      const now = /* @__PURE__ */ new Date();
      const timestamp = new Date(date);
      const diffInSeconds = Math.floor((now.getTime() - timestamp.getTime()) / 1e3);
      const minutes = Math.floor(diffInSeconds / 60);
      const hours = Math.floor(diffInSeconds / 3600);
      const days = Math.floor(diffInSeconds / 86400);
      const months = Math.floor(diffInSeconds / 2592e3);
      const years = Math.floor(diffInSeconds / 31536e3);
      if (years > 0) {
        return `${years} year${years > 1 ? "s" : ""} ago`;
      }
      if (months > 0) {
        return `${months} month${months > 1 ? "s" : ""} ago`;
      }
      if (days > 0) {
        return `${days} day${days > 1 ? "s" : ""} ago`;
      }
      if (hours > 0) {
        return `${hours} hour${hours > 1 ? "s" : ""} ago`;
      }
      if (minutes > 0) {
        return `${minutes} minute${minutes > 1 ? "s" : ""} ago`;
      }
      return "Just now";
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Dashboard" }, null, _parent));
      _push(ssrRenderComponent(AuthenticatedLayout, null, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<header class="flex items-center justify-between px-4 py-4 bg-gray-50 dark:bg-gray-800 rounded-lg shadow-sm"${_scopeId}><h2 class="text-3xl font-bold text-gray-800 dark:text-gray-200"${_scopeId}>Admin Dashboard</h2></header>`);
          } else {
            return [
              createVNode("header", { class: "flex items-center justify-between px-4 py-4 bg-gray-50 dark:bg-gray-800 rounded-lg shadow-sm" }, [
                createVNode("h2", { class: "text-3xl font-bold text-gray-800 dark:text-gray-200" }, "Admin Dashboard")
              ])
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="p-6"${_scopeId}>`);
            if (isLoading.value) {
              _push2(`<div class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50"${_scopeId}><div class="relative w-16 h-16"${_scopeId}><div class="w-full h-full border-4 border-transparent border-t-green-500 border-r-green-500 rounded-full animate-spin"${_scopeId}></div><div class="absolute inset-2 w-12 h-12 border-4 border-transparent border-t-gray-300 border-r-gray-300 rounded-full animate-spin-slow"${_scopeId}></div></div></div>`);
            } else {
              _push2(`<!---->`);
            }
            if (error.value) {
              _push2(`<div class="mb-6 p-4 bg-red-100 border border-red-400 text-red-700 rounded-lg"${_scopeId}><p${_scopeId}>${ssrInterpolate(error.value)}</p></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8"${_scopeId}><div class="bg-white dark:bg-gray-700 p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow"${_scopeId}><h3 class="text-lg font-semibold text-gray-700 dark:text-gray-200"${_scopeId}>Total Employees</h3><p class="text-2xl font-bold text-gray-900 dark:text-gray-100"${_scopeId}>${ssrInterpolate(__props.usersCount)}</p></div><div class="bg-white dark:bg-gray-700 p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow"${_scopeId}><h3 class="text-lg font-semibold text-gray-700 dark:text-gray-200"${_scopeId}>Active Employees</h3><p class="text-2xl font-bold text-gray-900 dark:text-gray-100"${_scopeId}>${ssrInterpolate(__props.activeUsersCount)}</p></div><div class="bg-white dark:bg-gray-700 p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow"${_scopeId}><h3 class="text-lg font-semibold text-gray-700 dark:text-gray-200"${_scopeId}>New Hires (This Month)</h3><p class="text-2xl font-bold text-gray-900 dark:text-gray-100"${_scopeId}>${ssrInterpolate(__props.newUsersCount)}</p></div></div><div class="bg-white dark:bg-gray-700 p-6 rounded-lg shadow-sm mb-8"${_scopeId}><div class="flex items-center justify-between mb-4"${_scopeId}><h3 class="text-xl font-semibold text-gray-800 dark:text-gray-200"${_scopeId}>Notice Board</h3>`);
            if (unref(is)("Super Admin")) {
              _push2(`<button class="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"${_scopeId}> Add Notice </button>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="h-64 overflow-y-auto space-y-4"${_scopeId}><!--[-->`);
            ssrRenderList(notices.value, (notice, index) => {
              _push2(`<div class="p-4 bg-gray-50 dark:bg-gray-600 rounded-lg relative group"${_scopeId}><h4 class="text-lg font-semibold text-gray-700 dark:text-gray-200"${_scopeId}>${ssrInterpolate(notice.title)}</h4><p class="text-gray-600 dark:text-gray-300 mt-2"${_scopeId}>${ssrInterpolate(notice.description)}</p><p class="text-sm text-gray-500 dark:text-gray-400 mt-2"${_scopeId}>Posted on: ${ssrInterpolate(notice.date)}</p><div class="absolute top-2 right-2 flex space-x-2 opacity-0 group-hover:opacity-100 transition-opacity"${_scopeId}>`);
              if (unref(is)("Super Admin")) {
                _push2(`<button class="p-1 text-green-500 hover:text-green-600"${_scopeId}>`);
                _push2(ssrRenderComponent(unref(PencilIcon), { class: "w-5 h-5" }, null, _parent2, _scopeId));
                _push2(`</button>`);
              } else {
                _push2(`<!---->`);
              }
              if (unref(is)("Super Admin")) {
                _push2(`<button class="p-1 text-red-500 hover:text-red-600"${_scopeId}>`);
                _push2(ssrRenderComponent(unref(TrashIcon), { class: "w-5 h-5" }, null, _parent2, _scopeId));
                _push2(`</button>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div></div>`);
            });
            _push2(`<!--]--></div></div><div class="bg-white dark:bg-gray-700 p-6 rounded-lg shadow-sm mb-8"${_scopeId}><div class="flex items-center justify-between mb-4"${_scopeId}><h3 class="text-xl font-semibold text-gray-800 dark:text-gray-200"${_scopeId}>Upcoming Events</h3>`);
            if (unref(is)("Super Admin")) {
              _push2(`<button class="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"${_scopeId}> Add Event </button>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="h-64 overflow-y-auto space-y-4"${_scopeId}><!--[-->`);
            ssrRenderList(events.value, (event, index) => {
              _push2(`<div class="p-4 bg-gray-50 dark:bg-gray-600 rounded-lg relative group"${_scopeId}><h4 class="text-lg font-semibold text-gray-700 dark:text-gray-200"${_scopeId}>${ssrInterpolate(event.title)}</h4><p class="text-gray-600 dark:text-gray-300 mt-2"${_scopeId}>${ssrInterpolate(event.description)}</p><p class="text-sm text-gray-500 dark:text-gray-400 mt-2"${_scopeId}>Date: ${ssrInterpolate(event.date)}</p><div class="absolute top-2 right-2 flex space-x-2 opacity-0 group-hover:opacity-100 transition-opacity"${_scopeId}>`);
              if (unref(is)("Super Admin")) {
                _push2(`<button class="p-1 text-green-500 hover:text-green-600"${_scopeId}>`);
                _push2(ssrRenderComponent(unref(PencilIcon), { class: "w-5 h-5" }, null, _parent2, _scopeId));
                _push2(`</button>`);
              } else {
                _push2(`<!---->`);
              }
              if (unref(is)("Super Admin")) {
                _push2(`<button class="p-1 text-red-500 hover:text-red-600"${_scopeId}>`);
                _push2(ssrRenderComponent(unref(TrashIcon), { class: "w-5 h-5" }, null, _parent2, _scopeId));
                _push2(`</button>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div></div>`);
            });
            _push2(`<!--]--></div></div><div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg mb-8"${_scopeId}><h3 class="text-2xl font-semibold text-gray-900 dark:text-gray-100 mb-6"${_scopeId}>Recent Employee Activity</h3><ul class="space-y-5"${_scopeId}><!--[-->`);
            ssrRenderList(__props.logs, (log) => {
              _push2(`<li class="flex items-center justify-between bg-gray-50 dark:bg-gray-700 p-4 rounded-lg shadow-sm hover:bg-gray-100 dark:hover:bg-gray-600 transition duration-200"${_scopeId}><span class="text-gray-700 dark:text-gray-300 text-base"${_scopeId}><strong class="font-medium"${_scopeId}>${ssrInterpolate(log.action)}:</strong> ${ssrInterpolate(log.user_name)} <span class="text-gray-600 dark:text-gray-400"${_scopeId}>${ssrInterpolate(log.description)}</span></span><span class="text-sm text-gray-500 dark:text-gray-400"${_scopeId}>${ssrInterpolate(formatDate(log.created_at))}</span></li>`);
            });
            _push2(`<!--]--></ul></div></div>`);
            _push2(ssrRenderComponent(_sfc_main$1, {
              show: isNoticeModalOpen.value,
              onClose: closeNoticeModal
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="p-6"${_scopeId2}><h3 class="text-xl font-semibold mb-4"${_scopeId2}>${ssrInterpolate(isEditingNotice.value ? "Edit Notice" : "Add Notice")}</h3><form${_scopeId2}><div class="mb-4"${_scopeId2}><label class="block text-gray-700 dark:text-gray-300 mb-2"${_scopeId2}>Title</label><input${ssrRenderAttr("value", noticeForm.value.title)} type="text" class="w-full px-4 py-2 border rounded-lg dark:bg-gray-800 dark:border-gray-700" required${_scopeId2}></div><div class="mb-4"${_scopeId2}><label class="block text-gray-700 dark:text-gray-300 mb-2"${_scopeId2}>Description</label><textarea class="w-full px-4 py-2 border rounded-lg dark:bg-gray-800 dark:border-gray-700" rows="4" required${_scopeId2}>${ssrInterpolate(noticeForm.value.description)}</textarea></div><div class="mb-4"${_scopeId2}><label class="block text-gray-700 dark:text-gray-300 mb-2"${_scopeId2}>Date</label><input${ssrRenderAttr("value", noticeForm.value.date)} type="date" class="w-full px-4 py-2 border rounded-lg dark:bg-gray-800 dark:border-gray-700" required${_scopeId2}></div><div class="flex justify-end"${_scopeId2}><button type="button" class="mr-2 px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-colors"${_scopeId2}> Cancel </button><button type="submit" class="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"${_scopeId2}>${ssrInterpolate(isEditingNotice.value ? "Update" : "Save")}</button></div></form></div>`);
                } else {
                  return [
                    createVNode("div", { class: "p-6" }, [
                      createVNode("h3", { class: "text-xl font-semibold mb-4" }, toDisplayString(isEditingNotice.value ? "Edit Notice" : "Add Notice"), 1),
                      createVNode("form", {
                        onSubmit: withModifiers(saveNotice, ["prevent"])
                      }, [
                        createVNode("div", { class: "mb-4" }, [
                          createVNode("label", { class: "block text-gray-700 dark:text-gray-300 mb-2" }, "Title"),
                          withDirectives(createVNode("input", {
                            "onUpdate:modelValue": ($event) => noticeForm.value.title = $event,
                            type: "text",
                            class: "w-full px-4 py-2 border rounded-lg dark:bg-gray-800 dark:border-gray-700",
                            required: ""
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, noticeForm.value.title]
                          ])
                        ]),
                        createVNode("div", { class: "mb-4" }, [
                          createVNode("label", { class: "block text-gray-700 dark:text-gray-300 mb-2" }, "Description"),
                          withDirectives(createVNode("textarea", {
                            "onUpdate:modelValue": ($event) => noticeForm.value.description = $event,
                            class: "w-full px-4 py-2 border rounded-lg dark:bg-gray-800 dark:border-gray-700",
                            rows: "4",
                            required: ""
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, noticeForm.value.description]
                          ])
                        ]),
                        createVNode("div", { class: "mb-4" }, [
                          createVNode("label", { class: "block text-gray-700 dark:text-gray-300 mb-2" }, "Date"),
                          withDirectives(createVNode("input", {
                            "onUpdate:modelValue": ($event) => noticeForm.value.date = $event,
                            type: "date",
                            class: "w-full px-4 py-2 border rounded-lg dark:bg-gray-800 dark:border-gray-700",
                            required: ""
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, noticeForm.value.date]
                          ])
                        ]),
                        createVNode("div", { class: "flex justify-end" }, [
                          createVNode("button", {
                            type: "button",
                            onClick: closeNoticeModal,
                            class: "mr-2 px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-colors"
                          }, " Cancel "),
                          createVNode("button", {
                            type: "submit",
                            class: "px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"
                          }, toDisplayString(isEditingNotice.value ? "Update" : "Save"), 1)
                        ])
                      ], 32)
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$1, {
              show: isEventModalOpen.value,
              onClose: closeEventModal
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="p-6"${_scopeId2}><h3 class="text-xl font-semibold mb-4"${_scopeId2}>${ssrInterpolate(isEditingEvent.value ? "Edit Event" : "Add Event")}</h3><form${_scopeId2}><div class="mb-4"${_scopeId2}><label class="block text-gray-700 dark:text-gray-300 mb-2"${_scopeId2}>Title</label><input${ssrRenderAttr("value", eventForm.value.title)} type="text" class="w-full px-4 py-2 border rounded-lg dark:bg-gray-800 dark:border-gray-700" required${_scopeId2}></div><div class="mb-4"${_scopeId2}><label class="block text-gray-700 dark:text-gray-300 mb-2"${_scopeId2}>Description</label><textarea class="w-full px-4 py-2 border rounded-lg dark:bg-gray-800 dark:border-gray-700" rows="4" required${_scopeId2}>${ssrInterpolate(eventForm.value.description)}</textarea></div><div class="mb-4"${_scopeId2}><label class="block text-gray-700 dark:text-gray-300 mb-2"${_scopeId2}>Date</label><input${ssrRenderAttr("value", eventForm.value.date)} type="date" class="w-full px-4 py-2 border rounded-lg dark:bg-gray-800 dark:border-gray-700" required${_scopeId2}></div><div class="flex justify-end"${_scopeId2}><button type="button" class="mr-2 px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-colors"${_scopeId2}> Cancel </button><button type="submit" class="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"${_scopeId2}>${ssrInterpolate(isEditingEvent.value ? "Update" : "Save")}</button></div></form></div>`);
                } else {
                  return [
                    createVNode("div", { class: "p-6" }, [
                      createVNode("h3", { class: "text-xl font-semibold mb-4" }, toDisplayString(isEditingEvent.value ? "Edit Event" : "Add Event"), 1),
                      createVNode("form", {
                        onSubmit: withModifiers(saveEvent, ["prevent"])
                      }, [
                        createVNode("div", { class: "mb-4" }, [
                          createVNode("label", { class: "block text-gray-700 dark:text-gray-300 mb-2" }, "Title"),
                          withDirectives(createVNode("input", {
                            "onUpdate:modelValue": ($event) => eventForm.value.title = $event,
                            type: "text",
                            class: "w-full px-4 py-2 border rounded-lg dark:bg-gray-800 dark:border-gray-700",
                            required: ""
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, eventForm.value.title]
                          ])
                        ]),
                        createVNode("div", { class: "mb-4" }, [
                          createVNode("label", { class: "block text-gray-700 dark:text-gray-300 mb-2" }, "Description"),
                          withDirectives(createVNode("textarea", {
                            "onUpdate:modelValue": ($event) => eventForm.value.description = $event,
                            class: "w-full px-4 py-2 border rounded-lg dark:bg-gray-800 dark:border-gray-700",
                            rows: "4",
                            required: ""
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, eventForm.value.description]
                          ])
                        ]),
                        createVNode("div", { class: "mb-4" }, [
                          createVNode("label", { class: "block text-gray-700 dark:text-gray-300 mb-2" }, "Date"),
                          withDirectives(createVNode("input", {
                            "onUpdate:modelValue": ($event) => eventForm.value.date = $event,
                            type: "date",
                            class: "w-full px-4 py-2 border rounded-lg dark:bg-gray-800 dark:border-gray-700",
                            required: ""
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, eventForm.value.date]
                          ])
                        ]),
                        createVNode("div", { class: "flex justify-end" }, [
                          createVNode("button", {
                            type: "button",
                            onClick: closeEventModal,
                            class: "mr-2 px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-colors"
                          }, " Cancel "),
                          createVNode("button", {
                            type: "submit",
                            class: "px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"
                          }, toDisplayString(isEditingEvent.value ? "Update" : "Save"), 1)
                        ])
                      ], 32)
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode("div", { class: "p-6" }, [
                isLoading.value ? (openBlock(), createBlock("div", {
                  key: 0,
                  class: "fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50"
                }, [
                  createVNode("div", { class: "relative w-16 h-16" }, [
                    createVNode("div", { class: "w-full h-full border-4 border-transparent border-t-green-500 border-r-green-500 rounded-full animate-spin" }),
                    createVNode("div", { class: "absolute inset-2 w-12 h-12 border-4 border-transparent border-t-gray-300 border-r-gray-300 rounded-full animate-spin-slow" })
                  ])
                ])) : createCommentVNode("", true),
                error.value ? (openBlock(), createBlock("div", {
                  key: 1,
                  class: "mb-6 p-4 bg-red-100 border border-red-400 text-red-700 rounded-lg"
                }, [
                  createVNode("p", null, toDisplayString(error.value), 1)
                ])) : createCommentVNode("", true),
                createVNode("div", { class: "grid grid-cols-1 md:grid-cols-3 gap-6 mb-8" }, [
                  createVNode("div", { class: "bg-white dark:bg-gray-700 p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow" }, [
                    createVNode("h3", { class: "text-lg font-semibold text-gray-700 dark:text-gray-200" }, "Total Employees"),
                    createVNode("p", { class: "text-2xl font-bold text-gray-900 dark:text-gray-100" }, toDisplayString(__props.usersCount), 1)
                  ]),
                  createVNode("div", { class: "bg-white dark:bg-gray-700 p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow" }, [
                    createVNode("h3", { class: "text-lg font-semibold text-gray-700 dark:text-gray-200" }, "Active Employees"),
                    createVNode("p", { class: "text-2xl font-bold text-gray-900 dark:text-gray-100" }, toDisplayString(__props.activeUsersCount), 1)
                  ]),
                  createVNode("div", { class: "bg-white dark:bg-gray-700 p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow" }, [
                    createVNode("h3", { class: "text-lg font-semibold text-gray-700 dark:text-gray-200" }, "New Hires (This Month)"),
                    createVNode("p", { class: "text-2xl font-bold text-gray-900 dark:text-gray-100" }, toDisplayString(__props.newUsersCount), 1)
                  ])
                ]),
                createVNode("div", { class: "bg-white dark:bg-gray-700 p-6 rounded-lg shadow-sm mb-8" }, [
                  createVNode("div", { class: "flex items-center justify-between mb-4" }, [
                    createVNode("h3", { class: "text-xl font-semibold text-gray-800 dark:text-gray-200" }, "Notice Board"),
                    unref(is)("Super Admin") ? (openBlock(), createBlock("button", {
                      key: 0,
                      onClick: () => openNoticeModal(),
                      class: "px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"
                    }, " Add Notice ", 8, ["onClick"])) : createCommentVNode("", true)
                  ]),
                  createVNode("div", { class: "h-64 overflow-y-auto space-y-4" }, [
                    (openBlock(true), createBlock(Fragment, null, renderList(notices.value, (notice, index) => {
                      return openBlock(), createBlock("div", {
                        key: notice.id,
                        class: "p-4 bg-gray-50 dark:bg-gray-600 rounded-lg relative group"
                      }, [
                        createVNode("h4", { class: "text-lg font-semibold text-gray-700 dark:text-gray-200" }, toDisplayString(notice.title), 1),
                        createVNode("p", { class: "text-gray-600 dark:text-gray-300 mt-2" }, toDisplayString(notice.description), 1),
                        createVNode("p", { class: "text-sm text-gray-500 dark:text-gray-400 mt-2" }, "Posted on: " + toDisplayString(notice.date), 1),
                        createVNode("div", { class: "absolute top-2 right-2 flex space-x-2 opacity-0 group-hover:opacity-100 transition-opacity" }, [
                          unref(is)("Super Admin") ? (openBlock(), createBlock("button", {
                            key: 0,
                            onClick: () => editNotice(index),
                            class: "p-1 text-green-500 hover:text-green-600"
                          }, [
                            createVNode(unref(PencilIcon), { class: "w-5 h-5" })
                          ], 8, ["onClick"])) : createCommentVNode("", true),
                          unref(is)("Super Admin") ? (openBlock(), createBlock("button", {
                            key: 1,
                            onClick: () => deleteNotice(index),
                            class: "p-1 text-red-500 hover:text-red-600"
                          }, [
                            createVNode(unref(TrashIcon), { class: "w-5 h-5" })
                          ], 8, ["onClick"])) : createCommentVNode("", true)
                        ])
                      ]);
                    }), 128))
                  ])
                ]),
                createVNode("div", { class: "bg-white dark:bg-gray-700 p-6 rounded-lg shadow-sm mb-8" }, [
                  createVNode("div", { class: "flex items-center justify-between mb-4" }, [
                    createVNode("h3", { class: "text-xl font-semibold text-gray-800 dark:text-gray-200" }, "Upcoming Events"),
                    unref(is)("Super Admin") ? (openBlock(), createBlock("button", {
                      key: 0,
                      onClick: () => openEventModal(),
                      class: "px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"
                    }, " Add Event ", 8, ["onClick"])) : createCommentVNode("", true)
                  ]),
                  createVNode("div", { class: "h-64 overflow-y-auto space-y-4" }, [
                    (openBlock(true), createBlock(Fragment, null, renderList(events.value, (event, index) => {
                      return openBlock(), createBlock("div", {
                        key: event.id,
                        class: "p-4 bg-gray-50 dark:bg-gray-600 rounded-lg relative group"
                      }, [
                        createVNode("h4", { class: "text-lg font-semibold text-gray-700 dark:text-gray-200" }, toDisplayString(event.title), 1),
                        createVNode("p", { class: "text-gray-600 dark:text-gray-300 mt-2" }, toDisplayString(event.description), 1),
                        createVNode("p", { class: "text-sm text-gray-500 dark:text-gray-400 mt-2" }, "Date: " + toDisplayString(event.date), 1),
                        createVNode("div", { class: "absolute top-2 right-2 flex space-x-2 opacity-0 group-hover:opacity-100 transition-opacity" }, [
                          unref(is)("Super Admin") ? (openBlock(), createBlock("button", {
                            key: 0,
                            onClick: () => editEvent(index),
                            class: "p-1 text-green-500 hover:text-green-600"
                          }, [
                            createVNode(unref(PencilIcon), { class: "w-5 h-5" })
                          ], 8, ["onClick"])) : createCommentVNode("", true),
                          unref(is)("Super Admin") ? (openBlock(), createBlock("button", {
                            key: 1,
                            onClick: () => deleteEvent(index),
                            class: "p-1 text-red-500 hover:text-red-600"
                          }, [
                            createVNode(unref(TrashIcon), { class: "w-5 h-5" })
                          ], 8, ["onClick"])) : createCommentVNode("", true)
                        ])
                      ]);
                    }), 128))
                  ])
                ]),
                createVNode("div", { class: "bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg mb-8" }, [
                  createVNode("h3", { class: "text-2xl font-semibold text-gray-900 dark:text-gray-100 mb-6" }, "Recent Employee Activity"),
                  createVNode("ul", { class: "space-y-5" }, [
                    (openBlock(true), createBlock(Fragment, null, renderList(__props.logs, (log) => {
                      return openBlock(), createBlock("li", {
                        key: log.id,
                        class: "flex items-center justify-between bg-gray-50 dark:bg-gray-700 p-4 rounded-lg shadow-sm hover:bg-gray-100 dark:hover:bg-gray-600 transition duration-200"
                      }, [
                        createVNode("span", { class: "text-gray-700 dark:text-gray-300 text-base" }, [
                          createVNode("strong", { class: "font-medium" }, toDisplayString(log.action) + ":", 1),
                          createTextVNode(" " + toDisplayString(log.user_name) + " ", 1),
                          createVNode("span", { class: "text-gray-600 dark:text-gray-400" }, toDisplayString(log.description), 1)
                        ]),
                        createVNode("span", { class: "text-sm text-gray-500 dark:text-gray-400" }, toDisplayString(formatDate(log.created_at)), 1)
                      ]);
                    }), 128))
                  ])
                ])
              ]),
              createVNode(_sfc_main$1, {
                show: isNoticeModalOpen.value,
                onClose: closeNoticeModal
              }, {
                default: withCtx(() => [
                  createVNode("div", { class: "p-6" }, [
                    createVNode("h3", { class: "text-xl font-semibold mb-4" }, toDisplayString(isEditingNotice.value ? "Edit Notice" : "Add Notice"), 1),
                    createVNode("form", {
                      onSubmit: withModifiers(saveNotice, ["prevent"])
                    }, [
                      createVNode("div", { class: "mb-4" }, [
                        createVNode("label", { class: "block text-gray-700 dark:text-gray-300 mb-2" }, "Title"),
                        withDirectives(createVNode("input", {
                          "onUpdate:modelValue": ($event) => noticeForm.value.title = $event,
                          type: "text",
                          class: "w-full px-4 py-2 border rounded-lg dark:bg-gray-800 dark:border-gray-700",
                          required: ""
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, noticeForm.value.title]
                        ])
                      ]),
                      createVNode("div", { class: "mb-4" }, [
                        createVNode("label", { class: "block text-gray-700 dark:text-gray-300 mb-2" }, "Description"),
                        withDirectives(createVNode("textarea", {
                          "onUpdate:modelValue": ($event) => noticeForm.value.description = $event,
                          class: "w-full px-4 py-2 border rounded-lg dark:bg-gray-800 dark:border-gray-700",
                          rows: "4",
                          required: ""
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, noticeForm.value.description]
                        ])
                      ]),
                      createVNode("div", { class: "mb-4" }, [
                        createVNode("label", { class: "block text-gray-700 dark:text-gray-300 mb-2" }, "Date"),
                        withDirectives(createVNode("input", {
                          "onUpdate:modelValue": ($event) => noticeForm.value.date = $event,
                          type: "date",
                          class: "w-full px-4 py-2 border rounded-lg dark:bg-gray-800 dark:border-gray-700",
                          required: ""
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, noticeForm.value.date]
                        ])
                      ]),
                      createVNode("div", { class: "flex justify-end" }, [
                        createVNode("button", {
                          type: "button",
                          onClick: closeNoticeModal,
                          class: "mr-2 px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-colors"
                        }, " Cancel "),
                        createVNode("button", {
                          type: "submit",
                          class: "px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"
                        }, toDisplayString(isEditingNotice.value ? "Update" : "Save"), 1)
                      ])
                    ], 32)
                  ])
                ]),
                _: 1
              }, 8, ["show"]),
              createVNode(_sfc_main$1, {
                show: isEventModalOpen.value,
                onClose: closeEventModal
              }, {
                default: withCtx(() => [
                  createVNode("div", { class: "p-6" }, [
                    createVNode("h3", { class: "text-xl font-semibold mb-4" }, toDisplayString(isEditingEvent.value ? "Edit Event" : "Add Event"), 1),
                    createVNode("form", {
                      onSubmit: withModifiers(saveEvent, ["prevent"])
                    }, [
                      createVNode("div", { class: "mb-4" }, [
                        createVNode("label", { class: "block text-gray-700 dark:text-gray-300 mb-2" }, "Title"),
                        withDirectives(createVNode("input", {
                          "onUpdate:modelValue": ($event) => eventForm.value.title = $event,
                          type: "text",
                          class: "w-full px-4 py-2 border rounded-lg dark:bg-gray-800 dark:border-gray-700",
                          required: ""
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, eventForm.value.title]
                        ])
                      ]),
                      createVNode("div", { class: "mb-4" }, [
                        createVNode("label", { class: "block text-gray-700 dark:text-gray-300 mb-2" }, "Description"),
                        withDirectives(createVNode("textarea", {
                          "onUpdate:modelValue": ($event) => eventForm.value.description = $event,
                          class: "w-full px-4 py-2 border rounded-lg dark:bg-gray-800 dark:border-gray-700",
                          rows: "4",
                          required: ""
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, eventForm.value.description]
                        ])
                      ]),
                      createVNode("div", { class: "mb-4" }, [
                        createVNode("label", { class: "block text-gray-700 dark:text-gray-300 mb-2" }, "Date"),
                        withDirectives(createVNode("input", {
                          "onUpdate:modelValue": ($event) => eventForm.value.date = $event,
                          type: "date",
                          class: "w-full px-4 py-2 border rounded-lg dark:bg-gray-800 dark:border-gray-700",
                          required: ""
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, eventForm.value.date]
                        ])
                      ]),
                      createVNode("div", { class: "flex justify-end" }, [
                        createVNode("button", {
                          type: "button",
                          onClick: closeEventModal,
                          class: "mr-2 px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-colors"
                        }, " Cancel "),
                        createVNode("button", {
                          type: "submit",
                          class: "px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"
                        }, toDisplayString(isEditingEvent.value ? "Update" : "Save"), 1)
                      ])
                    ], 32)
                  ])
                ]),
                _: 1
              }, 8, ["show"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Dashboard.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
