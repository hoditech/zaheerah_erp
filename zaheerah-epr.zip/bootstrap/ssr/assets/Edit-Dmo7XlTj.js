import { defineComponent, reactive, unref, withCtx, createVNode, withModifiers, withDirectives, openBlock, createBlock, Fragment, renderList, toDisplayString, vModelSelect, vModelText, useSSRContext } from "vue";
import { ssrRenderComponent, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual, ssrRenderList, ssrRenderAttr, ssrInterpolate } from "vue/server-renderer";
import { A as AuthenticatedLayout } from "./AuthenticatedLayout-DpiUQPiV.js";
import { Head, router } from "@inertiajs/vue3";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Edit",
  __ssrInlineRender: true,
  props: {
    production: {},
    categories: {}
  },
  setup(__props) {
    const props = __props;
    const form = reactive({
      quantity: props.production.quantity,
      material_cost: props.production.material_cost,
      labor_cost: props.production.labor_cost,
      overhead_cost: props.production.labor_cost,
      batch_status: props.production.batch_status,
      description: props.production.description,
      product_id: props.production.product_id
    });
    const updateProductionBatch = () => {
      router.put(route("productions.update", props.production.id), form);
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Edit Production Batch" }, null, _parent));
      _push(ssrRenderComponent(AuthenticatedLayout, null, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<h2 class="text-xl font-semibold leading-tight text-gray-800 dark:text-gray-200"${_scopeId}> Edit Production Batch </h2>`);
          } else {
            return [
              createVNode("h2", { class: "text-xl font-semibold leading-tight text-gray-800 dark:text-gray-200" }, " Edit Production Batch ")
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="py-12"${_scopeId}><div class="mx-auto max-w-7xl space-y-6 sm:px-6 lg:px-8"${_scopeId}><div class="bg-white p-4 shadow sm:rounded-lg sm:p-8 dark:bg-gray-800"${_scopeId}><form${_scopeId}><div class="mb-8"${_scopeId}><h3 class="text-lg font-medium text-black dark:text-gray-200 py-4"${_scopeId}>Batch Details</h3><div class="grid grid-cols-1 gap-6 sm:grid-cols-2"${_scopeId}><div${_scopeId}><label for="product" class="block text-sm font-medium text-gray-700 dark:text-gray-300"${_scopeId}>Category</label><select id="product" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500 dark:bg-gray-700 dark:text-white dark:border-gray-600 dark:focus:ring-green-500 dark:focus:border-green-500" required${_scopeId}><option value="" disabled${ssrIncludeBooleanAttr(Array.isArray(form.product_id) ? ssrLooseContain(form.product_id, "") : ssrLooseEqual(form.product_id, "")) ? " selected" : ""}${_scopeId}>Select a Product</option><!--[-->`);
            ssrRenderList(_ctx.categories, (category) => {
              _push2(`<option${ssrRenderAttr("value", category.id)}${_scopeId}>${ssrInterpolate(category.name)}</option>`);
            });
            _push2(`<!--]--></select></div><div${_scopeId}><label for="quantity" class="block text-sm font-medium text-gray-700 dark:text-gray-300"${_scopeId}>Quantity</label><input${ssrRenderAttr("value", form.quantity)} type="number" id="quantity" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500 dark:bg-gray-700 dark:text-white dark:border-gray-600 dark:focus:ring-green-500 dark:focus:border-green-500" required${_scopeId}></div></div></div><div class="mb-8"${_scopeId}><h3 class="text-lg font-medium text-gray-900 dark:text-gray-200"${_scopeId}>Costs</h3><div class="grid grid-cols-1 gap-6 sm:grid-cols-3"${_scopeId}><div${_scopeId}><label for="material_cost" class="block text-sm font-medium text-gray-700 dark:text-gray-300"${_scopeId}>Material Cost</label><input${ssrRenderAttr("value", form.material_cost)} type="number" id="material_cost" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500 dark:bg-gray-700 dark:text-white dark:border-gray-600 dark:focus:ring-green-500 dark:focus:border-green-500"${_scopeId}></div><div${_scopeId}><label for="labor_cost" class="block text-sm font-medium text-gray-700 dark:text-gray-300"${_scopeId}>Labor Cost</label><input${ssrRenderAttr("value", form.labor_cost)} type="number" id="labor_cost" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500 dark:bg-gray-700 dark:text-white dark:border-gray-600 dark:focus:ring-green-500 dark:focus:border-green-500"${_scopeId}></div><div${_scopeId}><label for="overhead_cost" class="block text-sm font-medium text-gray-700 dark:text-gray-300"${_scopeId}>Overhead Cost</label><input${ssrRenderAttr("value", form.overhead_cost)} type="number" id="overhead_cost" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500 dark:bg-gray-700 dark:text-white dark:border-gray-600 dark:focus:ring-green-500 dark:focus:border-green-500"${_scopeId}></div></div></div><div class="mb-8"${_scopeId}><h3 class="text-lg font-medium text-black dark:text-gray-200 py-4"${_scopeId}>Additional Information</h3><div class="mb-6"${_scopeId}><label for="status" class="block text-sm font-medium text-gray-700 dark:text-gray-300"${_scopeId}>Status</label><select id="status" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 dark:bg-gray-700 dark:text-white dark:border-gray-600 dark:focus:ring-indigo-500 dark:focus:border-indigo-500" required${_scopeId}><option value="" disabled${ssrIncludeBooleanAttr(Array.isArray(form.batch_status) ? ssrLooseContain(form.batch_status, "") : ssrLooseEqual(form.batch_status, "")) ? " selected" : ""}${_scopeId}>Select Status</option><option value="Pending"${ssrIncludeBooleanAttr(Array.isArray(form.batch_status) ? ssrLooseContain(form.batch_status, "Pending") : ssrLooseEqual(form.batch_status, "Pending")) ? " selected" : ""}${_scopeId}>Pending</option><option value="In Progress"${ssrIncludeBooleanAttr(Array.isArray(form.batch_status) ? ssrLooseContain(form.batch_status, "In Progress") : ssrLooseEqual(form.batch_status, "In Progress")) ? " selected" : ""}${_scopeId}>In Progress</option><option value="Completed"${ssrIncludeBooleanAttr(Array.isArray(form.batch_status) ? ssrLooseContain(form.batch_status, "Completed") : ssrLooseEqual(form.batch_status, "Completed")) ? " selected" : ""}${_scopeId}>Completed</option><option value="Cancelled"${ssrIncludeBooleanAttr(Array.isArray(form.batch_status) ? ssrLooseContain(form.batch_status, "Cancelled") : ssrLooseEqual(form.batch_status, "Cancelled")) ? " selected" : ""}${_scopeId}>Cancelled</option></select></div><div class="mb-8"${_scopeId}><label for="description" class="block text-sm font-medium text-gray-700 dark:text-gray-300"${_scopeId}>Description</label><textarea id="description" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500 dark:bg-gray-700 dark:text-white dark:border-gray-600 dark:focus:ring-green-500 dark:focus:border-green-500" rows="3"${_scopeId}>${ssrInterpolate(form.description)}</textarea></div></div><div class="flex justify-end space-x-4"${_scopeId}><button type="button" class="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-200 rounded-md hover:bg-gray-300 dark:text-gray-300 dark:bg-gray-700 dark:hover:bg-gray-600"${_scopeId}> Cancel </button><button type="submit" class="px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 dark:bg-green-500 dark:hover:bg-green-600"${_scopeId}> Save Changes </button></div></form></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "py-12" }, [
                createVNode("div", { class: "mx-auto max-w-7xl space-y-6 sm:px-6 lg:px-8" }, [
                  createVNode("div", { class: "bg-white p-4 shadow sm:rounded-lg sm:p-8 dark:bg-gray-800" }, [
                    createVNode("form", {
                      onSubmit: withModifiers(updateProductionBatch, ["prevent"])
                    }, [
                      createVNode("div", { class: "mb-8" }, [
                        createVNode("h3", { class: "text-lg font-medium text-black dark:text-gray-200 py-4" }, "Batch Details"),
                        createVNode("div", { class: "grid grid-cols-1 gap-6 sm:grid-cols-2" }, [
                          createVNode("div", null, [
                            createVNode("label", {
                              for: "product",
                              class: "block text-sm font-medium text-gray-700 dark:text-gray-300"
                            }, "Category"),
                            withDirectives(createVNode("select", {
                              "onUpdate:modelValue": ($event) => form.product_id = $event,
                              id: "product",
                              class: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500 dark:bg-gray-700 dark:text-white dark:border-gray-600 dark:focus:ring-green-500 dark:focus:border-green-500",
                              required: ""
                            }, [
                              createVNode("option", {
                                value: "",
                                disabled: ""
                              }, "Select a Product"),
                              (openBlock(true), createBlock(Fragment, null, renderList(_ctx.categories, (category) => {
                                return openBlock(), createBlock("option", {
                                  key: category.id,
                                  value: category.id
                                }, toDisplayString(category.name), 9, ["value"]);
                              }), 128))
                            ], 8, ["onUpdate:modelValue"]), [
                              [vModelSelect, form.product_id]
                            ])
                          ]),
                          createVNode("div", null, [
                            createVNode("label", {
                              for: "quantity",
                              class: "block text-sm font-medium text-gray-700 dark:text-gray-300"
                            }, "Quantity"),
                            withDirectives(createVNode("input", {
                              "onUpdate:modelValue": ($event) => form.quantity = $event,
                              type: "number",
                              id: "quantity",
                              class: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500 dark:bg-gray-700 dark:text-white dark:border-gray-600 dark:focus:ring-green-500 dark:focus:border-green-500",
                              required: ""
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [vModelText, form.quantity]
                            ])
                          ])
                        ])
                      ]),
                      createVNode("div", { class: "mb-8" }, [
                        createVNode("h3", { class: "text-lg font-medium text-gray-900 dark:text-gray-200" }, "Costs"),
                        createVNode("div", { class: "grid grid-cols-1 gap-6 sm:grid-cols-3" }, [
                          createVNode("div", null, [
                            createVNode("label", {
                              for: "material_cost",
                              class: "block text-sm font-medium text-gray-700 dark:text-gray-300"
                            }, "Material Cost"),
                            withDirectives(createVNode("input", {
                              "onUpdate:modelValue": ($event) => form.material_cost = $event,
                              type: "number",
                              id: "material_cost",
                              class: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500 dark:bg-gray-700 dark:text-white dark:border-gray-600 dark:focus:ring-green-500 dark:focus:border-green-500"
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [vModelText, form.material_cost]
                            ])
                          ]),
                          createVNode("div", null, [
                            createVNode("label", {
                              for: "labor_cost",
                              class: "block text-sm font-medium text-gray-700 dark:text-gray-300"
                            }, "Labor Cost"),
                            withDirectives(createVNode("input", {
                              "onUpdate:modelValue": ($event) => form.labor_cost = $event,
                              type: "number",
                              id: "labor_cost",
                              class: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500 dark:bg-gray-700 dark:text-white dark:border-gray-600 dark:focus:ring-green-500 dark:focus:border-green-500"
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [vModelText, form.labor_cost]
                            ])
                          ]),
                          createVNode("div", null, [
                            createVNode("label", {
                              for: "overhead_cost",
                              class: "block text-sm font-medium text-gray-700 dark:text-gray-300"
                            }, "Overhead Cost"),
                            withDirectives(createVNode("input", {
                              "onUpdate:modelValue": ($event) => form.overhead_cost = $event,
                              type: "number",
                              id: "overhead_cost",
                              class: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500 dark:bg-gray-700 dark:text-white dark:border-gray-600 dark:focus:ring-green-500 dark:focus:border-green-500"
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [vModelText, form.overhead_cost]
                            ])
                          ])
                        ])
                      ]),
                      createVNode("div", { class: "mb-8" }, [
                        createVNode("h3", { class: "text-lg font-medium text-black dark:text-gray-200 py-4" }, "Additional Information"),
                        createVNode("div", { class: "mb-6" }, [
                          createVNode("label", {
                            for: "status",
                            class: "block text-sm font-medium text-gray-700 dark:text-gray-300"
                          }, "Status"),
                          withDirectives(createVNode("select", {
                            "onUpdate:modelValue": ($event) => form.batch_status = $event,
                            id: "status",
                            class: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 dark:bg-gray-700 dark:text-white dark:border-gray-600 dark:focus:ring-indigo-500 dark:focus:border-indigo-500",
                            required: ""
                          }, [
                            createVNode("option", {
                              value: "",
                              disabled: ""
                            }, "Select Status"),
                            createVNode("option", { value: "Pending" }, "Pending"),
                            createVNode("option", { value: "In Progress" }, "In Progress"),
                            createVNode("option", { value: "Completed" }, "Completed"),
                            createVNode("option", { value: "Cancelled" }, "Cancelled")
                          ], 8, ["onUpdate:modelValue"]), [
                            [vModelSelect, form.batch_status]
                          ])
                        ]),
                        createVNode("div", { class: "mb-8" }, [
                          createVNode("label", {
                            for: "description",
                            class: "block text-sm font-medium text-gray-700 dark:text-gray-300"
                          }, "Description"),
                          withDirectives(createVNode("textarea", {
                            "onUpdate:modelValue": ($event) => form.description = $event,
                            id: "description",
                            class: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500 dark:bg-gray-700 dark:text-white dark:border-gray-600 dark:focus:ring-green-500 dark:focus:border-green-500",
                            rows: "3"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, form.description]
                          ])
                        ])
                      ]),
                      createVNode("div", { class: "flex justify-end space-x-4" }, [
                        createVNode("button", {
                          type: "button",
                          onClick: ($event) => _ctx.$inertia.visit(_ctx.route("production-batches.index")),
                          class: "px-4 py-2 text-sm font-medium text-gray-700 bg-gray-200 rounded-md hover:bg-gray-300 dark:text-gray-300 dark:bg-gray-700 dark:hover:bg-gray-600"
                        }, " Cancel ", 8, ["onClick"]),
                        createVNode("button", {
                          type: "submit",
                          onClick: updateProductionBatch,
                          class: "px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 dark:bg-green-500 dark:hover:bg-green-600"
                        }, " Save Changes ")
                      ])
                    ], 32)
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/ProductionBatches/Edit.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
