import { defineComponent, ref, unref, withCtx, createVNode, withDirectives, vModelText, openBlock, createBlock, Fragment, renderList, toDisplayString, vModelSelect, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderAttr, ssrRenderList, ssrInterpolate } from "vue/server-renderer";
import { A as AuthenticatedLayout } from "./AuthenticatedLayout-D1TzY3dv.js";
import { Head, router } from "@inertiajs/vue3";
import "laravel-permission-to-vuejs";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Index",
  __ssrInlineRender: true,
  props: {
    products: {}
  },
  setup(__props) {
    const props = __props;
    const cartItems = ref([]);
    const selectedCategory = ref("All");
    const searchQuery = ref("");
    const receiptTotal = ref(0);
    const showReceipt = ref(false);
    const receiptItems = ref([]);
    const categories = ["All", ...new Set(props.products.map((product) => product.category.name))];
    const addToCart = (product) => {
      const existingItem = cartItems.value.find((item) => item.id === product.id);
      if (existingItem) {
        existingItem.quantity++;
      } else {
        cartItems.value.push({ ...product, quantity: 1 });
      }
    };
    const removeFromCart = (productId) => {
      cartItems.value = cartItems.value.filter((item) => item.id !== productId);
    };
    const updateQuantity = (productId, quantity) => {
      const item = cartItems.value.find((item2) => item2.id === productId);
      if (item) item.quantity = quantity > 0 ? quantity : 1;
    };
    const calculateTotal = () => {
      return cartItems.value.reduce((total, item) => total + item.price * item.quantity, 0);
    };
    const filteredProducts = () => {
      return props.products.filter((product) => {
        return (selectedCategory.value === "All" || product.category.name === selectedCategory.value) && product.name.toLowerCase().includes(searchQuery.value.toLowerCase());
      });
    };
    const checkout = async () => {
      if (cartItems.value.length === 0) {
        alert("Cart is empty!");
        return;
      }
      const saleData = {
        total_amount: calculateTotal(),
        items: cartItems.value.map((item) => ({
          product_id: item.id,
          name: item.name,
          quantity: item.quantity,
          price: item.price
        }))
      };
      try {
        await router.post("/pos/make-sale", saleData);
        receiptItems.value = saleData.items;
        receiptTotal.value = saleData.total_amount;
        showReceipt.value = true;
        cartItems.value = [];
        cartItems.value = [];
      } catch (error) {
        console.error(error);
        alert("Failed to complete sale.");
      }
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "POS" }, null, _parent));
      _push(ssrRenderComponent(AuthenticatedLayout, null, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<h2 class="text-2xl font-bold leading-tight text-gray-800 dark:text-gray-200"${_scopeId}>Point of Sale</h2>`);
          } else {
            return [
              createVNode("h2", { class: "text-2xl font-bold leading-tight text-gray-800 dark:text-gray-200" }, "Point of Sale")
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="py-6"${_scopeId}><div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8"${_scopeId}><div class="flex flex-col lg:flex-row bg-gray-50 dark:bg-gray-900 text-gray-800 dark:text-gray-100 rounded-lg shadow-lg overflow-hidden"${_scopeId}><main class="flex-1 flex flex-col lg:flex-row lg:space-x-8 p-4 lg:p-8"${_scopeId}><section class="w-full lg:w-2/3 mb-8 lg:mb-0"${_scopeId}><div class="flex justify-between items-center mb-4"${_scopeId}><h3 class="text-lg font-semibold text-gray-700 dark:text-gray-300"${_scopeId}>Products</h3><input${ssrRenderAttr("value", searchQuery.value)} type="text" placeholder="Search products..." class="w-full sm:w-80 p-3 border border-gray-300 rounded-lg dark:bg-gray-700 dark:border-gray-600 text-gray-700 dark:text-gray-300 focus:outline-none focus:ring-2 focus:ring-green-500 transition"${_scopeId}></div><div class="mb-4"${_scopeId}><select class="w-full sm:w-40 p-2 border border-gray-300 rounded-lg dark:bg-gray-700 dark:border-gray-600 text-gray-700 dark:text-gray-300"${_scopeId}><!--[-->`);
            ssrRenderList(categories, (category) => {
              _push2(`<option${_scopeId}>${ssrInterpolate(category)}</option>`);
            });
            _push2(`<!--]--></select></div><div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 lg:gap-6"${_scopeId}><!--[-->`);
            ssrRenderList(filteredProducts(), (product) => {
              _push2(`<div class="bg-white dark:bg-gray-800 shadow-md rounded-lg p-4 transition hover:shadow-lg"${_scopeId}><div class="h-32 sm:h-40 bg-gray-200 dark:bg-gray-700 rounded-md mb-3 flex items-center justify-center overflow-hidden"${_scopeId}><img${ssrRenderAttr("src", product.image)} alt="Product Image" class="object-cover h-full w-full"${_scopeId}></div><h4 class="text-sm sm:text-lg font-semibold text-gray-700 dark:text-gray-300"${_scopeId}>${ssrInterpolate(product.name)}</h4><p class="text-xs text-gray-500 dark:text-gray-400"${_scopeId}>${ssrInterpolate(product.category.name)}</p><p class="text-sm sm:text-md font-bold mt-2 text-gray-800 dark:text-gray-100"${_scopeId}>₦${ssrInterpolate(product.price)}</p><button class="mt-3 w-full py-2 bg-green-500 hover:bg-green-600 text-white font-semibold rounded-lg transition"${_scopeId}> Add to Cart </button></div>`);
            });
            _push2(`<!--]--></div></section><section class="w-full lg:w-1/3 bg-white dark:bg-gray-800 rounded-lg shadow-lg p-4 lg:p-6"${_scopeId}><h3 class="text-lg font-semibold text-gray-700 dark:text-gray-300"${_scopeId}>Cart</h3><ul class="mt-4 lg:mt-6 space-y-4"${_scopeId}><!--[-->`);
            ssrRenderList(cartItems.value, (item) => {
              _push2(`<li class="flex justify-between items-center border-b border-gray-200 dark:border-gray-700 pb-2"${_scopeId}><div${_scopeId}><h4 class="text-sm font-semibold text-gray-700 dark:text-gray-300"${_scopeId}>${ssrInterpolate(item.name)}</h4><div class="flex items-center space-x-2 mt-1"${_scopeId}><input type="number"${ssrRenderAttr("value", item.quantity)} class="w-12 sm:w-16 p-1 border border-gray-300 rounded dark:bg-gray-700 dark:border-gray-600 text-center focus:outline-none" min="1"${_scopeId}><p class="text-xs text-gray-500 dark:text-gray-400"${_scopeId}>x ₦${ssrInterpolate(item.price)}</p></div></div><div class="flex items-center space-x-3"${_scopeId}><p class="font-semibold text-gray-800 dark:text-gray-100"${_scopeId}>₦${ssrInterpolate(item.price * item.quantity)}</p><button class="text-red-500 hover:text-red-600 text-sm font-bold"${_scopeId}>✕</button></div></li>`);
            });
            _push2(`<!--]--></ul><div class="mt-6 lg:mt-8 pt-4 border-t border-gray-200 dark:border-gray-700 space-y-4"${_scopeId}><div class="flex justify-between text-md sm:text-lg font-semibold text-gray-700 dark:text-gray-300"${_scopeId}><span${_scopeId}>Total:</span><span${_scopeId}>₦${ssrInterpolate(calculateTotal())}</span></div><button class="w-full py-3 bg-green-600 hover:bg-green-700 text-white font-bold rounded-lg shadow-md transition"${_scopeId}>Checkout</button><button class="w-full py-3 bg-gray-300 hover:bg-gray-400 text-gray-700 font-bold rounded-lg shadow-md transition dark:bg-gray-600 dark:hover:bg-gray-500 dark:text-gray-200"${_scopeId}> Clear Cart </button></div></section></main></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "py-6" }, [
                createVNode("div", { class: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8" }, [
                  createVNode("div", { class: "flex flex-col lg:flex-row bg-gray-50 dark:bg-gray-900 text-gray-800 dark:text-gray-100 rounded-lg shadow-lg overflow-hidden" }, [
                    createVNode("main", { class: "flex-1 flex flex-col lg:flex-row lg:space-x-8 p-4 lg:p-8" }, [
                      createVNode("section", { class: "w-full lg:w-2/3 mb-8 lg:mb-0" }, [
                        createVNode("div", { class: "flex justify-between items-center mb-4" }, [
                          createVNode("h3", { class: "text-lg font-semibold text-gray-700 dark:text-gray-300" }, "Products"),
                          withDirectives(createVNode("input", {
                            "onUpdate:modelValue": ($event) => searchQuery.value = $event,
                            type: "text",
                            placeholder: "Search products...",
                            class: "w-full sm:w-80 p-3 border border-gray-300 rounded-lg dark:bg-gray-700 dark:border-gray-600 text-gray-700 dark:text-gray-300 focus:outline-none focus:ring-2 focus:ring-green-500 transition"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, searchQuery.value]
                          ])
                        ]),
                        createVNode("div", { class: "mb-4" }, [
                          withDirectives(createVNode("select", {
                            "onUpdate:modelValue": ($event) => selectedCategory.value = $event,
                            class: "w-full sm:w-40 p-2 border border-gray-300 rounded-lg dark:bg-gray-700 dark:border-gray-600 text-gray-700 dark:text-gray-300"
                          }, [
                            (openBlock(), createBlock(Fragment, null, renderList(categories, (category) => {
                              return createVNode("option", { key: category }, toDisplayString(category), 1);
                            }), 64))
                          ], 8, ["onUpdate:modelValue"]), [
                            [vModelSelect, selectedCategory.value]
                          ])
                        ]),
                        createVNode("div", { class: "grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 lg:gap-6" }, [
                          (openBlock(true), createBlock(Fragment, null, renderList(filteredProducts(), (product) => {
                            return openBlock(), createBlock("div", {
                              key: product.id,
                              class: "bg-white dark:bg-gray-800 shadow-md rounded-lg p-4 transition hover:shadow-lg"
                            }, [
                              createVNode("div", { class: "h-32 sm:h-40 bg-gray-200 dark:bg-gray-700 rounded-md mb-3 flex items-center justify-center overflow-hidden" }, [
                                createVNode("img", {
                                  src: product.image,
                                  alt: "Product Image",
                                  class: "object-cover h-full w-full"
                                }, null, 8, ["src"])
                              ]),
                              createVNode("h4", { class: "text-sm sm:text-lg font-semibold text-gray-700 dark:text-gray-300" }, toDisplayString(product.name), 1),
                              createVNode("p", { class: "text-xs text-gray-500 dark:text-gray-400" }, toDisplayString(product.category.name), 1),
                              createVNode("p", { class: "text-sm sm:text-md font-bold mt-2 text-gray-800 dark:text-gray-100" }, "₦" + toDisplayString(product.price), 1),
                              createVNode("button", {
                                onClick: ($event) => addToCart(product),
                                class: "mt-3 w-full py-2 bg-green-500 hover:bg-green-600 text-white font-semibold rounded-lg transition"
                              }, " Add to Cart ", 8, ["onClick"])
                            ]);
                          }), 128))
                        ])
                      ]),
                      createVNode("section", { class: "w-full lg:w-1/3 bg-white dark:bg-gray-800 rounded-lg shadow-lg p-4 lg:p-6" }, [
                        createVNode("h3", { class: "text-lg font-semibold text-gray-700 dark:text-gray-300" }, "Cart"),
                        createVNode("ul", { class: "mt-4 lg:mt-6 space-y-4" }, [
                          (openBlock(true), createBlock(Fragment, null, renderList(cartItems.value, (item) => {
                            return openBlock(), createBlock("li", {
                              key: item.id,
                              class: "flex justify-between items-center border-b border-gray-200 dark:border-gray-700 pb-2"
                            }, [
                              createVNode("div", null, [
                                createVNode("h4", { class: "text-sm font-semibold text-gray-700 dark:text-gray-300" }, toDisplayString(item.name), 1),
                                createVNode("div", { class: "flex items-center space-x-2 mt-1" }, [
                                  withDirectives(createVNode("input", {
                                    type: "number",
                                    "onUpdate:modelValue": ($event) => item.quantity = $event,
                                    onChange: ($event) => updateQuantity(item.id, item.quantity),
                                    class: "w-12 sm:w-16 p-1 border border-gray-300 rounded dark:bg-gray-700 dark:border-gray-600 text-center focus:outline-none",
                                    min: "1"
                                  }, null, 40, ["onUpdate:modelValue", "onChange"]), [
                                    [
                                      vModelText,
                                      item.quantity,
                                      void 0,
                                      { number: true }
                                    ]
                                  ]),
                                  createVNode("p", { class: "text-xs text-gray-500 dark:text-gray-400" }, "x ₦" + toDisplayString(item.price), 1)
                                ])
                              ]),
                              createVNode("div", { class: "flex items-center space-x-3" }, [
                                createVNode("p", { class: "font-semibold text-gray-800 dark:text-gray-100" }, "₦" + toDisplayString(item.price * item.quantity), 1),
                                createVNode("button", {
                                  onClick: ($event) => removeFromCart(item.id),
                                  class: "text-red-500 hover:text-red-600 text-sm font-bold"
                                }, "✕", 8, ["onClick"])
                              ])
                            ]);
                          }), 128))
                        ]),
                        createVNode("div", { class: "mt-6 lg:mt-8 pt-4 border-t border-gray-200 dark:border-gray-700 space-y-4" }, [
                          createVNode("div", { class: "flex justify-between text-md sm:text-lg font-semibold text-gray-700 dark:text-gray-300" }, [
                            createVNode("span", null, "Total:"),
                            createVNode("span", null, "₦" + toDisplayString(calculateTotal()), 1)
                          ]),
                          createVNode("button", {
                            onClick: checkout,
                            class: "w-full py-3 bg-green-600 hover:bg-green-700 text-white font-bold rounded-lg shadow-md transition"
                          }, "Checkout"),
                          createVNode("button", {
                            onClick: ($event) => cartItems.value = [],
                            class: "w-full py-3 bg-gray-300 hover:bg-gray-400 text-gray-700 font-bold rounded-lg shadow-md transition dark:bg-gray-600 dark:hover:bg-gray-500 dark:text-gray-200"
                          }, " Clear Cart ", 8, ["onClick"])
                        ])
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      if (showReceipt.value) {
        _push(`<div class="fixed inset-0 z-50 bg-black bg-opacity-50 flex justify-center items-center"><div class="bg-white dark:bg-gray-800 rounded-lg shadow-lg max-w-md w-full p-6"><h3 class="text-lg font-bold text-gray-800 dark:text-gray-200 mb-4">Receipt</h3><div class="space-y-2"><!--[-->`);
        ssrRenderList(receiptItems.value, (item) => {
          _push(`<div class="flex justify-between"><span class="text-sm font-semibold text-gray-700 dark:text-gray-300">${ssrInterpolate(item.name)}</span><span class="text-sm text-gray-500 dark:text-gray-400">x${ssrInterpolate(item.quantity)}</span><span class="text-sm text-gray-800 dark:text-gray-100">₦${ssrInterpolate(item.price * item.quantity)}</span></div>`);
        });
        _push(`<!--]--></div><div class="mt-4 border-t border-gray-300 dark:border-gray-700 pt-4"><div class="flex justify-between text-lg font-bold"><span>Total:</span><span>₦${ssrInterpolate(receiptTotal.value)}</span></div></div><div class="mt-6 flex justify-end space-x-3"><button class="px-4 py-2 bg-green-600 text-white font-bold rounded-lg hover:bg-green-700"> Print </button><button class="px-4 py-2 bg-gray-300 dark:bg-gray-600 text-gray-700 dark:text-gray-200 font-bold rounded-lg hover:bg-gray-400 dark:hover:bg-gray-500"> Close </button></div></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/POS/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
