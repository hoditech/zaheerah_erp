import { defineComponent, ref, onMounted, mergeProps, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual, ssrRenderList, ssrRenderAttr, ssrInterpolate, ssrRenderDynamicModel } from "vue/server-renderer";
import { a as fetchUsers } from "./payrollService-Dk0jLPaH.js";
import "axios";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "PayrollFormModal",
  __ssrInlineRender: true,
  emits: ["submit", "close"],
  setup(__props, { emit: __emit }) {
    const users = ref([]);
    const isLoading = ref(true);
    const isSubmitting = ref(false);
    const validationErrors = ref({});
    const defaultForm = {
      user_id: "",
      base_salary: 0,
      overtime_pay: 0,
      bonuses: 0,
      deductions: 0,
      tax: 0,
      commission: 0,
      payment_method: "Bank Transfer",
      payment_status: "Pending",
      payment_date: "",
      location: "",
      designation: "",
      working_days: 0,
      bank: "",
      account_number: "",
      transport: 0,
      house_rent: 0,
      medicals: 0,
      others: 0,
      income_tax: 0,
      cra: 0,
      pension: 0,
      nhf: 0,
      nhis: 0,
      salary_advance: 0
    };
    const form = ref({ ...defaultForm });
    const allowanceFields = [
      { key: "transport", label: "Transport", type: "number", required: true },
      { key: "house_rent", label: "House Rent", type: "number", required: true },
      { key: "medicals", label: "Medicals", type: "number", required: true },
      { key: "others", label: "Others", type: "number", required: true }
    ];
    const deductionFields = [
      { key: "income_tax", label: "Income Tax", type: "number", required: true },
      { key: "cra", label: "CRA", type: "number", required: true },
      { key: "pension", label: "Pension", type: "number", required: true },
      { key: "nhf", label: "NHF", type: "number", required: true },
      { key: "nhis", label: "NHIS", type: "number", required: true },
      { key: "salary_advance", label: "Salary Advance", type: "number", required: true }
    ];
    const paymentMethodOptions = [
      { label: "Bank Transfer", value: "bank_transfer" },
      { label: "Cash", value: "cash" },
      { label: "Mobile Money", value: "mobile_money" }
    ];
    const paymentStatusOptions = [
      { label: "Paid", value: "paid" },
      { label: "Pending", value: "pending" }
    ];
    const loadUsers = async () => {
      isLoading.value = true;
      try {
        users.value = await fetchUsers();
      } catch (error) {
        console.error("Failed to fetch users:", error);
      } finally {
        isLoading.value = false;
      }
    };
    onMounted(loadUsers);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center" }, _attrs))}><div class="bg-white dark:bg-gray-800 rounded-lg w-11/12 md:w-4/5 lg:w-3/4 xl:w-2/3 p-6 max-h-[90vh] overflow-y-auto"><h3 class="text-xl font-semibold mb-4 max-w-6xl">Add Payroll</h3><form><div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"><div class="md:col-span-2 lg:col-span-3"><label class="block text-sm font-medium text-gray-700">Employee</label><select required class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm"${ssrIncludeBooleanAttr(isLoading.value) ? " disabled" : ""}><option value="" disabled${ssrIncludeBooleanAttr(Array.isArray(form.value.user_id) ? ssrLooseContain(form.value.user_id, "") : ssrLooseEqual(form.value.user_id, "")) ? " selected" : ""}>Select an Employee</option>`);
      if (isLoading.value) {
        _push(`<option disabled>Loading employees...</option>`);
      } else {
        _push(`<!--[-->`);
        ssrRenderList(users.value, (user) => {
          _push(`<option${ssrRenderAttr("value", user.id)}>${ssrInterpolate(user.name)}</option>`);
        });
        _push(`<!--]-->`);
      }
      _push(`</select>`);
      if (validationErrors.value.user_id) {
        _push(`<span class="text-red-500 text-sm">${ssrInterpolate(validationErrors.value.user_id[0])}</span>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div><label class="block text-sm font-medium text-gray-700">Base Salary</label><input${ssrRenderAttr("value", form.value.base_salary)} type="number" required class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm"></div><div class="md:col-span-2 lg:col-span-3 bg-gray-50 p-4 rounded-lg"><h4 class="font-medium mb-2">Allowances</h4><div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"><!--[-->`);
      ssrRenderList(allowanceFields, (field) => {
        _push(`<div><label class="block text-sm font-medium text-gray-700">${ssrInterpolate(field.label)}</label><input${ssrRenderDynamicModel(field.type, form.value[field.key], null)}${ssrRenderAttr("type", field.type)}${ssrIncludeBooleanAttr(field.required) ? " required" : ""} class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm"></div>`);
      });
      _push(`<!--]--></div></div><div class="md:col-span-2 lg:col-span-3 bg-gray-50 p-4 rounded-lg"><h4 class="font-medium mb-2">Deductions</h4><div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"><!--[-->`);
      ssrRenderList(deductionFields, (field) => {
        _push(`<div><label class="block text-sm font-medium text-gray-700">${ssrInterpolate(field.label)}</label><input${ssrRenderDynamicModel(field.type, form.value[field.key], null)}${ssrRenderAttr("type", field.type)}${ssrIncludeBooleanAttr(field.required) ? " required" : ""} class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm"></div>`);
      });
      _push(`<!--]--></div></div><div class="md:col-span-2 lg:col-span-3 bg-gray-50 p-4 rounded-lg"><h4 class="font-medium mb-2">Payment Details</h4><div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"><div><label class="block text-sm font-medium text-gray-700">Payment Method</label><select required class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm"><!--[-->`);
      ssrRenderList(paymentMethodOptions, (option) => {
        _push(`<option${ssrRenderAttr("value", option.value)}>${ssrInterpolate(option.label)}</option>`);
      });
      _push(`<!--]--></select></div><div><label class="block text-sm font-medium text-gray-700">Payment Status</label><select required class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm"><!--[-->`);
      ssrRenderList(paymentStatusOptions, (option) => {
        _push(`<option${ssrRenderAttr("value", option.value)}>${ssrInterpolate(option.label)}</option>`);
      });
      _push(`<!--]--></select></div><div><label class="block text-sm font-medium text-gray-700">Payment Date</label><input${ssrRenderAttr("value", form.value.payment_date)} type="date" class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm"></div></div></div><div class="md:col-span-2 lg:col-span-3 bg-gray-50 p-4 rounded-lg"><h4 class="font-medium mb-2">Bank Information</h4><div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"><div><label class="block text-sm font-medium text-gray-700">Bank Name</label><input${ssrRenderAttr("value", form.value.bank)} type="text" required class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm"></div><div><label class="block text-sm font-medium text-gray-700">Account Number</label><input${ssrRenderAttr("value", form.value.account_number)} type="text" required class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm"></div></div></div></div><div class="flex space-x-4 mt-6"><button type="submit" class="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition duration-300"${ssrIncludeBooleanAttr(isLoading.value || isSubmitting.value) ? " disabled" : ""}>${ssrInterpolate(isSubmitting.value ? "Submitting..." : "Submit")}</button><button type="button" class="px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition duration-300"${ssrIncludeBooleanAttr(isSubmitting.value) ? " disabled" : ""}> Cancel </button></div></form></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/finance/Components/PayrollFormModal.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
