import { defineComponent, mergeProps, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderClass, ssrInterpolate } from "vue/server-renderer";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "SummaryCard",
  __ssrInlineRender: true,
  props: {
    title: String,
    value: String,
    color: {
      type: String,
      default: "text-gray-900"
      // default color
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "bg-white dark:bg-gray-800 shadow-lg rounded-lg p-6" }, _attrs))}><h4 class="${ssrRenderClass(["text-lg", "font-semibold", "text-gray-700", "dark:text-gray-200"])}">${ssrInterpolate(__props.title)}</h4><p class="${ssrRenderClass(["text-2xl", "font-bold", "dark:text-gray-100", __props.color])}">${ssrInterpolate(__props.value)}</p></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/finance/Components/SummaryCard.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
