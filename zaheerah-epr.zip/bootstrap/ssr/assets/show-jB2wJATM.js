import { defineComponent, ref, unref, withCtx, createVNode, openBlock, createBlock, createCommentVNode, useSSRContext } from "vue";
import { ssrRenderComponent } from "vue/server-renderer";
import { A as AuthenticatedLayout } from "./AuthenticatedLayout-BMQt65oV.js";
import { Head } from "@inertiajs/vue3";
import _sfc_main$1 from "./Sidebar-CvZzd3ZJ.js";
import _sfc_main$2 from "./Dashboard-DxnhuVjP.js";
import _sfc_main$3 from "./Payroll-DviNxt_8.js";
import _sfc_main$4 from "./Reports-DdHNJCZc.js";
import "laravel-permission-to-vuejs";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
import "./SummaryCard-Be4td-xb.js";
import "./PayrollFormModal-sBt8t_pU.js";
import "axios";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "show",
  __ssrInlineRender: true,
  props: {
    totalRevenue: {},
    totalCost: {},
    totalPayrollExpense: {},
    totalProfit: {},
    totalStock: {},
    categories: {},
    payrolls: {}
  },
  setup(__props) {
    const activeTab = ref("Dashboard");
    const tabs = ["Dashboard", "Payroll", "Reports"];
    const switchTab = (tab) => {
      activeTab.value = tab;
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Financial Management" }, null, _parent));
      _push(ssrRenderComponent(AuthenticatedLayout, null, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<h2 class="text-3xl font-bold text-gray-900 dark:text-gray-100"${_scopeId}>Financial Management</h2>`);
          } else {
            return [
              createVNode("h2", { class: "text-3xl font-bold text-gray-900 dark:text-gray-100" }, "Financial Management")
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="flex min-h-screen bg-gray-100 dark:bg-gray-900"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$1, {
              activeTab: activeTab.value,
              tabs,
              onSwitchTab: switchTab
            }, null, _parent2, _scopeId));
            _push2(`<main class="flex-1 p-6"${_scopeId}>`);
            if (activeTab.value === "Dashboard") {
              _push2(ssrRenderComponent(_sfc_main$2, {
                totalRevenue: _ctx.totalRevenue,
                totalCost: _ctx.totalCost,
                totalProfit: _ctx.totalProfit,
                categories: _ctx.categories
              }, null, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            if (activeTab.value === "Payroll") {
              _push2(ssrRenderComponent(_sfc_main$3, { payrolls: _ctx.payrolls }, null, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            if (activeTab.value === "Reports") {
              _push2(ssrRenderComponent(_sfc_main$4, { categories: _ctx.categories }, null, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            _push2(`</main></div>`);
          } else {
            return [
              createVNode("div", { class: "flex min-h-screen bg-gray-100 dark:bg-gray-900" }, [
                createVNode(_sfc_main$1, {
                  activeTab: activeTab.value,
                  tabs,
                  onSwitchTab: switchTab
                }, null, 8, ["activeTab"]),
                createVNode("main", { class: "flex-1 p-6" }, [
                  activeTab.value === "Dashboard" ? (openBlock(), createBlock(_sfc_main$2, {
                    key: 0,
                    totalRevenue: _ctx.totalRevenue,
                    totalCost: _ctx.totalCost,
                    totalProfit: _ctx.totalProfit,
                    categories: _ctx.categories
                  }, null, 8, ["totalRevenue", "totalCost", "totalProfit", "categories"])) : createCommentVNode("", true),
                  activeTab.value === "Payroll" ? (openBlock(), createBlock(_sfc_main$3, {
                    key: 1,
                    payrolls: _ctx.payrolls
                  }, null, 8, ["payrolls"])) : createCommentVNode("", true),
                  activeTab.value === "Reports" ? (openBlock(), createBlock(_sfc_main$4, {
                    key: 2,
                    categories: _ctx.categories
                  }, null, 8, ["categories"])) : createCommentVNode("", true)
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/finance/show.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
