import { defineComponent, mergeProps, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderList, ssrRenderClass, ssrInterpolate } from "vue/server-renderer";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Sidebar",
  __ssrInlineRender: true,
  props: {
    activeTab: String,
    tabs: Array
  },
  emits: ["switch-tab"],
  setup(__props, { emit: __emit }) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<aside${ssrRenderAttrs(mergeProps({ class: "w-64 bg-white dark:bg-gray-800 border-r border-gray-300 dark:border-gray-700 p-4" }, _attrs))}><nav><ul class="space-y-3"><!--[-->`);
      ssrRenderList(__props.tabs, (tab) => {
        _push(`<li><a href="#" class="${ssrRenderClass([{ "bg-green-500 text-white": __props.activeTab === tab }, "block p-3 rounded-lg hover:bg-green-500 hover:text-white transition"])}">${ssrInterpolate(tab)}</a></li>`);
      });
      _push(`<!--]--></ul></nav></aside>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/finance/Components/Sidebar.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
