import { defineComponent, ref, onMounted, onUnmounted, mergeProps, unref, withCtx, createVNode, openBlock, createBlock, createCommentVNode, toDisplayString, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderClass, ssrRenderComponent, ssrRenderSlot, ssrInterpolate } from "vue/server-renderer";
import { Link } from "@inertiajs/vue3";
import { is } from "laravel-permission-to-vuejs";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-1tPrXgE0.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "AuthenticatedLayout",
  __ssrInlineRender: true,
  setup(__props) {
    ref(false);
    const sidebarOpen = ref(true);
    const isMobile = ref(window.innerWidth < 768);
    const updateIsMobile = () => {
      isMobile.value = window.innerWidth < 768;
    };
    onMounted(() => {
      window.addEventListener("resize", updateIsMobile);
    });
    onUnmounted(() => {
      window.removeEventListener("resize", updateIsMobile);
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex h-screen bg-gray-100 dark:bg-gray-900 text-gray-800 dark:text-gray-200 relative" }, _attrs))} data-v-38a1f573><aside class="${ssrRenderClass({
        "fixed inset-0 z-30 w-64": sidebarOpen.value && isMobile.value,
        "hidden md:flex": !sidebarOpen.value && isMobile.value,
        "w-44": sidebarOpen.value && !isMobile.value,
        "w-20": !sidebarOpen.value && !isMobile.value,
        "flex flex-col h-full bg-white shadow-lg dark:bg-gray-800 transition-all duration-200 md:relative": true
      })}" data-v-38a1f573><div class="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700" data-v-38a1f573>`);
      if (sidebarOpen.value || isMobile.value) {
        _push(`<h2 class="text-lg font-bold text-green-700 dark:text-gray-300" data-v-38a1f573><img src="/images/logo2.png" alt="Description" class="inline-block w-18 h-10" data-v-38a1f573></h2>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<button class="p-2" data-v-38a1f573>`);
      if (isMobile.value) {
        _push(`<span data-v-38a1f573>X</span>`);
      } else if (sidebarOpen.value) {
        _push(`<span data-v-38a1f573>➖</span>`);
      } else {
        _push(`<span data-v-38a1f573>➕</span>`);
      }
      _push(`</button></div><nav class="flex-grow" data-v-38a1f573><ul data-v-38a1f573><li class="${ssrRenderClass({
        "p-4 hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center": true,
        "justify-center": !sidebarOpen.value,
        "space-x-2": sidebarOpen.value,
        "active-link": _ctx.route().current("dashboard")
      })}" data-v-38a1f573>`);
      _push(ssrRenderComponent(unref(Link), {
        href: _ctx.route("dashboard"),
        class: {
          "flex items-center w-full": true,
          "justify-center": !sidebarOpen.value,
          "space-x-2": sidebarOpen.value
        }
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<span data-v-38a1f573${_scopeId}>🏠</span>`);
            if (sidebarOpen.value || isMobile.value) {
              _push2(`<span data-v-38a1f573${_scopeId}>Home</span>`);
            } else {
              _push2(`<!---->`);
            }
          } else {
            return [
              createVNode("span", null, "🏠"),
              sidebarOpen.value || isMobile.value ? (openBlock(), createBlock("span", { key: 0 }, "Home")) : createCommentVNode("", true)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li>`);
      if (unref(is)("Manager | Employee | Super Admin")) {
        _push(`<li class="${ssrRenderClass({
          "p-4 hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center": true,
          "justify-center": !sidebarOpen.value,
          "space-x-2": sidebarOpen.value,
          "active-link": _ctx.route().current("pos")
        })}" data-v-38a1f573>`);
        _push(ssrRenderComponent(unref(Link), {
          href: _ctx.route("pos"),
          class: {
            "flex items-center w-full": true,
            "justify-center": !sidebarOpen.value,
            "space-x-2": sidebarOpen.value
          }
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<span data-v-38a1f573${_scopeId}>💳</span>`);
              if (sidebarOpen.value || isMobile.value) {
                _push2(`<span data-v-38a1f573${_scopeId}>POS</span>`);
              } else {
                _push2(`<!---->`);
              }
            } else {
              return [
                createVNode("span", null, "💳"),
                sidebarOpen.value || isMobile.value ? (openBlock(), createBlock("span", { key: 0 }, "POS")) : createCommentVNode("", true)
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</li>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(is)("HR | Super Admin | Admin")) {
        _push(`<li class="${ssrRenderClass({
          "p-4 hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center": true,
          "justify-center": !sidebarOpen.value,
          "space-x-2": sidebarOpen.value,
          "active-link": _ctx.route().current("employees.index")
        })}" data-v-38a1f573>`);
        _push(ssrRenderComponent(unref(Link), {
          href: _ctx.route("employees.index"),
          class: "flex items-center space-x-2"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<span data-v-38a1f573${_scopeId}>👨‍💼</span>`);
              if (sidebarOpen.value || isMobile.value) {
                _push2(`<span data-v-38a1f573${_scopeId}>HR</span>`);
              } else {
                _push2(`<!---->`);
              }
            } else {
              return [
                createVNode("span", null, "👨‍💼"),
                sidebarOpen.value || isMobile.value ? (openBlock(), createBlock("span", { key: 0 }, "HR")) : createCommentVNode("", true)
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</li>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(is)("Manager  | Super Admin|Admin")) {
        _push(`<li class="${ssrRenderClass({
          "p-4 hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center": true,
          "justify-center": !sidebarOpen.value,
          "space-x-2": sidebarOpen.value,
          "active-link": _ctx.route().current("products")
        })}" data-v-38a1f573>`);
        _push(ssrRenderComponent(unref(Link), {
          href: _ctx.route("products"),
          class: "flex items-center space-x-2"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<span data-v-38a1f573${_scopeId}>📦</span>`);
              if (sidebarOpen.value || isMobile.value) {
                _push2(`<span data-v-38a1f573${_scopeId}>Inventory</span>`);
              } else {
                _push2(`<!---->`);
              }
            } else {
              return [
                createVNode("span", null, "📦"),
                sidebarOpen.value || isMobile.value ? (openBlock(), createBlock("span", { key: 0 }, "Inventory")) : createCommentVNode("", true)
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</li>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(is)("Manager  | Super Admin|Admin")) {
        _push(`<li class="${ssrRenderClass({
          "p-4 hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center": true,
          "justify-center": !sidebarOpen.value,
          "space-x-2": sidebarOpen.value,
          "active-link": _ctx.route().current("productions.index")
        })}" data-v-38a1f573>`);
        _push(ssrRenderComponent(unref(Link), {
          href: _ctx.route("productions.index"),
          class: "flex items-center space-x-2"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<span data-v-38a1f573${_scopeId}>🏭</span>`);
              if (sidebarOpen.value || isMobile.value) {
                _push2(`<span data-v-38a1f573${_scopeId}>Production</span>`);
              } else {
                _push2(`<!---->`);
              }
            } else {
              return [
                createVNode("span", null, "🏭"),
                sidebarOpen.value || isMobile.value ? (openBlock(), createBlock("span", { key: 0 }, "Production")) : createCommentVNode("", true)
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</li>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(is)("Technical Manager | Super Admin|Admin")) {
        _push(`<li class="${ssrRenderClass({
          "p-4 hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center": true,
          "justify-center": !sidebarOpen.value,
          "space-x-2": sidebarOpen.value,
          "active-link": _ctx.route().current("suppliers.index")
        })}" data-v-38a1f573>`);
        _push(ssrRenderComponent(unref(Link), {
          href: _ctx.route("suppliers.index"),
          class: "flex items-center space-x-2"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<span data-v-38a1f573${_scopeId}>🚚</span>`);
              if (sidebarOpen.value || isMobile.value) {
                _push2(`<span data-v-38a1f573${_scopeId}>Suppliers</span>`);
              } else {
                _push2(`<!---->`);
              }
            } else {
              return [
                createVNode("span", null, "🚚"),
                sidebarOpen.value || isMobile.value ? (openBlock(), createBlock("span", { key: 0 }, "Suppliers")) : createCommentVNode("", true)
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</li>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(is)("Manager | Super Admin|Admin")) {
        _push(`<li class="${ssrRenderClass({
          "p-4 hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center": true,
          "justify-center": !sidebarOpen.value,
          "space-x-2": sidebarOpen.value,
          "active-link": _ctx.route().current("purchase-orders.index")
        })}" data-v-38a1f573>`);
        _push(ssrRenderComponent(unref(Link), {
          href: _ctx.route("purchase-orders.index"),
          class: "flex items-center space-x-2"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<span data-v-38a1f573${_scopeId}> 🛒</span>`);
              if (sidebarOpen.value || isMobile.value) {
                _push2(`<span data-v-38a1f573${_scopeId}>Purchase Order</span>`);
              } else {
                _push2(`<!---->`);
              }
            } else {
              return [
                createVNode("span", null, " 🛒"),
                sidebarOpen.value || isMobile.value ? (openBlock(), createBlock("span", { key: 0 }, "Purchase Order")) : createCommentVNode("", true)
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</li>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(is)("Super Admin| Admin")) {
        _push(`<li class="${ssrRenderClass({
          "p-4 hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center": true,
          "justify-center": !sidebarOpen.value,
          "space-x-2": sidebarOpen.value,
          "active-link": _ctx.route().current("finance.index")
        })}" data-v-38a1f573>`);
        _push(ssrRenderComponent(unref(Link), {
          href: _ctx.route("finance.index"),
          class: "flex items-center space-x-2"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<span data-v-38a1f573${_scopeId}> 🏦</span>`);
              if (sidebarOpen.value || isMobile.value) {
                _push2(`<span data-v-38a1f573${_scopeId}>Finance</span>`);
              } else {
                _push2(`<!---->`);
              }
            } else {
              return [
                createVNode("span", null, " 🏦"),
                sidebarOpen.value || isMobile.value ? (openBlock(), createBlock("span", { key: 0 }, "Finance")) : createCommentVNode("", true)
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</li>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</ul></nav><div class="p-4 border-t border-gray-200 dark:border-gray-700" data-v-38a1f573>`);
      _push(ssrRenderComponent(unref(Link), {
        href: _ctx.route("logout"),
        method: "post",
        as: "button",
        class: "w-full py-2 text-sm font-semibold text-gray-600 bg-gray-100 dark:bg-gray-700 dark:text-gray-300 rounded-lg flex items-center justify-center"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<span data-v-38a1f573${_scopeId}>🔓</span>`);
            if (sidebarOpen.value || isMobile.value) {
              _push2(`<span data-v-38a1f573${_scopeId}>Log Out</span>`);
            } else {
              _push2(`<!---->`);
            }
          } else {
            return [
              createVNode("span", null, "🔓"),
              sidebarOpen.value || isMobile.value ? (openBlock(), createBlock("span", { key: 0 }, "Log Out")) : createCommentVNode("", true)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></aside>`);
      if (sidebarOpen.value && isMobile.value) {
        _push(`<div class="fixed inset-0 bg-black opacity-50 z-20" data-v-38a1f573></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="flex-1 flex flex-col" data-v-38a1f573>`);
      if (_ctx.$slots.header) {
        _push(`<header class="flex items-center justify-between px-4 py-4 md:px-6 bg-white shadow-md dark:bg-gray-800" data-v-38a1f573><button class="p-2 md:hidden" data-v-38a1f573><span data-v-38a1f573>≡</span></button><h1 class="text-xl md:text-2xl font-semibold leading-tight" data-v-38a1f573>`);
        ssrRenderSlot(_ctx.$slots, "header", {}, null, _push, _parent);
        _push(`</h1><div class="flex items-center space-x-4" data-v-38a1f573>`);
        _push(ssrRenderComponent(unref(Link), {
          href: _ctx.route("profile.edit"),
          class: "flex items-center p-2 bg-gray-100 dark:bg-gray-700 rounded-full hover:bg-gray-200"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<img src="/images/avata.png" class="w-8 h-8 rounded-full" alt="User Profile" data-v-38a1f573${_scopeId}><span class="ml-2 text-gray-800 dark:text-gray-200 font-semibold text-sm md:text-base" data-v-38a1f573${_scopeId}>${ssrInterpolate(_ctx.$page.props.auth.user.name)}</span>`);
            } else {
              return [
                createVNode("img", {
                  src: "/images/avata.png",
                  class: "w-8 h-8 rounded-full",
                  alt: "User Profile"
                }),
                createVNode("span", { class: "ml-2 text-gray-800 dark:text-gray-200 font-semibold text-sm md:text-base" }, toDisplayString(_ctx.$page.props.auth.user.name), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div></header>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<main class="flex-1 overflow-y-auto p-4 md:p-6 bg-gray-100 dark:bg-gray-900" data-v-38a1f573><div class="p-4 md:p-2 g-white dark:bg-gray-800 rounded-lg" data-v-38a1f573>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div></main></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Layouts/AuthenticatedLayout.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const AuthenticatedLayout = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-38a1f573"]]);
export {
  AuthenticatedLayout as A
};
