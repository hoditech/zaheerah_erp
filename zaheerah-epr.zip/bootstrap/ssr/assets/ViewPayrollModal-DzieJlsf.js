import { defineComponent, mergeProps, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrInterpolate, ssrRenderClass } from "vue/server-renderer";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "ViewPayrollModal",
  __ssrInlineRender: true,
  props: {
    payroll: {}
  },
  emits: ["close"],
  setup(__props, { emit: __emit }) {
    const formatNumber = (num) => (num == null ? void 0 : num.toLocaleString()) || "0";
    const formatDate = (dateString) => new Date(dateString).toLocaleDateString();
    const statusClasses = (status) => ({
      "text-green-500": status === "paid",
      "text-yellow-500": status === "pending",
      "text-red-500": status === "failed"
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4" }, _attrs))}><div class="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl p-6 w-full max-w-4xl h-[80vh] overflow-y-auto"><div class="mt-6 flex justify-end"><button class="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition">Close</button></div><h2 class="text-2xl font-semibold mb-4 text-gray-900 dark:text-gray-100">Payroll Details</h2><div class="grid grid-cols-2 gap-6"><div class="border-b pb-4"><h3 class="text-lg font-medium mb-2 text-gray-800 dark:text-gray-200">Employee Information</h3><div class="grid grid-cols-2 gap-4 text-gray-700 dark:text-gray-300"><div><strong>ID:</strong> ${ssrInterpolate(_ctx.payroll.user.employee_id)}</div><div><strong>Name:</strong> ${ssrInterpolate(_ctx.payroll.user.name)}</div><div><strong>Location:</strong> ${ssrInterpolate(_ctx.payroll.location)}</div><div><strong>Designation:</strong> ${ssrInterpolate(_ctx.payroll.designation)}</div><div><strong>Working Days:</strong> ${ssrInterpolate(_ctx.payroll.working_days)}</div></div></div><div class="border-b pb-4"><h3 class="text-lg font-medium mb-2 text-gray-800 dark:text-gray-200">Salary Information</h3><div class="grid grid-cols-2 gap-4 text-gray-700 dark:text-gray-300"><div><strong>Base Salary:</strong> ₦${ssrInterpolate(formatNumber(_ctx.payroll.base_salary))}</div><div><strong>Gross Salary:</strong> ₦${ssrInterpolate(formatNumber(_ctx.payroll.gross_salary))}</div><div><strong>Net Salary:</strong> ₦${ssrInterpolate(formatNumber(_ctx.payroll.net_salary))}</div><div><strong>Total Deduction:</strong> ₦${ssrInterpolate(formatNumber(_ctx.payroll.total_deduction))}</div></div></div><div class="border-b pb-4"><h3 class="text-lg font-medium mb-2 text-gray-800 dark:text-gray-200">Payment Details</h3><div class="grid grid-cols-2 gap-4 text-gray-700 dark:text-gray-300"><div><strong>Method:</strong> ${ssrInterpolate(_ctx.payroll.payment_method.replace("_", " "))}</div><div><strong>Date:</strong> ${ssrInterpolate(formatDate(_ctx.payroll.payment_date))}</div><div><strong>Status:</strong> <span class="${ssrRenderClass(statusClasses(_ctx.payroll.payment_status))}">${ssrInterpolate(_ctx.payroll.payment_status)}</span></div></div></div><div class="grid grid-cols-2 gap-6"><div><h3 class="text-lg font-medium mb-2 text-gray-800 dark:text-gray-200">Earnings</h3><div class="text-gray-700 dark:text-gray-300"><strong>Overtime Pay:</strong> ₦${ssrInterpolate(formatNumber(_ctx.payroll.overtime_pay))}</div><div><strong>Bonuses:</strong> ₦${ssrInterpolate(formatNumber(_ctx.payroll.bonuses))}</div><div><strong>Commission:</strong> ₦${ssrInterpolate(formatNumber(_ctx.payroll.commission))}</div><div><strong>Allowances:</strong></div><ul class="ml-4 list-disc text-gray-700 dark:text-gray-300"><li>Transport: ₦${ssrInterpolate(formatNumber(_ctx.payroll.transport))}</li><li>House Rent: ₦${ssrInterpolate(formatNumber(_ctx.payroll.house_rent))}</li><li>Medical: ₦${ssrInterpolate(formatNumber(_ctx.payroll.medicals))}</li><li>Others: ₦${ssrInterpolate(formatNumber(_ctx.payroll.others))}</li></ul></div><div><h3 class="text-lg font-medium mb-2 text-gray-800 dark:text-gray-200">Deductions</h3><div class="text-gray-700 dark:text-gray-300"><strong>Tax:</strong> ₦${ssrInterpolate(formatNumber(_ctx.payroll.tax))}</div><div><strong>Income Tax:</strong> ₦${ssrInterpolate(formatNumber(_ctx.payroll.income_tax))}</div><div><strong>CRA:</strong> ₦${ssrInterpolate(formatNumber(_ctx.payroll.cra))}</div><div><strong>Pension:</strong> ₦${ssrInterpolate(formatNumber(_ctx.payroll.pension))}</div><div><strong>NHF:</strong> ₦${ssrInterpolate(formatNumber(_ctx.payroll.nhf))}</div><div><strong>NHIS:</strong> ₦${ssrInterpolate(formatNumber(_ctx.payroll.nhis))}</div><div><strong>Salary Advance:</strong> ₦${ssrInterpolate(formatNumber(_ctx.payroll.salary_advance))}</div></div></div><div><h3 class="text-lg font-medium mb-2 text-gray-800 dark:text-gray-200">Bank Details</h3><div class="grid grid-cols-2 gap-4 text-gray-700 dark:text-gray-300"><div><strong>Bank:</strong> ${ssrInterpolate(_ctx.payroll.bank)}</div><div><strong>Account Number:</strong> ${ssrInterpolate(_ctx.payroll.account_number)}</div></div></div></div></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/finance/Components/ViewPayrollModal.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
