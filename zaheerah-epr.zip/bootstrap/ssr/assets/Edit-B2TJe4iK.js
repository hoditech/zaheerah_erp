import { defineComponent, unref, withCtx, createVNode, createTextVNode, withModifiers, withDirectives, openBlock, createBlock, Fragment, renderList, toDisplayString, vModelSelect, useSSRContext } from "vue";
import { ssrRenderComponent, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual, ssrRenderList, ssrRenderAttr, ssrInterpolate } from "vue/server-renderer";
import { useForm, Head } from "@inertiajs/vue3";
import { A as AuthenticatedLayout } from "./AuthenticatedLayout-GMSouBjC.js";
import { _ as _sfc_main$1, a as _sfc_main$2, b as _sfc_main$3 } from "./TextInput-Co45MSy8.js";
import { P as PrimaryButton } from "./PrimaryButton-CDoi0rzE.js";
import "laravel-permission-to-vuejs";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Edit",
  __ssrInlineRender: true,
  props: {
    product: {
      type: Object,
      required: true
    },
    categories: {
      type: Array,
      required: true
    },
    suppliers: {
      type: Array,
      required: true
    }
  },
  setup(__props) {
    const props = __props;
    console.log([props.suppliers, props.product]);
    const form = useForm({
      name: props.product.name,
      price: props.product.price,
      stock: props.product.stock,
      weight: props.product.weight,
      weight_per_unit: props.product.weight_per_unit,
      total_cost: props.product.total_cost,
      stock_receive: props.product.stock_receive,
      stock_release: props.product.stock_release,
      remaining_units: props.product.remaining_units,
      supplier_id: props.product.supplier_id,
      exp_date: props.product.exp_date,
      batch_number: props.product.batch_number,
      storage_location: props.product.storage_location,
      category_id: props.product.category_id
    });
    const submit = () => {
      form.put(route("products.update", props.product.id), {
        onSuccess: () => {
          form.reset();
        },
        onError: (errors) => {
          console.log(errors);
        }
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Edit Product" }, null, _parent));
      _push(ssrRenderComponent(AuthenticatedLayout, null, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<h2 class="text-xl font-semibold leading-tight text-gray-800 dark:text-gray-200"${_scopeId}> Add Poduct </h2>`);
          } else {
            return [
              createVNode("h2", { class: "text-xl font-semibold leading-tight text-gray-800 dark:text-gray-200" }, " Add Poduct ")
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="py-12"${_scopeId}><div class="mx-auto max-w-7xl space-y-6 sm:px-6 lg:px-8"${_scopeId}><div class="bg-white p-4 shadow sm:rounded-lg sm:p-8 dark:bg-gray-800"${_scopeId}><form class="space-y-6"${_scopeId}><div class="grid grid-cols-1 md:grid-cols-2 gap-4"${_scopeId}><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$1, {
              for: "name",
              value: "Product Name"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$2, {
              id: "name",
              type: "text",
              class: "mt-1 block w-full",
              modelValue: unref(form).name,
              "onUpdate:modelValue": ($event) => unref(form).name = $event,
              required: "",
              autofocus: ""
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              class: "mt-2",
              message: unref(form).errors.name
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$1, {
              for: "price",
              value: "Price"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$2, {
              id: "price",
              type: "number",
              step: "0.01",
              class: "mt-1 block w-full",
              modelValue: unref(form).price,
              "onUpdate:modelValue": ($event) => unref(form).price = $event,
              modelModifiers: { number: true },
              required: ""
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              class: "mt-2",
              message: unref(form).errors.price
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$1, {
              for: "stock",
              value: "Stock"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$2, {
              id: "stock",
              type: "number",
              class: "mt-1 block w-full",
              modelValue: unref(form).stock,
              "onUpdate:modelValue": ($event) => unref(form).stock = $event,
              required: ""
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              class: "mt-2",
              message: unref(form).errors.stock
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$1, {
              for: "category",
              value: "Category"
            }, null, _parent2, _scopeId));
            _push2(`<select id="category" class="mt-1 block w-full rounded-md shadow-sm border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50" required${_scopeId}><option value="" disabled${ssrIncludeBooleanAttr(Array.isArray(unref(form).category_id) ? ssrLooseContain(unref(form).category_id, "") : ssrLooseEqual(unref(form).category_id, "")) ? " selected" : ""}${_scopeId}>Select a category</option><!--[-->`);
            ssrRenderList(__props.categories, (category) => {
              _push2(`<option${ssrRenderAttr("value", category.id)}${_scopeId}>${ssrInterpolate(category.name)}</option>`);
            });
            _push2(`<!--]--></select>`);
            _push2(ssrRenderComponent(_sfc_main$3, {
              class: "mt-2",
              message: unref(form).errors.category_id
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$1, {
              for: "weight",
              value: "Weight"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$2, {
              id: "weight",
              type: "number",
              step: "0.01",
              class: "mt-1 block w-full",
              modelValue: unref(form).weight,
              "onUpdate:modelValue": ($event) => unref(form).weight = $event
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              class: "mt-2",
              message: unref(form).errors.weight
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$1, {
              for: "weight_per_unit",
              value: "Weight per unit"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$2, {
              id: "weight_per_unit",
              type: "number",
              step: "0.01",
              class: "mt-1 block w-full",
              modelValue: unref(form).weight_per_unit,
              "onUpdate:modelValue": ($event) => unref(form).weight_per_unit = $event
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              class: "mt-2",
              message: unref(form).errors.weight_per_unit
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$1, {
              for: "total_cost",
              value: "Total Cost"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$2, {
              id: "total_cost",
              type: "number",
              step: "0.01",
              class: "mt-1 block w-full",
              modelValue: unref(form).total_cost,
              "onUpdate:modelValue": ($event) => unref(form).total_cost = $event
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              class: "mt-2",
              message: unref(form).errors.total_cost
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$1, {
              for: "stock_receive",
              value: "Stock Receive"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$2, {
              id: "stock_receive",
              type: "number",
              class: "mt-1 block w-full",
              modelValue: unref(form).stock_receive,
              "onUpdate:modelValue": ($event) => unref(form).stock_receive = $event,
              modelModifiers: { number: true }
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              class: "mt-2",
              message: unref(form).errors.stock_receive
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$1, {
              for: "stock_release",
              value: "Stock Release"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$2, {
              id: "stock_release",
              type: "number",
              class: "mt-1 block w-full",
              modelValue: unref(form).stock_release,
              "onUpdate:modelValue": ($event) => unref(form).stock_release = $event
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              class: "mt-2",
              message: unref(form).errors.stock_release
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$1, {
              for: "remaining_units",
              value: "Remaining units"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$2, {
              id: "remaining_units",
              type: "number",
              class: "mt-1 block w-full",
              modelValue: unref(form).remaining_units,
              "onUpdate:modelValue": ($event) => unref(form).remaining_units = $event,
              modelModifiers: { number: true }
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              class: "mt-2",
              message: unref(form).errors.remaining_units
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$1, {
              for: "exp_date",
              value: "Expiration Date"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$2, {
              id: "exp_date",
              type: "date",
              class: "mt-1 block w-full",
              modelValue: unref(form).exp_date,
              "onUpdate:modelValue": ($event) => unref(form).exp_date = $event
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              class: "mt-2",
              message: unref(form).errors.exp_date
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$1, {
              for: "batch_number",
              value: "Batch Number"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$2, {
              id: "batch_number",
              type: "text",
              class: "mt-1 block w-full",
              modelValue: unref(form).batch_number,
              "onUpdate:modelValue": ($event) => unref(form).batch_number = $event
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              class: "mt-2",
              message: unref(form).errors.batch_number
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$1, {
              for: "supplier",
              value: "Supplier"
            }, null, _parent2, _scopeId));
            _push2(`<select id="supplier" class="mt-1 block w-full rounded-md shadow-sm border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"${_scopeId}><option value="" disabled${ssrIncludeBooleanAttr(Array.isArray(unref(form).supplier_id) ? ssrLooseContain(unref(form).supplier_id, "") : ssrLooseEqual(unref(form).supplier_id, "")) ? " selected" : ""}${_scopeId}>Select a Supplier</option><!--[-->`);
            ssrRenderList(__props.suppliers, (supplier) => {
              _push2(`<option${ssrRenderAttr("value", supplier.id)}${_scopeId}>${ssrInterpolate(supplier.name)}</option>`);
            });
            _push2(`<!--]--></select>`);
            _push2(ssrRenderComponent(_sfc_main$3, {
              class: "mt-2",
              message: unref(form).errors.category_id
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$1, {
              for: "storage_location",
              value: "Storage Location"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$2, {
              id: "storage_location",
              type: "text",
              class: "mt-1 block w-full",
              modelValue: unref(form).storage_location,
              "onUpdate:modelValue": ($event) => unref(form).storage_location = $event
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              class: "mt-2",
              message: unref(form).errors.storage_location
            }, null, _parent2, _scopeId));
            _push2(`</div></div><div class="flex items-center gap-4"${_scopeId}>`);
            _push2(ssrRenderComponent(PrimaryButton, {
              disabled: unref(form).processing
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`Update`);
                } else {
                  return [
                    createTextVNode("Update")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></form></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "py-12" }, [
                createVNode("div", { class: "mx-auto max-w-7xl space-y-6 sm:px-6 lg:px-8" }, [
                  createVNode("div", { class: "bg-white p-4 shadow sm:rounded-lg sm:p-8 dark:bg-gray-800" }, [
                    createVNode("form", {
                      onSubmit: withModifiers(submit, ["prevent"]),
                      class: "space-y-6"
                    }, [
                      createVNode("div", { class: "grid grid-cols-1 md:grid-cols-2 gap-4" }, [
                        createVNode("div", null, [
                          createVNode(_sfc_main$1, {
                            for: "name",
                            value: "Product Name"
                          }),
                          createVNode(_sfc_main$2, {
                            id: "name",
                            type: "text",
                            class: "mt-1 block w-full",
                            modelValue: unref(form).name,
                            "onUpdate:modelValue": ($event) => unref(form).name = $event,
                            required: "",
                            autofocus: ""
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$3, {
                            class: "mt-2",
                            message: unref(form).errors.name
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$1, {
                            for: "price",
                            value: "Price"
                          }),
                          createVNode(_sfc_main$2, {
                            id: "price",
                            type: "number",
                            step: "0.01",
                            class: "mt-1 block w-full",
                            modelValue: unref(form).price,
                            "onUpdate:modelValue": ($event) => unref(form).price = $event,
                            modelModifiers: { number: true },
                            required: ""
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$3, {
                            class: "mt-2",
                            message: unref(form).errors.price
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$1, {
                            for: "stock",
                            value: "Stock"
                          }),
                          createVNode(_sfc_main$2, {
                            id: "stock",
                            type: "number",
                            class: "mt-1 block w-full",
                            modelValue: unref(form).stock,
                            "onUpdate:modelValue": ($event) => unref(form).stock = $event,
                            required: ""
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$3, {
                            class: "mt-2",
                            message: unref(form).errors.stock
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$1, {
                            for: "category",
                            value: "Category"
                          }),
                          withDirectives(createVNode("select", {
                            id: "category",
                            "onUpdate:modelValue": ($event) => unref(form).category_id = $event,
                            class: "mt-1 block w-full rounded-md shadow-sm border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50",
                            required: ""
                          }, [
                            createVNode("option", {
                              value: "",
                              disabled: ""
                            }, "Select a category"),
                            (openBlock(true), createBlock(Fragment, null, renderList(__props.categories, (category) => {
                              return openBlock(), createBlock("option", {
                                key: category.id,
                                value: category.id
                              }, toDisplayString(category.name), 9, ["value"]);
                            }), 128))
                          ], 8, ["onUpdate:modelValue"]), [
                            [vModelSelect, unref(form).category_id]
                          ]),
                          createVNode(_sfc_main$3, {
                            class: "mt-2",
                            message: unref(form).errors.category_id
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$1, {
                            for: "weight",
                            value: "Weight"
                          }),
                          createVNode(_sfc_main$2, {
                            id: "weight",
                            type: "number",
                            step: "0.01",
                            class: "mt-1 block w-full",
                            modelValue: unref(form).weight,
                            "onUpdate:modelValue": ($event) => unref(form).weight = $event
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$3, {
                            class: "mt-2",
                            message: unref(form).errors.weight
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$1, {
                            for: "weight_per_unit",
                            value: "Weight per unit"
                          }),
                          createVNode(_sfc_main$2, {
                            id: "weight_per_unit",
                            type: "number",
                            step: "0.01",
                            class: "mt-1 block w-full",
                            modelValue: unref(form).weight_per_unit,
                            "onUpdate:modelValue": ($event) => unref(form).weight_per_unit = $event
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$3, {
                            class: "mt-2",
                            message: unref(form).errors.weight_per_unit
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$1, {
                            for: "total_cost",
                            value: "Total Cost"
                          }),
                          createVNode(_sfc_main$2, {
                            id: "total_cost",
                            type: "number",
                            step: "0.01",
                            class: "mt-1 block w-full",
                            modelValue: unref(form).total_cost,
                            "onUpdate:modelValue": ($event) => unref(form).total_cost = $event
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$3, {
                            class: "mt-2",
                            message: unref(form).errors.total_cost
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$1, {
                            for: "stock_receive",
                            value: "Stock Receive"
                          }),
                          createVNode(_sfc_main$2, {
                            id: "stock_receive",
                            type: "number",
                            class: "mt-1 block w-full",
                            modelValue: unref(form).stock_receive,
                            "onUpdate:modelValue": ($event) => unref(form).stock_receive = $event,
                            modelModifiers: { number: true }
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$3, {
                            class: "mt-2",
                            message: unref(form).errors.stock_receive
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$1, {
                            for: "stock_release",
                            value: "Stock Release"
                          }),
                          createVNode(_sfc_main$2, {
                            id: "stock_release",
                            type: "number",
                            class: "mt-1 block w-full",
                            modelValue: unref(form).stock_release,
                            "onUpdate:modelValue": ($event) => unref(form).stock_release = $event
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$3, {
                            class: "mt-2",
                            message: unref(form).errors.stock_release
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$1, {
                            for: "remaining_units",
                            value: "Remaining units"
                          }),
                          createVNode(_sfc_main$2, {
                            id: "remaining_units",
                            type: "number",
                            class: "mt-1 block w-full",
                            modelValue: unref(form).remaining_units,
                            "onUpdate:modelValue": ($event) => unref(form).remaining_units = $event,
                            modelModifiers: { number: true }
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$3, {
                            class: "mt-2",
                            message: unref(form).errors.remaining_units
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$1, {
                            for: "exp_date",
                            value: "Expiration Date"
                          }),
                          createVNode(_sfc_main$2, {
                            id: "exp_date",
                            type: "date",
                            class: "mt-1 block w-full",
                            modelValue: unref(form).exp_date,
                            "onUpdate:modelValue": ($event) => unref(form).exp_date = $event
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$3, {
                            class: "mt-2",
                            message: unref(form).errors.exp_date
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$1, {
                            for: "batch_number",
                            value: "Batch Number"
                          }),
                          createVNode(_sfc_main$2, {
                            id: "batch_number",
                            type: "text",
                            class: "mt-1 block w-full",
                            modelValue: unref(form).batch_number,
                            "onUpdate:modelValue": ($event) => unref(form).batch_number = $event
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$3, {
                            class: "mt-2",
                            message: unref(form).errors.batch_number
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$1, {
                            for: "supplier",
                            value: "Supplier"
                          }),
                          withDirectives(createVNode("select", {
                            id: "supplier",
                            "onUpdate:modelValue": ($event) => unref(form).supplier_id = $event,
                            class: "mt-1 block w-full rounded-md shadow-sm border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                          }, [
                            createVNode("option", {
                              value: "",
                              disabled: ""
                            }, "Select a Supplier"),
                            (openBlock(true), createBlock(Fragment, null, renderList(__props.suppliers, (supplier) => {
                              return openBlock(), createBlock("option", {
                                key: supplier.id,
                                value: supplier.id
                              }, toDisplayString(supplier.name), 9, ["value"]);
                            }), 128))
                          ], 8, ["onUpdate:modelValue"]), [
                            [vModelSelect, unref(form).supplier_id]
                          ]),
                          createVNode(_sfc_main$3, {
                            class: "mt-2",
                            message: unref(form).errors.category_id
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$1, {
                            for: "storage_location",
                            value: "Storage Location"
                          }),
                          createVNode(_sfc_main$2, {
                            id: "storage_location",
                            type: "text",
                            class: "mt-1 block w-full",
                            modelValue: unref(form).storage_location,
                            "onUpdate:modelValue": ($event) => unref(form).storage_location = $event
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$3, {
                            class: "mt-2",
                            message: unref(form).errors.storage_location
                          }, null, 8, ["message"])
                        ])
                      ]),
                      createVNode("div", { class: "flex items-center gap-4" }, [
                        createVNode(PrimaryButton, {
                          disabled: unref(form).processing
                        }, {
                          default: withCtx(() => [
                            createTextVNode("Update")
                          ]),
                          _: 1
                        }, 8, ["disabled"])
                      ])
                    ], 32)
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/product/Edit.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
