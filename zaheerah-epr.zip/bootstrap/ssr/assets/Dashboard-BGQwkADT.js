import { defineComponent, mergeProps, useSSRContext, unref, withCtx, createVNode, openBlock, createBlock, createCommentVNode, Fragment, renderList, toDisplayString } from "vue";
import { ssrRenderAttrs, ssrInterpolate, ssrRenderClass, ssrRenderList, ssrRenderComponent } from "vue/server-renderer";
import { A as AuthenticatedLayout } from "./AuthenticatedLayout-BMQt65oV.js";
import { Head } from "@inertiajs/vue3";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-1tPrXgE0.js";
import { is } from "laravel-permission-to-vuejs";
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "StatisticCard",
  __ssrInlineRender: true,
  props: {
    title: { type: String, required: true },
    value: { type: String, required: true },
    color: { type: String, default: "indigo" },
    // Color for value text, default to indigo
    subtitle: { type: String, default: "" },
    updated: { type: String, default: "" }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "p-5 bg-white dark:bg-gray-800 shadow-lg rounded-lg" }, _attrs))} data-v-c3a6218e><h3 class="text-xl font-medium text-gray-800 dark:text-gray-200" data-v-c3a6218e>${ssrInterpolate(__props.title)}</h3><p class="${ssrRenderClass(`mt-2 text-3xl font-bold text-${__props.color}-500`)}" data-v-c3a6218e>${ssrInterpolate(__props.value)}</p>`);
      if (__props.subtitle) {
        _push(`<p class="mt-1 text-xs text-gray-500 dark:text-gray-400" data-v-c3a6218e>${ssrInterpolate(__props.subtitle)}</p>`);
      } else {
        _push(`<!---->`);
      }
      if (__props.updated) {
        _push(`<p class="mt-1 text-xs text-gray-500 dark:text-gray-400" data-v-c3a6218e>Updated ${ssrInterpolate(__props.updated)}</p>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/StatisticCard.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const StatisticCard = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-c3a6218e"]]);
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "ActivityPanel",
  __ssrInlineRender: true,
  props: {
    title: {},
    items: {}
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "bg-white dark:bg-gray-800 shadow-lg rounded-lg p-6" }, _attrs))}><h3 class="text-xl font-semibold text-gray-800 dark:text-gray-200">${ssrInterpolate(_ctx.title)}</h3><ul class="mt-4 space-y-4"><!--[-->`);
      ssrRenderList(_ctx.items, (item, index) => {
        _push(`<li class="p-4 bg-gray-100 dark:bg-gray-700 rounded-md flex justify-between"><span class="text-sm font-medium text-gray-600 dark:text-gray-400">${ssrInterpolate(item.description)}</span><span class="text-xs text-gray-500 dark:text-gray-400">${ssrInterpolate(item.time)}</span></li>`);
      });
      _push(`<!--]--></ul></div>`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/ActivityPanel.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Dashboard",
  __ssrInlineRender: true,
  props: {
    totalRevenue: {
      type: String,
      default: "0"
    },
    totalProfit: {
      type: String,
      default: "0"
    },
    totalStock: {
      type: String,
      default: "0"
    },
    totalCost: {
      type: String,
      default: "0"
    },
    categories: Array,
    recentActivities: {
      type: Array,
      default: []
    },
    users: Array
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Dashboard" }, null, _parent));
      _push(ssrRenderComponent(AuthenticatedLayout, null, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<header class="flex items-center justify-between px-4 py-4 bg-gray-50 dark:bg-gray-800 rounded-lg shadow-sm"${_scopeId}><h2 class="text-3xl font-bold text-gray-800 dark:text-gray-200"${_scopeId}>Admin Dashboard</h2></header>`);
          } else {
            return [
              createVNode("header", { class: "flex items-center justify-between px-4 py-4 bg-gray-50 dark:bg-gray-800 rounded-lg shadow-sm" }, [
                createVNode("h2", { class: "text-3xl font-bold text-gray-800 dark:text-gray-200" }, "Admin Dashboard")
              ])
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<main class="min-h-screen bg-gray-100 dark:bg-gray-900"${_scopeId}><section class="container mx-auto max-w-7xl space-y-12"${_scopeId}>`);
            if (unref(is)("Super Admin | Admin")) {
              _push2(`<div class="grid grid-cols-1 gap-6 md:grid-cols-4"${_scopeId}>`);
              _push2(ssrRenderComponent(StatisticCard, {
                title: "Total Revenue",
                value: __props.totalRevenue,
                color: "yellow",
                subtitle: "Monthly Revenue"
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(StatisticCard, {
                title: "Total Cost",
                value: __props.totalProfit,
                color: "red",
                subtitle: "Monthly Costs"
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(StatisticCard, {
                title: "Profit",
                value: __props.totalCost,
                color: "green",
                subtitle: "Monthly Profit"
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(StatisticCard, {
                title: "Inventory Level",
                value: __props.totalStock,
                color: "green",
                subtitle: "Items"
              }, null, _parent2, _scopeId));
              _push2(`</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div class="bg-white dark:bg-gray-800 shadow-lg rounded-lg p-6"${_scopeId}><h3 class="text-2xl font-semibold text-gray-800 dark:text-gray-200 mb-6"${_scopeId}>Financial Indicators by Category</h3><div class="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3"${_scopeId}><!--[-->`);
            ssrRenderList(__props.categories, (category) => {
              _push2(`<div class="bg-gray-50 dark:bg-gray-700 rounded-lg shadow p-6 hover:shadow-xl transition-all duration-300"${_scopeId}><h4 class="text-xl font-medium text-gray-800 dark:text-gray-200"${_scopeId}>${ssrInterpolate(category.name)}</h4><div class="mt-4 space-y-2"${_scopeId}><div class="flex justify-between text-sm text-gray-600 dark:text-gray-400"${_scopeId}><span${_scopeId}>Revenue:</span><span class="font-semibold text-grey-900 dark:text-green-400"${_scopeId}>${ssrInterpolate(category.revenue)}</span></div><div class="flex justify-between text-sm text-gray-600 dark:text-gray-400"${_scopeId}><span${_scopeId}>Cost:</span><span class="font-semibold text-red-600 dark:text-red-400"${_scopeId}>${ssrInterpolate(category.cost)}</span></div><div class="flex justify-between text-sm text-gray-600 dark:text-gray-400"${_scopeId}><span${_scopeId}>Profit:</span><span class="font-semibold text-green-600 dark:text-green-400"${_scopeId}>${ssrInterpolate(category.profit)}</span></div><div class="flex justify-between text-sm text-gray-600 dark:text-gray-400"${_scopeId}><span${_scopeId}>Inventory level:</span><span class="font-semibold text-blue-600 dark:text-blue-400"${_scopeId}>${ssrInterpolate(category.inventory)}</span></div></div></div>`);
            });
            _push2(`<!--]--></div></div><div class="bg-white dark:bg-gray-800 shadow-lg rounded-lg p-6"${_scopeId}><h3 class="text-2xl font-semibold text-gray-800 dark:text-gray-200 mb-4"${_scopeId}>Employee Records</h3><table class="w-full border-collapse text-left"${_scopeId}><thead${_scopeId}><tr class="bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-200 font-medium text-sm"${_scopeId}><th class="p-3 border-b dark:border-gray-600"${_scopeId}>Name</th><th class="p-3 border-b dark:border-gray-600"${_scopeId}>Email</th><th class="p-3 border-b dark:border-gray-600"${_scopeId}>Phone Number</th><th class="p-3 border-b dark:border-gray-600"${_scopeId}>Role</th></tr></thead><tbody class="text-sm text-gray-700 dark:text-gray-200"${_scopeId}><!--[-->`);
            ssrRenderList(__props.users, (user) => {
              _push2(`<tr class="hover:bg-gray-100 dark:hover:bg-gray-700"${_scopeId}><td class="p-3 border-b dark:border-gray-600"${_scopeId}>${ssrInterpolate(user.name)}</td><td class="p-3 border-b dark:border-gray-600"${_scopeId}>${ssrInterpolate(user.email)}</td><td class="p-3 border-b dark:border-gray-600"${_scopeId}>${ssrInterpolate(user.phone)}</td><td class="p-3 border-b dark:border-gray-600"${_scopeId}><span class="${ssrRenderClass(user.status === "Active" ? "text-green-500" : "text-red-500")}"${_scopeId}>${ssrInterpolate(user.role)}</span></td></tr>`);
            });
            _push2(`<!--]--></tbody></table></div><div class="grid grid-cols-1 gap-6 lg:grid-cols-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$1, {
              title: "Recent Activity",
              items: __props.recentActivities
            }, null, _parent2, _scopeId));
            _push2(`</div></section></main>`);
          } else {
            return [
              createVNode("main", { class: "min-h-screen bg-gray-100 dark:bg-gray-900" }, [
                createVNode("section", { class: "container mx-auto max-w-7xl space-y-12" }, [
                  unref(is)("Super Admin | Admin") ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: "grid grid-cols-1 gap-6 md:grid-cols-4"
                  }, [
                    createVNode(StatisticCard, {
                      title: "Total Revenue",
                      value: __props.totalRevenue,
                      color: "yellow",
                      subtitle: "Monthly Revenue"
                    }, null, 8, ["value"]),
                    createVNode(StatisticCard, {
                      title: "Total Cost",
                      value: __props.totalProfit,
                      color: "red",
                      subtitle: "Monthly Costs"
                    }, null, 8, ["value"]),
                    createVNode(StatisticCard, {
                      title: "Profit",
                      value: __props.totalCost,
                      color: "green",
                      subtitle: "Monthly Profit"
                    }, null, 8, ["value"]),
                    createVNode(StatisticCard, {
                      title: "Inventory Level",
                      value: __props.totalStock,
                      color: "green",
                      subtitle: "Items"
                    }, null, 8, ["value"])
                  ])) : createCommentVNode("", true),
                  createVNode("div", { class: "bg-white dark:bg-gray-800 shadow-lg rounded-lg p-6" }, [
                    createVNode("h3", { class: "text-2xl font-semibold text-gray-800 dark:text-gray-200 mb-6" }, "Financial Indicators by Category"),
                    createVNode("div", { class: "grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3" }, [
                      (openBlock(true), createBlock(Fragment, null, renderList(__props.categories, (category) => {
                        return openBlock(), createBlock("div", {
                          key: category.id,
                          class: "bg-gray-50 dark:bg-gray-700 rounded-lg shadow p-6 hover:shadow-xl transition-all duration-300"
                        }, [
                          createVNode("h4", { class: "text-xl font-medium text-gray-800 dark:text-gray-200" }, toDisplayString(category.name), 1),
                          createVNode("div", { class: "mt-4 space-y-2" }, [
                            createVNode("div", { class: "flex justify-between text-sm text-gray-600 dark:text-gray-400" }, [
                              createVNode("span", null, "Revenue:"),
                              createVNode("span", { class: "font-semibold text-grey-900 dark:text-green-400" }, toDisplayString(category.revenue), 1)
                            ]),
                            createVNode("div", { class: "flex justify-between text-sm text-gray-600 dark:text-gray-400" }, [
                              createVNode("span", null, "Cost:"),
                              createVNode("span", { class: "font-semibold text-red-600 dark:text-red-400" }, toDisplayString(category.cost), 1)
                            ]),
                            createVNode("div", { class: "flex justify-between text-sm text-gray-600 dark:text-gray-400" }, [
                              createVNode("span", null, "Profit:"),
                              createVNode("span", { class: "font-semibold text-green-600 dark:text-green-400" }, toDisplayString(category.profit), 1)
                            ]),
                            createVNode("div", { class: "flex justify-between text-sm text-gray-600 dark:text-gray-400" }, [
                              createVNode("span", null, "Inventory level:"),
                              createVNode("span", { class: "font-semibold text-blue-600 dark:text-blue-400" }, toDisplayString(category.inventory), 1)
                            ])
                          ])
                        ]);
                      }), 128))
                    ])
                  ]),
                  createVNode("div", { class: "bg-white dark:bg-gray-800 shadow-lg rounded-lg p-6" }, [
                    createVNode("h3", { class: "text-2xl font-semibold text-gray-800 dark:text-gray-200 mb-4" }, "Employee Records"),
                    createVNode("table", { class: "w-full border-collapse text-left" }, [
                      createVNode("thead", null, [
                        createVNode("tr", { class: "bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-200 font-medium text-sm" }, [
                          createVNode("th", { class: "p-3 border-b dark:border-gray-600" }, "Name"),
                          createVNode("th", { class: "p-3 border-b dark:border-gray-600" }, "Email"),
                          createVNode("th", { class: "p-3 border-b dark:border-gray-600" }, "Phone Number"),
                          createVNode("th", { class: "p-3 border-b dark:border-gray-600" }, "Role")
                        ])
                      ]),
                      createVNode("tbody", { class: "text-sm text-gray-700 dark:text-gray-200" }, [
                        (openBlock(true), createBlock(Fragment, null, renderList(__props.users, (user) => {
                          return openBlock(), createBlock("tr", {
                            key: user.id,
                            class: "hover:bg-gray-100 dark:hover:bg-gray-700"
                          }, [
                            createVNode("td", { class: "p-3 border-b dark:border-gray-600" }, toDisplayString(user.name), 1),
                            createVNode("td", { class: "p-3 border-b dark:border-gray-600" }, toDisplayString(user.email), 1),
                            createVNode("td", { class: "p-3 border-b dark:border-gray-600" }, toDisplayString(user.phone), 1),
                            createVNode("td", { class: "p-3 border-b dark:border-gray-600" }, [
                              createVNode("span", {
                                class: user.status === "Active" ? "text-green-500" : "text-red-500"
                              }, toDisplayString(user.role), 3)
                            ])
                          ]);
                        }), 128))
                      ])
                    ])
                  ]),
                  createVNode("div", { class: "grid grid-cols-1 gap-6 lg:grid-cols-1" }, [
                    createVNode(_sfc_main$1, {
                      title: "Recent Activity",
                      items: __props.recentActivities
                    }, null, 8, ["items"])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Dashboard.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
