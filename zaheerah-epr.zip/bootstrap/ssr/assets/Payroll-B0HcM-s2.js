import { defineComponent, ref, computed, onMounted, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderList, ssrRenderClass } from "vue/server-renderer";
import _sfc_main$1 from "./PayrollFormModal-Cutmei_-.js";
import _sfc_main$2 from "./UpdateModal-D1X0e6Ax.js";
import _sfc_main$3 from "./ViewPayrollModal-DzieJlsf.js";
import { f as fetchPayrolls } from "./payrollService-Dk0jLPaH.js";
import "axios";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Payroll",
  __ssrInlineRender: true,
  setup(__props) {
    const payrolls = ref([]);
    const loading = ref(false);
    const payrollFilter = ref("All");
    const payrollFilters = ["All", "Paid", "Pending"];
    const isCreateModalOpen = ref(false);
    const isEditModalOpen = ref(false);
    const isViewModalOpen = ref(false);
    const editedPayroll = ref(null);
    const viewedPayroll = ref(null);
    const successMessage = ref("");
    ref(null);
    const formatNumber = (num) => (num == null ? void 0 : num.toLocaleString()) || "0";
    const formatDate = (dateString) => new Date(dateString).toLocaleDateString();
    const statusClasses = (status) => ({
      "text-green-500": status === "paid",
      "text-yellow-500": status === "pending",
      "text-red-500": status === "failed"
    });
    const handlePayrollUpdate = () => {
      isEditModalOpen.value = false;
      successMessage.value = "Payroll successfully updated!";
      setTimeout(() => successMessage.value = "", 3e3);
      loadPayrolls();
    };
    const closeModals = () => {
      isCreateModalOpen.value = false;
      isEditModalOpen.value = false;
      isViewModalOpen.value = false;
      editedPayroll.value = null;
      viewedPayroll.value = null;
    };
    const filteredPayrolls = computed(() => {
      if (payrollFilter.value === "All") return payrolls.value;
      return payrolls.value.filter(
        (payroll) => payroll.payment_status === payrollFilter.value.toLowerCase()
      );
    });
    const handlePayrollSubmit = () => {
      isCreateModalOpen.value = false;
      successMessage.value = "Payroll successfully submitted!";
      setTimeout(() => successMessage.value = "", 3e3);
      loadPayrolls();
    };
    const loadPayrolls = async () => {
      loading.value = true;
      try {
        payrolls.value = await fetchPayrolls();
      } catch (error) {
        console.error("Error fetching payrolls:", error);
      } finally {
        loading.value = false;
      }
    };
    onMounted(loadPayrolls);
    const closePayrollForm = () => {
      isCreateModalOpen.value = false;
    };
    return (_ctx, _push, _parent, _attrs) => {
      var _a;
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      if (isCreateModalOpen.value) {
        _push(ssrRenderComponent(_sfc_main$1, {
          onSubmit: handlePayrollSubmit,
          onClose: closePayrollForm
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (isEditModalOpen.value) {
        _push(ssrRenderComponent(_sfc_main$2, {
          onUpdate: handlePayrollUpdate,
          onClose: closeModals,
          payroll: editedPayroll.value,
          key: (_a = editedPayroll.value) == null ? void 0 : _a.id
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (isViewModalOpen.value) {
        _push(ssrRenderComponent(_sfc_main$3, {
          onClose: closeModals,
          payroll: viewedPayroll.value
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (successMessage.value) {
        _push(`<div class="bg-green-500 text-white p-4 rounded-lg mb-4">${ssrInterpolate(successMessage.value)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<h3 class="text-2xl font-semibold mb-4">Payroll Tracking</h3><div class="mb-6 flex space-x-4"><!--[-->`);
      ssrRenderList(payrollFilters, (filter) => {
        _push(`<button class="${ssrRenderClass([{ "bg-green-500 text-white": payrollFilter.value === filter }, "px-4 py-2 rounded-lg bg-gray-200 dark:bg-gray-700 hover:bg-green-500 hover:text-white transition"])}">${ssrInterpolate(filter)}</button>`);
      });
      _push(`<!--]--><button class="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition"> Add Payroll </button></div><div class="bg-white dark:bg-gray-800 shadow-lg rounded-lg p-4"><div class="overflow-y-auto max-h-[400px] overflow-x-auto"><table class="w-full border-collapse min-w-[1000px]"><thead><tr class="bg-gray-200 dark:bg-gray-700"><th class="py-3 px-4 text-left sticky top-0 bg-gray-200 dark:bg-gray-700 z-10">Employee ID</th><th class="py-3 px-4 text-left sticky top-0 bg-gray-200 dark:bg-gray-700 z-10">Employee</th><th class="py-3 px-4 text-left sticky top-0 bg-gray-200 dark:bg-gray-700 z-10">Base Salary</th><th class="py-3 px-4 text-left sticky top-0 bg-gray-200 dark:bg-gray-700 z-10">Gross Salary</th><th class="py-3 px-4 text-left sticky top-0 bg-gray-200 dark:bg-gray-700 z-10">Total Deduction</th><th class="py-3 px-4 text-left sticky top-0 bg-gray-200 dark:bg-gray-700 z-10">Net Salary</th><th class="py-3 px-4 text-left sticky top-0 bg-gray-200 dark:bg-gray-700 z-10">Payment Method</th><th class="py-3 px-4 text-left sticky top-0 bg-gray-200 dark:bg-gray-700 z-10">Payment Date</th><th class="py-3 px-4 text-left sticky top-0 bg-gray-200 dark:bg-gray-700 z-10">Status</th><th class="py-3 px-4 text-left sticky top-0 bg-gray-200 dark:bg-gray-700 z-10">Actions</th></tr></thead><tbody><!--[-->`);
      ssrRenderList(filteredPayrolls.value, (payroll) => {
        _push(`<tr class="border-t border-gray-300 dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700"><td class="py-3 px-4">${ssrInterpolate(payroll.user.employee_id)}</td><td class="py-3 px-4">${ssrInterpolate(payroll.user.name)}</td><td class="py-3 px-4">₦${ssrInterpolate(formatNumber(payroll.base_salary))}</td><td class="py-3 px-4">₦${ssrInterpolate(formatNumber(payroll.gross_salary))}</td><td class="py-3 px-4">₦${ssrInterpolate(formatNumber(payroll.total_deduction))}</td><td class="py-3 px-4">₦${ssrInterpolate(formatNumber(payroll.net_salary))}</td><td class="py-3 px-4 capitalize">${ssrInterpolate(payroll.payment_method.replace("_", " "))}</td><td class="py-3 px-4">${ssrInterpolate(formatDate(payroll.payment_date))}</td><td class="py-3 px-4"><span class="${ssrRenderClass(statusClasses(payroll.payment_status))}">${ssrInterpolate(payroll.payment_status)}</span></td><td class="py-3 px-4 space-x-2"><button class="px-2 py-1 bg-yellow-500 text-sm text-white rounded-md hover:bg-yellow-600 transition"> Edit </button><button class="px-2 py-1 bg-red-500 text-sm text-white rounded-md hover:bg-red-600 transition"> Delete </button><button class="px-2 py-1 bg-blue-500 text-sm z-50 text-white rounded-md hover:bg-blue-600 transition"> View </button></td></tr>`);
      });
      _push(`<!--]--></tbody></table></div></div>`);
      if (loading.value) {
        _push(`<div class="flex justify-center items-center p-4"><p class="text-green-500">Loading...</p></div>`);
      } else {
        _push(`<!---->`);
      }
      if (!loading.value && payrolls.value.length === 0) {
        _push(`<div class="text-center p-8 text-gray-500"> No payroll records found </div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/finance/Components/Payroll.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
