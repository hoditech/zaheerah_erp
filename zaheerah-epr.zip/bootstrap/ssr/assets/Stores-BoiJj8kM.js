import { defineComponent, ref, resolveComponent, unref, withCtx, createVNode, createTextVNode, withDirectives, vModelText, openBlock, createBlock, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderAttr } from "vue/server-renderer";
import { A as AuthenticatedLayout } from "./AuthenticatedLayout-GMSouBjC.js";
import { Head } from "@inertiajs/vue3";
import { D as DataTable } from "./DataTable-Bf1VUkR3.js";
import "laravel-permission-to-vuejs";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Stores",
  __ssrInlineRender: true,
  setup(__props) {
    const stores = ref([
      { id: 1, name: "Main Store", location: "123 Main St", manager: "Alice Johnson", status: "Open" },
      { id: 2, name: "Downtown Outlet", location: "45 Downtown Ave", manager: "Bob Smith", status: "Closed" },
      { id: 3, name: "Westside Branch", location: "78 West St", manager: "Carol White", status: "Open" }
    ]);
    const columns = [
      { label: "ID", key: "id" },
      { label: "Name", key: "name" },
      { label: "Location", key: "location" },
      { label: "Manager", key: "manager" },
      { label: "Status", key: "status" }
    ];
    const searchQuery = ref("");
    const deleteStore = (store) => {
      stores.value = stores.value.filter((s) => s.id !== store.id);
    };
    const actions = [
      { label: "Delete", onClick: deleteStore, class: "text-red-600 hover:text-red-900" },
      {
        label: "Edit",
        onClick: (store) => console.log("Edit", store),
        class: "text-blue-600 hover:text-blue-900"
      }
    ];
    return (_ctx, _push, _parent, _attrs) => {
      const _component_router_link = resolveComponent("router-link");
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Stores Management" }, null, _parent));
      _push(ssrRenderComponent(AuthenticatedLayout, null, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<h2 class="text-2xl font-bold leading-tight text-gray-800 dark:text-gray-200"${_scopeId}>Stores Management</h2>`);
          } else {
            return [
              createVNode("h2", { class: "text-2xl font-bold leading-tight text-gray-800 dark:text-gray-200" }, "Stores Management")
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="py-6"${_scopeId}><div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8"${_scopeId}><div class="flex justify-between items-center mb-6"${_scopeId}><div class="relative w-1/3"${_scopeId}><input${ssrRenderAttr("value", searchQuery.value)} type="text" placeholder="Search stores..." class="w-full p-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring focus:ring-green-500 dark:bg-gray-700 dark:border-gray-600 dark:text-gray-300"${_scopeId}><span class="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-500"${_scopeId}><svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"${_scopeId}><path fill-rule="evenodd" d="M11.742 10.988a4.5 4.5 0 1 1 .707.707l4.47 4.47a1 1 0 0 1-1.414 1.414l-4.47-4.47a4.5 4.5 0 0 1-.707-.707zM12 9.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5z" clip-rule="evenodd"${_scopeId}></path></svg></span></div>`);
            _push2(ssrRenderComponent(_component_router_link, {
              to: "/stores/new",
              class: "inline-flex items-center px-4 py-2 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-md shadow-md transition duration-300 ease-in-out"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` New Store `);
                } else {
                  return [
                    createTextVNode(" New Store ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div>`);
            _push2(ssrRenderComponent(DataTable, {
              columns,
              data: stores.value,
              searchQuery: searchQuery.value,
              actions
            }, null, _parent2, _scopeId));
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", { class: "py-6" }, [
                createVNode("div", { class: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8" }, [
                  createVNode("div", { class: "flex justify-between items-center mb-6" }, [
                    createVNode("div", { class: "relative w-1/3" }, [
                      withDirectives(createVNode("input", {
                        "onUpdate:modelValue": ($event) => searchQuery.value = $event,
                        type: "text",
                        placeholder: "Search stores...",
                        class: "w-full p-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring focus:ring-green-500 dark:bg-gray-700 dark:border-gray-600 dark:text-gray-300"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, searchQuery.value]
                      ]),
                      createVNode("span", { class: "absolute inset-y-0 left-0 flex items-center pl-3 text-gray-500" }, [
                        (openBlock(), createBlock("svg", {
                          xmlns: "http://www.w3.org/2000/svg",
                          class: "h-5 w-5",
                          viewBox: "0 0 20 20",
                          fill: "currentColor"
                        }, [
                          createVNode("path", {
                            "fill-rule": "evenodd",
                            d: "M11.742 10.988a4.5 4.5 0 1 1 .707.707l4.47 4.47a1 1 0 0 1-1.414 1.414l-4.47-4.47a4.5 4.5 0 0 1-.707-.707zM12 9.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5z",
                            "clip-rule": "evenodd"
                          })
                        ]))
                      ])
                    ]),
                    createVNode(_component_router_link, {
                      to: "/stores/new",
                      class: "inline-flex items-center px-4 py-2 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-md shadow-md transition duration-300 ease-in-out"
                    }, {
                      default: withCtx(() => [
                        createTextVNode(" New Store ")
                      ]),
                      _: 1
                    })
                  ]),
                  createVNode(DataTable, {
                    columns,
                    data: stores.value,
                    searchQuery: searchQuery.value,
                    actions
                  }, null, 8, ["data", "searchQuery"])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Stores.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
