import { defineComponent, ref, computed, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderAttr, ssrRenderList, ssrIncludeBooleanAttr, ssrLooseContain, ssrInterpolate } from "vue/server-renderer";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Reports",
  __ssrInlineRender: true,
  props: {
    categories: { default: () => [] }
  },
  setup(__props) {
    const props = __props;
    const selectedColumns = ref(["name", "revenue", "cost", "profit", "inventory"]);
    const dateRange = ref({ start: "2023-10-01", end: "2023-10-31" });
    const filteredReports = computed(() => {
      return (props.categories ?? []).filter((category) => {
        return true;
      });
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}><h3 class="text-2xl font-semibold mb-4">Reports</h3><div class="mb-6 bg-white dark:bg-gray-800 shadow-lg rounded-lg p-6"><h4 class="text-lg font-semibold text-gray-700 dark:text-gray-200 mb-4">Customize Report</h4><div class="grid grid-cols-1 md:grid-cols-2 gap-6"><div><label class="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-2">Date Range</label><div class="flex space-x-4"><input${ssrRenderAttr("value", dateRange.value.start)} type="date" class="px-4 py-2 rounded-lg bg-gray-200 dark:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"><input${ssrRenderAttr("value", dateRange.value.end)} type="date" class="px-4 py-2 rounded-lg bg-gray-200 dark:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-green-500"></div></div><div><label class="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-2">Select Columns</label><div class="flex flex-wrap gap-2"><!--[-->`);
      ssrRenderList(["name", "revenue", "cost", "profit", "inventory"], (column) => {
        _push(`<label class="flex items-center space-x-2"><input type="checkbox"${ssrIncludeBooleanAttr(Array.isArray(selectedColumns.value) ? ssrLooseContain(selectedColumns.value, column) : selectedColumns.value) ? " checked" : ""}${ssrRenderAttr("value", column)} class="rounded border-gray-300 dark:border-gray-700"><span class="text-gray-700 dark:text-gray-200">${ssrInterpolate(column.replace(/([A-Z])/g, "$1").toUpperCase())}</span></label>`);
      });
      _push(`<!--]--></div></div></div></div><div class="mb-6 flex space-x-4"><button class="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition"> Export as CSV </button><button class="px-4 py-2 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition"> Export as Excel </button></div><div class="bg-white dark:bg-gray-800 shadow-lg rounded-lg p-4"><h4 class="text-lg font-semibold text-gray-700 dark:text-gray-200 mb-4">Preview</h4><table class="w-full border-collapse"><thead><tr class="bg-gray-200 dark:bg-gray-700"><!--[-->`);
      ssrRenderList(selectedColumns.value, (column) => {
        _push(`<th class="py-3 px-4 text-left">${ssrInterpolate(column.replace(/([A-Z])/g, " $1").toUpperCase())}</th>`);
      });
      _push(`<!--]--></tr></thead><tbody><!--[-->`);
      ssrRenderList(filteredReports.value, (report) => {
        _push(`<tr class="border-t border-gray-300 dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700"><!--[-->`);
        ssrRenderList(selectedColumns.value, (column) => {
          _push(`<td class="py-3 px-4">${ssrInterpolate(report[column] ?? "N/A")}</td>`);
        });
        _push(`<!--]--></tr>`);
      });
      _push(`<!--]--></tbody></table></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/finance/Components/Reports.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
