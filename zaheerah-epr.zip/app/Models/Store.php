<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Store extends Model
{
    protected $fillable = ['name'];

    // A store has many users (employees)
    public function users()
    {
        return $this->hasMany(User::class);
    }
}
