<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Sale;
use App\Models\Product;
use App\Models\Category;
use Carbon\Carbon;

class ReportController extends Controller
{
    // Sales Report with date filtering (JSON response)
    public function salesReport(Request $request)
    {
        $validated = $request->validate([
            'start_date' => 'nullable|date',
            'end_date' => 'nullable|date|after_or_equal:start_date',
        ]);

        $query = Sale::with(['items.product'])
            ->when($request->start_date, function ($q) use ($validated) {
                $q->where('created_at', '>=', $validated['start_date']);
            })
            ->when($request->end_date, function ($q) use ($validated) {
                $q->where('created_at', '<=', Carbon::parse($validated['end_date'])->endOfDay());
            });

        $totalSales = $query->sum('total_amount');
        $transactions = $query->paginate(10);

        return response()->json([
            'status' => 'success',
            'data' => [
                'total_sales' => $totalSales,
                'transactions' => $transactions,
            ],
        ]);
    }

    // Product Performance Report (JSON response)
   

    // Category-wise Sales Report (JSON response)
    public function categorySales(Request $request)
    {
        $categories = Category::selectRaw('
                categories.*,
                SUM(sale_items.quantity) as total_quantity,
                SUM(sale_items.quantity * sale_items.price) as total_revenue
            ')
            ->leftJoin('products', 'products.category_id', '=', 'categories.id')
            ->leftJoin('sale_items', 'sale_items.product_id', '=', 'products.id')
            ->groupBy('categories.id')
            ->orderBy('total_revenue', 'desc')
            ->paginate(10);

        return response()->json([
            'status' => 'success',
            'data' => $categories,
        ]);
    }

    // Inventory Status Report (JSON response)
    public function inventoryReport()
    {
        $products = Product::with(['category', 'supplier'])
            ->orderBy('remaining_units')
            ->paginate(10);

        return response()->json([
            'status' => 'success',
            'data' => $products,
        ]);
    }

    // Expiry Report (JSON response)
    public function expiryReport(Request $request)
    {
        $validated = $request->validate([
            'threshold' => 'nullable|integer|min:1|max:365',
        ]);

        $threshold = $validated['threshold'] ?? 30;
        $expiryDate = Carbon::now()->addDays($threshold);

        $products = Product::whereNotNull('exp_date')
            ->where('exp_date', '<=', $expiryDate)
            ->orderBy('exp_date')
            ->paginate(10);

        return response()->json([
            'status' => 'success',
            'data' => [
                'threshold_days' => $threshold,
                'products' => $products,
            ],
        ]);
    }

    // Stock Movement Report (JSON response)
    public function stockMovement(Request $request)
    {
        $validated = $request->validate([
            'start_date' => 'nullable|date',
            'end_date' => 'nullable|date|after_or_equal:start_date',
        ]);

        $products = Product::with(['category'])
            ->withSum([
                'productions as total_produced' => function ($query) use ($validated) {
                    $this->applyDateFilters($query, $validated);
                }
            ], 'quantity_produced')
            ->withSum([
                'saleItems as total_sold' => function ($query) use ($validated) {
                    $this->applyDateFilters($query->whereHas('sale'), $validated);
                }
            ], 'quantity')
            ->paginate(10);

        return response()->json([
            'status' => 'success',
            'data' => $products,
        ]);
    }

    // Helper method for date filtering
    private function applyDateFilters($query, $filters)
    {
        if (!empty($filters['start_date'])) {
            $query->where('created_at', '>=', $filters['start_date']);
        }
        if (!empty($filters['end_date'])) {
            $query->where('created_at', '<=', Carbon::parse($filters['end_date'])->endOfDay());
        }
    }
}